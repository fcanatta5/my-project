# pkg — gerenciador pessoal monolítico em Bash

`pkg` é um gerenciador de software pessoal para Linux From Scratch/JHALFS pensado para ser simples, rastreável e previsível. Ele não tenta competir com `apt`, `dnf` ou `pacman`. O foco é outro: construir, instalar, atualizar, remover e auditar software local com receitas em Bash, manifesto de arquivos, banco local legível e snapshots simples.

Esta versão fecha a etapa de endurecimento funcional do projeto e adiciona uma camada mais madura de integração com LFS + systemd:
- install, remove, reinstall e upgrade
- depends, provides, rdeps, orphan e autoremove
- conflitos de manifesto/ownership antes da instalação
- replaces simples e validado
- rollback simples por snapshot dos arquivos registrados
- patches automáticos
- hooks de arquivo e de função
- suporte a múltiplas fontes locais/remotas e `git+`
- logs por etapa
- suíte de testes automatizados
- verify/owner/snapshots/rollback com auditoria mais rígida
- documentação detalhada de configuração, uso, manutenção e auditoria
- sysusers/tmpfiles declarativos por pacote
- enable/disable de unidades systemd no pós-instalação
- triggers globais para ldconfig, cache de ícones, MIME, gdk-pixbuf, info dir e man-db
- alternativas via update-alternatives
- formato binário instalável com metadados e source package separado
- repositório binário local com índice, cache e instalação offline por pacote binário

## Estrutura do projeto

```text
usr/pkg/bin/pkg
etc/pkg/pkg.conf
usr/pkg/pkgbuilds/<nome>/pkgbuild
usr/pkg/pkgbuilds/<nome>/patches/
usr/pkg/pkgbuilds/<nome>/files/
usr/pkg/pkgbuilds/<nome>/hooks/
docs/
tests/
```

## Leituras recomendadas

- `docs/INSTALLATION_AND_QUICKSTART.md`
- `docs/CONFIG_REFERENCE.md`
- `docs/RECIPE_REFERENCE.md`
- `docs/OPERATIONS_AND_AUDIT.md`
- `docs/TESTING.md`

## Instalação rápida

```bash
cp -a usr/pkg /usr/
mkdir -p /etc/pkg
cp -a etc/pkg/pkg.conf /etc/pkg/pkg.conf
ln -sf /usr/pkg/bin/pkg /usr/bin/pkg
```

## Exemplo mínimo de uso

```bash
pkg install example-hello
pkg list
pkg info example-hello
pkg files example-hello
pkg verify example-hello
pkg remove example-hello
```

## Estado local

Pacotes instalados ficam em:

```text
/var/lib/pkg/installed/<pacote>/
```

Logs ficam em:

```text
/var/log/pkg/<pacote>/
```

Snapshots ficam em:

```text
/var/lib/pkg/snapshots/<pacote>/
```

## Cobertura de testes

A árvore inclui uma suíte principal em `tests/run-tests.sh`. Ela cria um `PKG_SYSROOT` temporário e exercita o gerenciador sem tocar no sistema real.

Cobertura desta etapa:
- verify cruzando manifesto, metadados e ownership
- owner com canonicalização e detecção de múltiplos owners
- snapshots com metadados e hashes de auditoria
- rollback registrando metadados de restauração
- depends + provides + rdeps
- autoremove
- conflito por manifesto/ownership
- replace com conflito explícito
- upgrade e rollback
- bloqueio de sobrescrita não rastreada
- patch automático
- hooks
- preservação de arquivos de configuração com `.new`
- fonte `git+` com checksum determinístico
- empacotamento binário (`pkg pack`) e instalação por índice (`pkg install-bin`)
- persistência de metadados de integração: system users, tmpfiles, unidades e alternativas

## Correções importantes desta etapa

- checksum de fonte `git+` agora é determinístico por árvore de arquivos, e não por tarball ad-hoc
- `post_build` agora roda antes de `package()`, o que corrige receitas que geram artefatos entre build e stage
- `reinstall` agora usa o `pkg_name` real da receita para recuperar `install_reason`
- a poda de snapshots remove também os metadados `.db` antigos
- `apply_patches` agora exige `patch` explicitamente

## Escopo e limites

`pkg` continua sendo um gerenciador pessoal simples. Ainda não é um solver transacional global nem um gerenciador com ownership compartilhado completo. O design é intencionalmente conservador.


## Novos comandos e integrações

- `pkg pack <receita> [repo-dir]`
- `pkg install-bin <arquivo|url|pacote> [repo-dir]`
- `pkg repo-index [repo-dir]`
- `pkg repo-list [repo-dir]`
- `pkg logs <pacote> [latest|path|main|install|build|download|patch|hook]`
- `pkg diagnose <pacote> [latest|error|path]`
- `pkg history`

No plano de integração pós-instalação, o `pkg` agora consegue aplicar sysusers/tmpfiles, habilitar ou desabilitar unidades systemd e disparar refresh global de caches usuais de desktop/toolchain quando os binários estiverem disponíveis no host.

## Estado local

Os metadados dos pacotes instalados agora registram contagens de arquivos, diretórios, configs, depends, provides, system users, tmpfiles, unidades systemd e alternativas. Remoções preservam uma cópia do banco e dos logs em `PKG_REMOVED_DB_ROOT`.

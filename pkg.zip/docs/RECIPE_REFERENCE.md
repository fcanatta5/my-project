# Referência de receitas

## Layout

Cada receita fica em:

```text
/usr/pkg/pkgbuilds/<nome>/
  pkgbuild
  patches/
  files/
  hooks/
```

## Variáveis suportadas

### Identidade
- `pkg_name`
- `pkg_version`
- `pkg_release`
- `pkg_desc`
- `pkg_homepage`
- `pkg_license`

### Fontes
- `pkg_sources=( ... )`
- `pkg_sha256s=( ... )`

Regras:
- a quantidade de entradas em `pkg_sources` e `pkg_sha256s` deve coincidir
- para fonte local ou remota, use SHA-256 do arquivo baixado
- para `git+`, use o SHA-256 determinístico da árvore de arquivos clonada, ou `SKIP`

Formatos aceitos em `pkg_sources`:
- caminho local: `"/tmp/foo-1.0.tar.gz"`
- URL HTTP/HTTPS: `"https://example.org/foo-1.0.tar.gz"`
- Git: `"git+https://example.org/repo.git#ref=v1.2.3"`
- Git local: `"git+/srv/git/foo#ref=main"`

## Dependências e relacionamento

- `pkg_depends=( ... )`
- `pkg_build_depends=( ... )`
- `pkg_conflicts=( ... )`
- `pkg_provides=( ... )`
- `pkg_replaces=( ... )`

Exemplo real com `provides`:

```bash
pkg_name="libressl"
pkg_provides=("openssl")
```

Exemplo real com `replaces` e `conflicts`:

```bash
pkg_name="newfoo"
pkg_conflicts=("oldfoo")
pkg_replaces=("oldfoo")
```

## Patches

### Automáticos
Qualquer arquivo em `patches/*.patch` ou `patches/*.diff` é aplicado automaticamente com `patch -p1`.

### Declarados
Você também pode listar patches extras em `pkg_patches=( ... )` com caminhos relativos à receita.

## Arquivos de configuração

Use `pkg_config_files` para marcar arquivos que devem ser preservados em upgrades:

```bash
pkg_config_files=(
  "/etc/foo/foo.conf"
)
```

Se o arquivo já existir no sistema e estiver diferente do novo arquivo staged:
- o arquivo atual é preservado
- o novo arquivo é instalado como `.new`

## Funções suportadas

- `prepare`
- `build`
- `package`
- `pre_fetch`
- `post_fetch`
- `pre_patch`
- `post_patch`
- `pre_build`
- `post_build`
- `pre_install`
- `post_install`

Ordem simplificada do pipeline:
1. `pre_fetch`
2. fetch/extract
3. `post_fetch`
4. `pre_patch`
5. patches
6. `post_patch`
7. `pre_build`
8. `prepare`
9. `build`
10. `post_build`
11. `package`
12. `pre_install`
13. sync para `PKG_SYSROOT`
14. `post_install`

## Hooks externos

Além de funções no `pkgbuild`, você pode usar scripts externos em `hooks/`:
- `hooks/pre_fetch.sh`
- `hooks/post_fetch.sh`
- `hooks/pre_patch.sh`
- `hooks/post_patch.sh`
- `hooks/pre_build.sh`
- `hooks/post_build.sh`
- `hooks/pre_install.sh`
- `hooks/post_install.sh`

Eles recebem o ambiente exportado pelo `pkg`, incluindo:
- `PKG_DESTDIR`
- `PKG_WORKDIR`
- `PKG_SRCDIR`
- `PKG_RECIPE_DIR`
- `PKG_LOGDIR`
- `PKG_SYSROOT`

## Exemplo 1 — pacote simples de arquivo pronto

```bash
pkg_name="hello-bin"
pkg_version="1.0"
pkg_release="1"
pkg_desc="Hello world em shell"
pkg_homepage="https://example.invalid/hello-bin"
pkg_license="MIT"

pkg_sources=("/tmp/hello-bin-1.0.tar.gz")
pkg_sha256s=("<sha256>")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() {
  :
}

package() {
  mkdir -p "$PKG_DESTDIR/usr/bin"
  install -m0755 hello "$PKG_DESTDIR/usr/bin/hello"
}
```

## Exemplo 2 — pacote autotools

```bash
build() {
  ./configure "${PKG_CONFIGURE_FLAGS[@]}"
  make
}

package() {
  make DESTDIR="$PKG_DESTDIR" install
}
```

## Exemplo 3 — pacote com patch automático e config file

```bash
pkg_config_files=("/etc/myapp.conf")

build() {
  ./configure --prefix=/usr --sysconfdir=/etc
  make
}

package() {
  make DESTDIR="$PKG_DESTDIR" install
}
```

Se houver `patches/fix-build.patch`, ele será aplicado automaticamente.


## Integração com serviços do sistema

Além do manifesto de arquivos, a receita pode declarar metadata operacional de sistema:

- `pkg_system_users=( ... )`
- `pkg_tmpfiles=( ... )`
- `pkg_systemd_units_enable=( ... )`
- `pkg_systemd_units_disable=( ... )`
- `pkg_alternatives=( ... )`

Formato esperado:

```bash
pkg_system_users=(
  "u mysvc - "My Service" /var/lib/mysvc"
)

pkg_tmpfiles=(
  "d /var/lib/mysvc 0750 mysvc mysvc -"
)

pkg_systemd_units_enable=(
  "mysvc.service"
  "mysvc.timer"
)

pkg_systemd_units_disable=(
  "legacy-mysvc.service"
)

pkg_alternatives=(
  "editor|/usr/bin/editor|/usr/bin/vim|100"
)
```

Cada entrada de `pkg_alternatives` usa o formato:

```text
nome|link|caminho-real|prioridade
```

Esses dados são gravados no banco instalado e também seguem para o pacote binário gerado por `pkg pack`.

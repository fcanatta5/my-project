# Testes automatizados

## Objetivo

A suíte testa o `pkg` num `PKG_SYSROOT` temporário e não toca no sistema real.

## Execução

```bash
cd tests
./run-tests.sh
```

## Cobertura atual

### Núcleo de dependências
- install com `--deps`
- satisfação por `provides`
- `rdeps`
- `autoremove`

### Segurança de ownership
- conflito por manifesto
- bloqueio de sobrescrita de arquivo não rastreado
- `replace` com conflito explícito

### Ciclo de manutenção
- `upgrade`
- `rollback`

### Endurecimento adicional
- patch automático
- hooks de função e de arquivo
- preservação de config como `.new`
- fonte `git+` com checksum determinístico

## Como a suíte funciona

A suíte:
1. cria um diretório temporário
2. monta um sysroot falso
3. escreve um `pkg.conf` isolado
4. gera receitas sintéticas
5. cria fontes locais tar e repositórios git locais
6. executa os comandos do `pkg`
7. valida arquivos, banco local, snapshots e logs

## Adicionando novos testes

Padrão recomendado:
- criar uma receita sintética pequena
- usar apenas fontes locais
- evitar acesso à internet
- validar o estado final no sysroot e no banco
- validar o caminho de erro quando aplicável

## Casos úteis para ampliar depois
- múltiplas fontes misturando tarball + arquivo local + git
- hooks `pre_fetch`, `post_patch`, `pre_install`
- symlinks e permissões especiais
- receitas sem `build()` quando `PKG_REQUIRE_BUILD_FUNCTION=0`
- pacotes com vários arquivos de configuração

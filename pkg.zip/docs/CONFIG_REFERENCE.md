# Referência de configuração

O arquivo principal é `/etc/pkg/pkg.conf`.

## Caminhos principais

### `PKG_ROOT`
Raiz lógica do sistema. Mantido para compatibilidade de desenho, mas o fluxo principal usa `PKG_SYSROOT`.

### `PKG_SYSROOT`
Raiz efetiva de instalação. Em produção normalmente `/`. Em testes pode ser um diretório temporário.

### `PKG_DB_ROOT`
Raiz do banco local. Os pacotes instalados ficam em `PKG_DB_ROOT/installed/<pacote>/`.

### `PKG_STATE_ROOT`
Reservado para estado interno adicional.

### `PKG_LOCK_ROOT`
Diretório dos locks por pacote.

### `PKG_LOG_ROOT`
Diretório base dos logs por operação.

### `PKG_CACHE_ROOT`
Cache de fontes baixadas/clonadas.

### `PKG_TMP_ROOT`
Área temporária de trabalho e stage.

### `PKG_RECIPES_ROOT`
Diretório onde ficam as receitas.

### `PKG_BINARY_ARCHIVE_ROOT`
Diretório para arquivos binários de stage, caso `PKG_CREATE_BINARY_ARCHIVE=1`.

### `PKG_SNAPSHOT_ROOT`
Diretório base dos snapshots usados para rollback.

## Segurança e política de instalação

### `PKG_PROTECTED_PATHS`
Lista de caminhos protegidos contra limpeza agressiva. Evita `rm -rf` em diretórios críticos.

### `PKG_ALLOWED_INSTALL_PREFIXES`
Prefixos onde arquivos do stage podem ser instalados. Isso endurece o manifesto.

### `PKG_ALLOW_INSECURE_HTTP`
Reservado para políticas de fetch. Nesta versão, o controle fino ainda não é aplicado em todos os fluxos.

### `PKG_BUILD_UMASK`
`umask` aplicado durante o build.

### `PKG_BUILD_USER`
Documenta a intenção de executar builds como usuário dedicado. Nesta versão o script não troca efetivamente de usuário.

## Flags de compilação

### `PKG_JOBS`
Número de jobs paralelos.

### `PKG_CFLAGS`, `PKG_CXXFLAGS`, `PKG_CPPFLAGS`, `PKG_LDFLAGS`
Exportadas para o ambiente de build.

### `PKG_MAKEFLAGS`
Também exportada automaticamente.

### `PKG_CONFIGURE_FLAGS`, `PKG_CMAKE_FLAGS`, `PKG_MESON_FLAGS`
Flags globais para receitas usarem explicitamente.

Exemplo real:

```bash
PKG_CONFIGURE_FLAGS=(
  "--prefix=/usr"
  "--sysconfdir=/etc"
  "--localstatedir=/var"
)
```

Na receita:

```bash
build() {
  ./configure "${PKG_CONFIGURE_FLAGS[@]}"
  make
}
```

## Download e fetch

### `PKG_DOWNLOAD_TOOL`
`curl` ou `wget`.

### `PKG_FETCH_RETRIES`
Número de tentativas para download.

### `PKG_FETCH_TIMEOUT`
Timeout de conexão.

### `PKG_DEFAULT_GIT_CLONE_DEPTH`
Profundidade padrão para clone de fontes `git+`.

## Comportamento operacional

### `PKG_KEEP_WORKDIR`
Se `1`, preserva diretório de trabalho.

### `PKG_KEEP_STAGE`
Se `1`, preserva stage no fim do build.

### `PKG_VERBOSE`
Reservado para variações futuras de verbosidade.

### `PKG_ASSUME_YES`
Reservado para prompts futuros.

### `PKG_STRIP_BINARIES`
Reservado para strip automático.

### `PKG_AUTO_APPLY_PATCHES`
Se `1`, aplica `patches/*.patch` e `patches/*.diff` automaticamente.

### `PKG_EXPORT_BUILD_ENV`
Se `1`, exporta e registra o ambiente usado no build.

### `PKG_CLEAN_ENV_AFTER_BUILD`
Se `1`, limpa variáveis do ambiente após a operação.

### `PKG_HOOKS_ENABLED`
Habilita hooks externos e de função.

### `PKG_LOG_TO_SCREEN`
Mostra logs também na tela.

### `PKG_LOG_DATE_FORMAT`
Formato do timestamp.

### `PKG_COLOR`
Habilita cores.

### `PKG_ARCHIVE_BUILDS`
Reservado.

### `PKG_CREATE_BINARY_ARCHIVE`
Se `1`, cria um tar do stage final.

### `PKG_INSTALL_TOOL`
Reservado. O fluxo atual usa `cp -a`.

### `PKG_REQUIRE_BUILD_FUNCTION`
Se `1`, exige `build()` mesmo que a receita só empacote arquivos prontos.

### `PKG_AUTOREMOVE_ON_REMOVE`
Se `1`, chama `autoremove` após `remove`.

### `PKG_SEARCH_IN_DESCRIPTIONS`
Inclui `pkg_desc` em `pkg search`.

### `PKG_MAX_SNAPSHOTS_PER_PACKAGE`
Limita snapshots por pacote.

### `PKG_ALLOW_UNOWNED_OVERWRITE`
Se `0`, recusa sobrescrever arquivo existente sem owner registrado no banco.

### `PKG_ALLOW_REPLACE_WITHOUT_CONFLICTS`
Se `0`, `replaces` exige também conflito explícito.

### `PKG_STRICT_OWNERSHIP`
Política estrita para ownership registrado. A remoção preserva arquivo se o owner no banco já mudou.


## Integração systemd e pós-instalação

### `PKG_SYSTEMD_INTEGRATION`
Se `1`, habilita a camada de integração com `systemd-sysusers`, `systemd-tmpfiles`, `systemctl` e triggers globais.

### `PKG_SYSTEMD_SYSUSERS_BIN`, `PKG_SYSTEMD_TMPFILES_BIN`, `PKG_SYSTEMCTL_BIN`
Permitem sobrescrever os caminhos dos binários do ecossistema systemd.

### `PKG_ENABLE_SYSTEMD_UNITS_ON_INSTALL`
Se `1`, aplica `enable`/`disable` para unidades declaradas no pacote durante a instalação.

### `PKG_LDCONFIG_BIN`, `PKG_UPDATE_ICON_CACHE_BIN`, `PKG_UPDATE_MIME_DB_BIN`
Binários dos triggers globais para toolchain e desktop.

### `PKG_GDK_PIXBUF_QUERYLOADERS_BIN`, `PKG_INSTALL_INFO_BIN`, `PKG_MANDb_BIN`
Binários auxiliares para regeneração de cache do GDK Pixbuf, diretório `info` e base do `man-db`.

### `PKG_UPDATE_ALTERNATIVES_BIN`
Binário do sistema de alternativas.

## Repositório binário

### `PKG_BINARY_REPO_ROOT`
Raiz do repositório binário local. O índice fica em `index.tsv` e os pacotes em `packages/<nome>/`.

### `PKG_BINARY_INDEX_FILE`
Caminho completo do índice binário.

### `PKG_BINARY_CACHE_ROOT`
Cache para pacotes binários baixados por URL.

### `PKG_SOURCE_ARCHIVE_ROOT`
Diretório onde `pkg pack` grava o source package separado.


Observação sobre repositório binário
--------------------------------
O índice `index.tsv` agora prefere caminhos relativos ao diretório do repositório. Isso permite mover ou copiar o repositório binário para outro local e continuar usando `pkg install-bin <pacote> <repo-dir>` offline. Quando há múltiplas versões do mesmo pacote no índice, a resolução por nome escolhe a maior combinação `versão-release`.

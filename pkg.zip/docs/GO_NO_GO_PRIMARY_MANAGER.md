# Go/No-Go para uso como gerenciador principal

Esta bateria existe para responder uma pergunta operacional objetiva: **o bundle está forte o suficiente para assumir o papel de gerenciador principal do ambiente?**

## Regra de decisão

O veredito é **GO** apenas quando todos os gates críticos passam. Qualquer falha em um gate crítico produz **NO-GO**.

## Gates críticos

### 1. Integridade estrutural mínima
- sintaxe do `usr/pkg/bin/pkg`
- sintaxe de todos os scripts de teste `.sh`
- presença de `README.md`, `docs/TESTING.md` e `etc/pkg/pkg.conf`
- estrutura mínima obrigatória presente na árvore

### 2. Hardening de entrada e configuração
- rejeição de configurações absolutas não canônicas
- rejeição de paths derivados não canônicos
- validação de `pkg_name`, deps/provides/conflicts/replaces e arquivos de configuração

### 3. Segurança de pacote binário e repositório
- rejeição de path traversal antes da extração
- rejeição de symlink perigoso antes da extração
- rejeição de manifesto incompatível com o payload
- rejeição de drift entre manifesto declarado e payload real
- funcionamento do dispatcher `repo-index` / `repo-list`
- hardening do path do índice do repositório

### 4. Integridade de fontes e solver
- integridade determinística de `git+`
- providers/snapshots
- `replaces` e conflitos sob regras explícitas
- sanity de release

### 5. Segurança transacional e recuperação
- rollback imediato
- upgrade com rollback
- cleanup/recovery em prontidão
- stress operacional
- interrupção abrupta repetida
- autocura de resíduo de runtime
- PID estrangeiro ignorado corretamente pela recovery
- rollback em falha transacional
- contenção de locks em recovery
- retenção de lock transacional
- preservação de multi-lock parcial
- limpeza de tx stale
- cleanup metadata em sucesso
- crash recovery com ownership compartilhado
- conflito de ownership em rollback
- colisão de runtime id
- remoção fast-path de caminho ausente
- telemetria operacional
- aceitação restrita de diretórios-pai implícitos

## Script oficial desta bateria

```bash
bash tests/run-go-no-go-primary-manager-r33.sh
```

## Saída esperada

A execução gera:

- `QA_RESULTS_R33/REPORT_R33.tsv`
- `QA_RESULTS_R33/SUMMARY_R33.txt`
- `QA_RESULTS_R33/VERDICT_R33.txt`

## Interpretação

- **GO**: pronto para homologação forte e uso como gerenciador principal dentro do escopo do projeto.
- **NO-GO**: não promover até corrigir a causa e repetir a bateria completa.


## Reforço R34

A revisão R34 endurece a decisão de promoção com um modelo em três camadas:

1. **Estrutural e smoke atual**
   - sintaxe do entrypoint e da suíte `.sh`
   - presença da documentação/configuração mínima
   - `pkg help` funcionando no bundle final

2. **Evidência viva crítica R34**
   - blocker gates essenciais executados nesta revisão e armazenados em `QA_RESULTS_R34_LIVE/`
   - o verificador R34 falha se qualquer log estiver ausente, vazio ou contiver `FAIL`, `ERROR` ou `Terminated`

3. **Cobertura estendida herdada R32**
   - gates mais longos continuam obrigatórios, mas a validação ocorre por conferência explícita do `QA_RESULTS_R32/SUMMARY_R32.txt`
   - isso reduz fragilidade operacional sem perder cobertura de promoção

### Script oficial mais forte

```bash
bash tests/run-go-no-go-primary-manager-r34.sh
```

### Saída R34

- `QA_RESULTS_R34_LIVE/SUMMARY_R34_LIVE.txt`
- `QA_RESULTS_R34/REPORT_R34.tsv`
- `QA_RESULTS_R34/SUMMARY_R34.txt`
- `QA_RESULTS_R34/VERDICT_R34.txt`
- `QA_RESULTS_R34/CRITICAL_SHA256_R34.txt`

### Regra operacional R34

- **GO**: zero FAIL em estrutura/smoke, evidência viva crítica e cobertura estendida.
- **NO-GO**: qualquer inconsistência nessas três camadas.


## R35 Production Sealed

A revisão R35 converte a bateria em um **harness único reexecutável**, pensado para decisão conservadora de promoção a gerenciador principal.

### O que o R35 exige

1. **Execução limpa em um único harness**
   - `tests/run-go-no-go-primary-manager-r35.sh` executa todos os gates críticos com timeout por etapa
   - o veredito é derivado apenas da execução desta revisão

2. **Rollback realmente exercitado**
   - rollback imediato em falha de `post_install`
   - falha transacional com lock e rollback preservado

3. **Recovery após falha realmente exercitado**
   - contenção de lock em recovery
   - limpeza de `tx` stale
   - PID estrangeiro ignorado corretamente

4. **Matriz de ambiente mais ampla**
   - profile `baseline`: `umask 022`, `LC_ALL=C`
   - profile `hardened`: `umask 077`, `LC_ALL=C.UTF-8`
   - profile `portable`: `umask 022`, `LC_ALL=POSIX`

5. **Manifesto imutável e selo final**
   - `QA_RESULTS_R35_SEALED/MANIFEST_IMMUTABLE_R35.sha256`
   - `QA_RESULTS_R35_SEALED/SEAL_R35.txt`
   - qualquer alteração posterior em arquivo manifestado invalida o selo

### Script oficial sealed

```bash
bash tests/run-go-no-go-primary-manager-r35.sh
```

### Saída R35

- `QA_RESULTS_R35_SEALED/REPORT_R35.tsv`
- `QA_RESULTS_R35_SEALED/SUMMARY_R35.txt`
- `QA_RESULTS_R35_SEALED/VERDICT_R35.txt`
- `QA_RESULTS_R35_SEALED/MANIFEST_IMMUTABLE_R35.sha256`
- `QA_RESULTS_R35_SEALED/SEAL_R35.txt`

### Regra operacional R35

- **GO**: zero FAIL em todo o harness único R35.
- **NO-GO**: qualquer FAIL estrutural, funcional, transacional, de recovery ou de matriz.

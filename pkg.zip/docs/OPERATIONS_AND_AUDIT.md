# Operações, manutenção e auditoria

## Fluxos operacionais

## Instalar uma receita

```bash
pkg install foo
```

Fluxo interno:
1. carrega receita
2. cria lock por pacote
3. limpa workdir
4. baixa/clona/copía fontes
5. valida checksum
6. extrai fontes
7. aplica patches
8. exporta ambiente
9. executa hooks/funções de build
10. gera stage em `PKG_DESTDIR`
11. cria manifesto
12. verifica dependências declaradas já instaladas
13. valida conflitos de manifesto, ownership, replaces e conflicts
14. sincroniza stage para `PKG_SYSROOT`
15. salva banco local
16. grava logs

## Instalar com dependências conhecidas

```bash
pkg install --deps foo
```

O resolvedor é propositalmente simples:
- usa `pkg_depends`
- aceita dependência satisfeita por nome do pacote ou por `provides`
- instala em ordem topológica simples
- não é solver SAT

## Atualizar

```bash
pkg upgrade foo
```

Comportamento:
- gera snapshot do pacote instalado antes de remover seus arquivos
- remove arquivos antigos do próprio pacote
- preserva configs modificadas com `.new`
- instala nova versão
- substitui pacotes listados em `pkg_replaces`

## Reinstalar

```bash
pkg reinstall foo
```

Usa a receita atual e preserva o `install_reason` do pacote já instalado.

## Remover

```bash
pkg remove foo
```

Regras:
- recusa remoção se houver reverse dependencies instaladas
- gera snapshot antes de remover
- remove apenas arquivos do manifesto daquele pacote
- preserva arquivo se o owner no banco já mudou
- tenta remover diretórios vazios, exceto os protegidos

## Autoremove

```bash
pkg orphan
pkg autoremove
```

Um pacote é órfão quando:
- `install_reason=dependency`
- nenhum pacote instalado depende dele

## Rollback

```bash
pkg rollback foo latest
```

O rollback é simples:
- reextrai o snapshot tar na `PKG_SYSROOT`
- restaura também o diretório `.db` do pacote, quando existir

Limites importantes:
- não é transação global do sistema
- não reverte efeitos de hooks externos fora do manifesto
- não restaura arquivos não rastreados

## Auditoria prática

## Ver o que está instalado

```bash
pkg list
```

## Ver metadados de um pacote

```bash
pkg info foo
```

## Ver manifesto de arquivos

```bash
pkg files foo
```

## Descobrir dono de um arquivo

```bash
pkg owner /usr/bin/foo
```

## Verificar integridade

```bash
pkg verify foo
```

Isso detecta:
- arquivo ausente
- checksum alterado
- ownership inconsistente do manifesto
- múltiplos owners para o mesmo caminho
- divergência entre contagens do manifesto e o arquivo `meta`
- entradas inválidas fora dos prefixos permitidos

## Onde auditar manualmente

### Banco local

```text
/var/lib/pkg/installed/<pacote>/
```

Arquivos principais:
- `meta`
- `files`
- `dirs`
- `sha256sums`
- `depends`
- `provides`
- `conflicts`
- `replaces`
- `config_files`

### Logs

```text
/var/log/pkg/<pacote>/<operação>/
```

Arquivos comuns:
- `main.log`
- `download.log`
- `build.log`
- `patch.log`
- `hook.log`
- `install.log`
- `environment.exported`

### Snapshots

```text
/var/lib/pkg/snapshots/<pacote>/
```

Conteúdo:
- `<timestamp>-<reason>.tar`
- `<timestamp>-<reason>.files`
- `<timestamp>-<reason>.manifest`
- `<timestamp>-<reason>.meta`
- `<timestamp>-<reason>.db/`

O arquivo `.meta` do snapshot registra pacote, motivo, hash do archive, hash do manifesto, contagens de arquivos/diretórios e versão/restauração de origem.

## Manutenção recomendada

### 1. Revisar periodicamente receitas locais
- remover URLs mortas
- atualizar checksums
- revisar `depends`, `provides`, `conflicts` e `replaces`

### 2. Verificar pacotes críticos

```bash
pkg verify openssl
pkg verify curl
pkg verify git
```

### 3. Limpar workdirs antigos

```bash
pkg clean foo
```

### 4. Revisar snapshots
- confira tamanho em `/var/lib/pkg/snapshots`
- ajuste `PKG_MAX_SNAPSHOTS_PER_PACKAGE` conforme o espaço em disco

### 5. Conferir logs de falha
Em erro de build ou install, a primeira leitura deve ser:
- `main.log`
- `build.log`
- `patch.log`
- `install.log`
- `hook.log`

## Casos reais de troubleshooting

## Caso 1 — arquivo existe mas não pertence a nenhum pacote
Erro típico:

```text
Conflito de ownership: /usr/bin/foo já existe no sistema mas não pertence a nenhum pacote
```

Ação:
1. auditar origem do arquivo
2. decidir se ele deve ser removido manualmente
3. ou habilitar temporariamente `PKG_ALLOW_UNOWNED_OVERWRITE=1` se a política local permitir

## Caso 2 — replace sem conflito explícito
Erro típico:

```text
replaces exige conflito explícito com oldfoo
```

Ação:
- adicionar `oldfoo` em `pkg_conflicts`
- ou, conscientemente, usar `PKG_ALLOW_REPLACE_WITHOUT_CONFLICTS=1`

## Caso 3 — dependência não satisfeita
Erro típico:

```text
Dependências ausentes para foo
```

Ação:
- instalar a dependência pelo nome real do pacote
- ou criar uma receita que a forneça via `pkg_provides`

## Caso 4 — config file preservado como `.new`
Isso não é erro. Significa que o arquivo em `/etc` foi modificado localmente e o `pkg` preservou a versão do operador.


## Logs, history e remoções auditáveis

- `pkg logs <pacote>` retorna o diretório de logs ativo do pacote instalado ou, se o pacote já tiver sido removido, o diretório mais recente preservado em `PKG_REMOVED_DB_ROOT`.
- `pkg logs <pacote> main|install|build|download|patch|hook` imprime o arquivo de log correspondente.
- `pkg diagnose <pacote> latest` imprime o `operation.meta` mais recente com `operation`, `status`, `exit_code`, `start_time`, `end_time` e `detail`.
- `pkg diagnose <pacote> error` imprime o `last_error.meta` quando a última operação do pacote terminou em falha.
- Em falhas, a saída agora aponta explicitamente para o diretório de logs e permite localizar o caminho novamente com `pkg logs <pacote> path`.
- `pkg history` mostra o histórico global tabulado em `PKG_HISTORY_FILE`.
- Antes de remover um pacote, o `pkg` cria snapshot, copia o banco instalado para `PKG_REMOVED_DB_ROOT/<pacote>/...` e grava `removal.meta` com motivo e data.
- O banco instalado (`meta`) agora inclui contagens de `source_count`, `file_count`, `dir_count`, `config_count`, `depends_count` e `provides_count`.


## Verificações finais de consistência

Nesta etapa o `pkg verify` ficou mais rígido: ele não confere só a presença dos arquivos, mas também se o banco local ainda é coerente com o que está no disco e com o manifesto salvo. Isso ajuda a detectar corrupção silenciosa do banco, `replaces` mal aplicados, ou edição manual incorreta dos metadados.

No rollback, o `meta` restaurado recebe chaves adicionais como `restored_at`, `restored_from_snapshot`, `restored_from_snapshot_db`, `restored_by` e `rollback_log_dir`. Isso fecha a trilha de auditoria de quem restaurou, quando restaurou e de qual snapshot veio a volta.


## Triggers pós-instalação globais

Depois da sincronização do stage e do `post_install`, o `pkg` tenta executar triggers globais baseados no manifesto instalado:

- `ldconfig` para bibliotecas em `/lib`, `/usr/lib`, `/usr/lib64`
- `gtk-update-icon-cache` para temas em `/usr/share/icons/*`
- `update-mime-database` para `/usr/share/mime`
- `gdk-pixbuf-query-loaders` para loaders de pixbuf
- `install-info` para arquivos em `/usr/share/info`
- `mandb` para páginas em `/usr/share/man`

Esses gatilhos não exigem recipe hooks locais e servem como camada global de pós-instalação.

## Pacotes binários e source packages

### Gerar artefatos instaláveis

```bash
pkg pack foo
```

Resultado:
- pacote binário `.pkg.tar.zst` com payload + metadata instalada/instalável
- source package `.src.tar.zst` separado
- atualização do `index.tsv` do repositório local

### Instalar de arquivo, URL ou índice local

```bash
pkg install-bin foo
pkg install-bin /srv/repo/foo-1.2-1.pkg.tar.zst
pkg install-bin https://repo.exemplo.invalid/foo-1.2-1.pkg.tar.zst
```

Esse fluxo cobre rebuild em uma máquina de build e instalação offline em outra máquina a partir do repositório binário exportado.

## Auditoria do formato binário

O pacote binário contém ao menos:
- `./.PKGINFO`
- `./payload/`
- `./meta/`

O diretório `meta/` replica o banco instalado: manifesto, metadata, depends, provides, config files, system users, tmpfiles, unidades e alternativas.


Observação sobre repositório binário
--------------------------------
O índice `index.tsv` agora prefere caminhos relativos ao diretório do repositório. Isso permite mover ou copiar o repositório binário para outro local e continuar usando `pkg install-bin <pacote> <repo-dir>` offline. Quando há múltiplas versões do mesmo pacote no índice, a resolução por nome escolhe a maior combinação `versão-release`.

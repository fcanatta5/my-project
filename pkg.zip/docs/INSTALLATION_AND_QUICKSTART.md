# Instalação e início rápido

## 1. Instalar a árvore

Copie a árvore respeitando a raiz do sistema:

```bash
cp -a usr/pkg /usr/
mkdir -p /etc/pkg
cp -a etc/pkg/pkg.conf /etc/pkg/pkg.conf
ln -sf /usr/pkg/bin/pkg /usr/bin/pkg
```

## 2. Criar diretórios base

Se o seu sistema ainda não tiver os diretórios definidos em `pkg.conf`, crie-os:

```bash
mkdir -p /var/lib/pkg/installed \
         /var/lib/pkg/state \
         /var/lib/pkg/locks \
         /var/lib/pkg/snapshots \
         /var/log/pkg \
         /var/cache/pkg/sources \
         /var/cache/pkg/packages \
         /var/tmp/pkg \
         /usr/pkg/pkgbuilds
```

## 3. Revisar a configuração

Abra `/etc/pkg/pkg.conf` e ajuste pelo menos:
- `PKG_RECIPES_ROOT`
- `PKG_ALLOWED_INSTALL_PREFIXES`
- `PKG_CFLAGS`, `PKG_CXXFLAGS`, `PKG_LDFLAGS`
- `PKG_JOBS`, `PKG_MAKEFLAGS`
- `PKG_LOG_ROOT`, `PKG_DB_ROOT`, `PKG_SNAPSHOT_ROOT`

## 4. Criar sua primeira receita

Estrutura:

```text
/usr/pkg/pkgbuilds/example-hello/
  pkgbuild
  patches/
  files/
  hooks/
```

Exemplo:

```bash
pkg_name="example-hello"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="Programa de teste"
pkg_homepage="https://example.invalid/hello"
pkg_license="MIT"

pkg_sources=(
  "/tmp/example-hello-1.0.0.tar.gz"
)

pkg_sha256s=(
  "<sha256-do-arquivo>"
)

pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() {
  :
}

package() {
  mkdir -p "$PKG_DESTDIR/usr/bin"
  install -m0755 hello "$PKG_DESTDIR/usr/bin/hello"
}
```

## 5. Fluxos básicos

Instalar:

```bash
pkg install example-hello
```

Instalar com dependências de receitas conhecidas:

```bash
pkg install --deps example-hello
```

Atualizar:

```bash
pkg upgrade example-hello
```

Reinstalar:

```bash
pkg reinstall example-hello
```

Remover:

```bash
pkg remove example-hello
```

Rollback:

```bash
pkg rollback example-hello latest
```

## 6. Primeira auditoria

```bash
pkg list
pkg info example-hello
pkg files example-hello
pkg verify example-hello
pkg owner /usr/bin/hello
pkg history
```

`pkg` ainda não tem um subcomando `history`, então a auditoria histórica é feita em `/var/log/pkg` e `/var/lib/pkg/snapshots`.


## 7. Camada systemd/LFS

As receitas agora podem declarar integração de sistema diretamente no `pkgbuild`:

```bash
pkg_system_users=(
  "u mysvc - "My Service" /var/lib/mysvc"
)

pkg_tmpfiles=(
  "d /var/lib/mysvc 0750 mysvc mysvc -"
)

pkg_systemd_units_enable=(
  "mysvc.service"
)

pkg_systemd_units_disable=()

pkg_alternatives=(
  "editor|/usr/bin/editor|/usr/bin/vim|100"
)
```

Quando `PKG_SYSTEMD_INTEGRATION=1`, o `pkg` tenta aplicar:
- `systemd-sysusers`
- `systemd-tmpfiles --create`
- `systemctl --root ... enable/disable`
- triggers globais como `ldconfig`, `gtk-update-icon-cache`, `update-mime-database`, `gdk-pixbuf-query-loaders`, `install-info` e `mandb`

Se algum binário não existir no host, o trigger correspondente é simplesmente ignorado.

## 8. Repositório binário e instalação offline

Gerar pacote binário e source package separado:

```bash
pkg pack example-hello
```

Isso cria:

```text
/var/lib/pkg/repo/packages/<pacote>/<pacote>-<versão>-<release>.pkg.tar.zst
/var/lib/pkg/repo/index.tsv
/var/cache/pkg/source-packages/<pacote>-<versão>-<release>.src.tar.zst
```

Listar índice local:

```bash
pkg repo-list
```

Instalar a partir do índice local/offline:

```bash
pkg install-bin example-hello
```

Instalar a partir de um arquivo binário publicado:

```bash
pkg install-bin /mnt/repo/example-hello-1.0-1.pkg.tar.zst
```

Instalar a partir de URL publicada:

```bash
pkg install-bin https://repo.exemplo.invalid/example-hello-1.0-1.pkg.tar.zst
```


Observação sobre repositório binário
--------------------------------
O índice `index.tsv` agora prefere caminhos relativos ao diretório do repositório. Isso permite mover ou copiar o repositório binário para outro local e continuar usando `pkg install-bin <pacote> <repo-dir>` offline. Quando há múltiplas versões do mesmo pacote no índice, a resolução por nome escolhe a maior combinação `versão-release`.

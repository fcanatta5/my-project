#!/usr/bin/env bash
echo "Hook pós-instalação do example-hello executado"

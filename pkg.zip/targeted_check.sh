#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")" && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-targeted-XXXXXX)"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_ARCHIVE_ROOT="$TEST_ROOT/packages"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /usr/local /opt /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_CONFIGURE_FLAGS=("--prefix=/usr")
PKG_KEEP_WORKDIR=1
CFG
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
run_pkg_keep(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
mk_tar_src(){ local name="$1"; local d="$SOURCES/$name-src"; mkdir -p "$d"; printf '%s\n' "$name source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$name.tar.gz"|awk '{print $1}'; }
echo '[1/4] upgrade/clean path'
# alpha for upgrade/clean
sum=$(mk_tar_src alpha-1.0.0)
mkdir -p "$RECIPES/alpha/patches" "$RECIPES/alpha/hooks" "$RECIPES/alpha/files"
cat > "$RECIPES/alpha/pkgbuild" <<PKG
pkg_name="alpha"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="alpha"
pkg_sources=("$SOURCES/alpha-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf 'a1\n' > "\$PKG_DESTDIR/usr/bin/alpha"; }
PKG
run_pkg install alpha >/dev/null
sum=$(mk_tar_src alpha-1.1.0)
cat > "$RECIPES/alpha/pkgbuild" <<PKG
pkg_name="alpha"
pkg_version="1.1.0"
pkg_release="1"
pkg_desc="alpha"
pkg_sources=("$SOURCES/alpha-1.1.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf 'a2\n' > "\$PKG_DESTDIR/usr/bin/alpha"; }
PKG
run_pkg upgrade alpha >/dev/null
grep -Fq 'a2' "$SYSROOT/usr/bin/alpha"
run_pkg_keep build alpha >/dev/null
alpha_workdir="$(find "$TMPROOT" -maxdepth 1 -mindepth 1 -type d -name "alpha-1.1.0-1-*" | sort | tail -n1)"
[[ -n "$alpha_workdir" ]]
[[ -f "$alpha_workdir/primary_source_dir" ]]
run_pkg clean alpha >/tmp/clean1.out
run_pkg clean alpha >/tmp/clean2.out
[[ -z "$(find "$TMPROOT" -mindepth 1 -print -quit 2>/dev/null || true)" ]]
echo '[2/4] single-file source path'
# single file source
mkdir -p "$RECIPES/singlefilepkg/patches" "$RECIPES/singlefilepkg/hooks" "$RECIPES/singlefilepkg/files"
printf 'single-file-payload\n' > "$SOURCES/singlefilepkg-1.0.0.txt"
sum=$(sha256sum "$SOURCES/singlefilepkg-1.0.0.txt"|awk '{print $1}')
cat > "$RECIPES/singlefilepkg/pkgbuild" <<PKG
pkg_name="singlefilepkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="single"
pkg_sources=("$SOURCES/singlefilepkg-1.0.0.txt")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ test -f singlefilepkg-1.0.0.txt; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/singlefilepkg"; cp -f singlefilepkg-1.0.0.txt "\$PKG_DESTDIR/usr/share/singlefilepkg/payload.txt"; }
PKG
run_pkg install singlefilepkg >/dev/null
grep -Fq 'single-file-payload' "$SYSROOT/usr/share/singlefilepkg/payload.txt"
echo '[3/4] pre_fetch hook path'
# pre_fetch env
mkdir -p "$RECIPES/prefetchhook/patches" "$RECIPES/prefetchhook/hooks" "$RECIPES/prefetchhook/files"
sum=$(mk_tar_src prefetchhook-1.0.0)
cat > "$RECIPES/prefetchhook/hooks/pre_fetch.sh" <<'HOOK'
#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$PKG_SYSROOT/var/lib/prefetch-hook"
printf '%s\n' "$PKG_WORKDIR" > "$PKG_SYSROOT/var/lib/prefetch-hook/workdir.txt"
HOOK
chmod +x "$RECIPES/prefetchhook/hooks/pre_fetch.sh"
cat > "$RECIPES/prefetchhook/pkgbuild" <<PKG
pkg_name="prefetchhook"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="hook"
pkg_sources=("$SOURCES/prefetchhook-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/prefetchhook"; printf ok > "\$PKG_DESTDIR/usr/share/prefetchhook/installed.txt"; }
PKG
run_pkg install prefetchhook >/dev/null
grep -Fq "$TMPROOT/prefetchhook-1.0.0-1" "$SYSROOT/var/lib/prefetch-hook/workdir.txt"
echo '[4/4] insecure-http policy path'
# insecure http
mkdir -p "$RECIPES/insecurehttp/patches" "$RECIPES/insecurehttp/hooks" "$RECIPES/insecurehttp/files"
cat > "$RECIPES/insecurehttp/pkgbuild" <<'PKG'
pkg_name="insecurehttp"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="http"
pkg_sources=("http://example.com/insecurehttp-1.0.0.tar.gz")
pkg_sha256s=("SKIP")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ :; }
PKG
if run_pkg install insecurehttp >/tmp/http.out 2>&1; then echo should-fail; exit 1; fi
grep -R -Fq 'Fonte HTTP insegura bloqueada' "$LOGROOT"
echo 'OK'

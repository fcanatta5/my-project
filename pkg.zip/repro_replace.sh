#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT=/mnt/data/workproj
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-repro-XXXXXX)"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$SYSROOT/etc" "$SYSROOT/var/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_ARCHIVE_ROOT="$TEST_ROOT/packages"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_CONFIGURE_FLAGS=("--prefix=/usr")
PKG_ALLOW_REPLACE_WITHOUT_CONFLICTS=0
PKG_STRICT_OWNERSHIP=1
CFG
mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}
write_basic_recipe() {
  local recipe="$1" version="$2" release="$3" desc="$4" depends="$5" provides="$6" conflicts="$7" replaces="$8" body="$9"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$desc"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=($replaces)
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
write_basic_recipe oldname 1.0.0 1 "legacy package" "" '"legacy-virtual"' "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "old\\n" > "$PKG_DESTDIR/usr/bin/legacy-tool"'
write_basic_recipe newname 2.0.0 1 "replacement package" "" '"legacy-virtual"' '"oldname"' '"oldname"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "new\\n" > "$PKG_DESTDIR/usr/bin/legacy-tool"'
set -x
run_pkg install oldname
run_pkg install newname
printf '\nROOT=%s\n' "$TEST_ROOT"
find "$TEST_ROOT" -maxdepth 4 | sort

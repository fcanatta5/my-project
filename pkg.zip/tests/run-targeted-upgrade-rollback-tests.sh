#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-upgrade-rollback-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" release="$3" body="$4"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe upgrade/rollback test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe alpha 2.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "alpha-v2\\n" > "$PKG_DESTDIR/usr/bin/alpha"'
run_pkg install alpha >/dev/null
write_recipe alpha 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "alpha-v1\\n" > "$PKG_DESTDIR/usr/bin/alpha"'
if run_pkg upgrade alpha >/dev/null 2>&1; then
  fail "upgrade deveria recusar downgrade silencioso"
fi
assert_file_contains "$SYSROOT/usr/bin/alpha" 'alpha-v2'
pass "upgrade recusa downgrade de versão/release"

write_recipe beta 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "beta\\n" > "$PKG_DESTDIR/usr/bin/beta"'
write_recipe gamma 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "gamma\\n" > "$PKG_DESTDIR/usr/bin/gamma"'
run_pkg install beta >/dev/null
run_pkg install gamma >/dev/null
beta_snap="$(find "$SNAPROOT/beta" -maxdepth 1 -type f -name '*.tar' | sort | tail -n1 || true)"
if [[ -z "$beta_snap" ]]; then
  run_pkg reinstall beta >/dev/null
  beta_snap="$(find "$SNAPROOT/beta" -maxdepth 1 -type f -name '*.tar' | sort | tail -n1)"
fi
assert_file "$beta_snap"
if run_pkg rollback gamma "$beta_snap" >/dev/null 2>&1; then
  fail "rollback deveria rejeitar snapshot de outro pacote"
fi
assert_file_contains "$SYSROOT/usr/bin/gamma" 'gamma'
assert_not_exists "$DBROOT/installed/gamma/meta.tmp"
pass "rollback valida pertencimento do snapshot ao pacote solicitado"

echo "Todos os testes de upgrade/rollback passaram em $TEST_ROOT"

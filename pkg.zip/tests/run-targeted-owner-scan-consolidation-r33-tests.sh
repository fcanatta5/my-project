#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r33-owner-scan-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_eq(){ [[ "$1" == "$2" ]] || fail "esperado '$1' == '$2'"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT/installed" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
mkpkg(){
  local name="$1" file="$2" dir="$3"
  local db="$DBROOT/installed/${name}"
  mkdir -p "$db"
  printf '%s\n' "$file" > "$db/files"
  printf '%s\n' "$dir" > "$db/dirs"
  : > "$db/meta"
}
mkpkg alpha /usr/bin/tool /usr/bin
mkpkg beta /usr/bin/other /usr/share
mkpkg gamma /usr/bin/third /usr/share
owner_file="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" owner /usr/bin/tool)"
assert_eq "$owner_file" alpha
if PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" owner /usr/share >/dev/null 2>&1; then
  fail "owner deveria falhar para múltiplos owners"
else
  rc=$?
  [[ "$rc" -eq 2 ]] || fail "owner para múltiplos owners deveria sair com 2, saiu com $rc"
fi
pass "owner consolidado preserva owner único e ambiguidade multi-owner"
echo "Todos os testes de owner scan r33 passaram em $TEST_ROOT"

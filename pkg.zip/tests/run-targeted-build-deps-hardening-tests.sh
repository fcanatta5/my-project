#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-builddeps-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$2', obtido '$1'"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=1
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" build_depends="$4" provides="$5" body="$6"
  local dir="$RECIPES/$recipe"
  local sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=($build_depends)
pkg_conflicts=()
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe toolchain 1.0.0 '' '' '"virtual/toolchain"' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "toolchain\n" > "$PKG_DESTDIR/usr/lib/toolchain"\n'
write_recipe app 1.0.0 '' '"virtual/toolchain"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app\n" > "$PKG_DESTDIR/usr/bin/app"\n'

if run_pkg build app >/tmp/builddeps_fail.out 2>&1; then
  fail 'build deveria falhar sem build-dependência instalada'
fi
assert_file_contains /tmp/builddeps_fail.out 'Build-dependências ausentes para app'
pass 'cmd_build falha explicitamente quando pkg_build_depends não está satisfeito'

run_pkg install --deps app >/dev/null
assert_file_contains "$SYSROOT/usr/bin/app" 'app'
assert_eq "$(awk 'NF{print $1; exit}' "$DBROOT/installed/app/build_depends")" 'virtual/toolchain'
pass 'install --deps resolve e instala provider de pkg_build_depends antes do alvo'

echo "OK build-deps hardening em $TEST_ROOT"

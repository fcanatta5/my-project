#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTDIR="${OUTDIR:-$(mktemp -d /tmp/pkg-r35-failover-XXXXXX)}"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$OUTDIR"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_gate(){
  local name="$1"
  local script="$2"
  local timeout_s="$3"
  local log="$OUTDIR/${name}.log"
  if timeout "$timeout_s" bash "$REPO_ROOT/$script" >"$log" 2>&1; then
    if grep -Eqi '(^|\s)(FAIL|ERROR|Terminated)(\s|:|$)' "$log"; then
      fail "gate $name contém FAIL/ERROR/Terminated"
    fi
    pass "$name => $(tail -n 1 "$log")"
  else
    local rc=$?
    tail -n 50 "$log" >&2 || true
    fail "gate $name falhou rc=$rc"
  fi
}
run_gate immediate-rollback tests/run-targeted-immediate-rollback-tests.sh 240
run_gate tx-stale-cleanup tests/run-targeted-tx-stale-cleanup-tests.sh 240
echo "Todos os testes selados de rollback/recovery R35 passaram em $OUTDIR"

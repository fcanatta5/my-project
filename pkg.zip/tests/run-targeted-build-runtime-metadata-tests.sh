#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-runtime-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_dir() { [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$1' == '$2'"; }
assert_contains() { grep -Fq "$2" <<<"$1" || fail "texto ausente: $2"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$SYSROOT/etc"
mkdir -p "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
CFG

mk_src_with_basename() {
  local subdir="$1" basename="$2" content="$3"
  mkdir -p "$SOURCES/$subdir"
  printf '%s\n' "$content" > "$SOURCES/$subdir/$basename"
  sha256sum "$SOURCES/$subdir/$basename" | awk '{print $1}'
}

mk_recipe_tar() {
  local name="$1" version="$2"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" provides="$4" body="$5"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_recipe_tar "$recipe-$version" "$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe runtime test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
prepare() {
  printf 'prepare-ran\n' > "\$PKG_WORKDIR/prepare.marker"
}
build() {
  printf 'build-ran\n' > "\$PKG_WORKDIR/build.marker"
}
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

call_func() {
  local func="$1"
  shift
  PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s -- "$func" "$@" <<'INNER'
set -Eeuo pipefail
func="$1"
shift
source <(sed '$d' "$PKG_BIN")
load_config
"$func" "$@"
INNER
}

# 1) resolve_recipe_dep_order, recipe_declares_name_or_provide e solver helpers
write_recipe virtlib 1.0.0 '' '"virtual/solver-lib"' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "lib\n" > "$PKG_DESTDIR/usr/lib/libsolver.so"\n'
write_recipe solverapp 1.0.0 '"virtual/solver-lib"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app\n" > "$PKG_DESTDIR/usr/bin/solverapp"\n'
call_func recipe_declares_name_or_provide virtlib virtlib >/dev/null
call_func recipe_declares_name_or_provide virtlib virtual/solver-lib >/dev/null
order_out="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'INNER'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
order=()
resolve_recipe_dep_order solverapp order
printf '%s\n' "${order[@]}"
INNER
)"
assert_eq "$order_out" $'virtlib\nsolverapp'
pass 'resolve_recipe_dep_order e recipe_declares_name_or_provide cobrem nome e provider de receita'

# 2) run_prepare_build_package/export_build_env/create_manifest/write_metadata end-to-end
# recipe auxiliar para satisfazer build_depends do envpkg
write_recipe tooling 1.0.0 '' '"virtual/tooling"' $'  mkdir -p "$PKG_DESTDIR/usr/lib"
  printf "tooling\n" > "$PKG_DESTDIR/usr/lib/tooling"
'
run_pkg install tooling >/dev/null
write_recipe envpkg 1.0.0 '' '"virtual/envpkg"' $'  mkdir -p "$PKG_DESTDIR/usr/bin" "$PKG_DESTDIR/etc/envpkg"\n  printf "#!/bin/sh\nexit 0\n" > "$PKG_DESTDIR/usr/bin/envpkg"\n  chmod +x "$PKG_DESTDIR/usr/bin/envpkg"\n  printf "key=value\n" > "$PKG_DESTDIR/etc/envpkg/env.conf"\n'
python - "$RECIPES/envpkg/pkgbuild" <<'INNER'
from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text()
s=s.replace('pkg_build_depends=()', 'pkg_build_depends=("virtual/tooling")', 1)
p.write_text(s)
INNER
run_pkg build envpkg >/dev/null
build_dir="$(find "$LOGROOT/envpkg" -mindepth 1 -maxdepth 1 -type d | sort | tail -n1)"
manifest_root="$(find "$TMPROOT" -maxdepth 1 -type d -name 'envpkg-*' | sort | tail -n1)/manifest"
assert_file "$build_dir/environment.exported"
assert_file_contains "$build_dir/environment.exported" 'PKG_DESTDIR='
assert_file_contains "$manifest_root/files" '/usr/bin/envpkg'
assert_file_contains "$manifest_root/files" '/etc/envpkg/env.conf'
assert_file_contains "$manifest_root/meta" 'file_count=2'
assert_file_contains "$manifest_root/meta" 'depends_count=0'
assert_file_contains "$manifest_root/meta" 'build_depends_count=1'
assert_file_contains "$manifest_root/meta" 'provides_count=1'
pass 'run_prepare_build_package, export_build_env, create_manifest e write_metadata geram saída consistente'

# 3) fetch_one_source must not collide for equal basenames
sum_a="$(mk_src_with_basename a common.tar 'alpha source')"
sum_b="$(mk_src_with_basename b common.tar 'beta source')"
fetch_out="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" SUM_A="$sum_a" SUM_B="$sum_b" SRC_A="$SOURCES/a/common.tar" SRC_B="$SOURCES/b/common.tar" bash -s <<'INNER'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
pkg_name='fetchpkg'
CURRENT_LOG_DIR="$PKG_LOG_ROOT/fetchpkg"
mkdir -p "$CURRENT_LOG_DIR"
first="$(fetch_one_source 0 "$SRC_A" "$SUM_A")"
second="$(fetch_one_source 1 "$SRC_B" "$SUM_B")"
printf '%s\n%s\n' "$first" "$second"
INNER
)"
first_path="$(printf '%s\n' "$fetch_out" | sed -n '1p')"
second_path="$(printf '%s\n' "$fetch_out" | sed -n '2p')"
assert_file "$first_path"
assert_file "$second_path"
[[ "$first_path" != "$second_path" ]] || fail 'fetch_one_source colidiu no cache para basenames iguais'
assert_contains "$(cat "$first_path")" 'alpha source'
assert_contains "$(cat "$second_path")" 'beta source'
pass 'fetch_one_source evita colisão de cache entre fontes com mesmo basename'

# 3b) resolve_primary_source_dir must recover when marker is missing but sources are still extracted
write_recipe markerfallback 1.0.0 '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/markerfallback"\n  printf "ok\n" > "$PKG_DESTDIR/usr/share/markerfallback/value"\n'
run_pkg build markerfallback >/dev/null
marker_workdir="$(find "$TMPROOT" -maxdepth 1 -type d -name 'markerfallback-*' | sort | tail -n1)"
rm -f -- "$marker_workdir/primary_source_dir"
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" MARKER_WORKDIR="$marker_workdir" bash -s <<'INNER'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
load_recipe markerfallback
CURRENT_WORKDIR="$MARKER_WORKDIR"
CURRENT_SRC_DIR="$CURRENT_WORKDIR/src"
CURRENT_STAGE_DIR="$CURRENT_WORKDIR/stage"
CURRENT_MANIFEST_DIR="$CURRENT_WORKDIR/manifest"
CURRENT_LOG_DIR="$PKG_LOG_ROOT/markerfallback-reentry"
mkdir -p "$CURRENT_LOG_DIR"
run_prepare_build_package >/dev/null
INNER
assert_file "$marker_workdir/primary_source_dir"
assert_file_contains "$marker_workdir/manifest/files" '/usr/share/markerfallback/value'
pass 'resolve_primary_source_dir recompõe o marcador quando o src já foi extraído'

# 4) install package and validate pkg_* helpers + metadata persistence
run_pkg install envpkg >/dev/null
call_func pkg_declares_name_or_provide envpkg envpkg >/dev/null
call_func pkg_declares_name_or_provide envpkg virtual/envpkg >/dev/null
assert_eq "$(call_func pkg_provides_name virtual/envpkg)" 'envpkg'
call_func pkg_satisfies_dep envpkg >/dev/null
call_func pkg_satisfies_dep virtual/envpkg >/dev/null
assert_eq "$(call_func pkg_meta_value envpkg description)" 'envpkg runtime test'
assert_eq "$(call_func pkg_meta_value envpkg version)" '1.0.0'
assert_file_contains "$DBROOT/installed/envpkg/build_depends" 'virtual/tooling'
assert_file_contains "$DBROOT/installed/envpkg/meta" 'build_depends_count=1'
pass 'pkg_declares_name_or_provide, pkg_provides_name, pkg_satisfies_dep e pkg_meta_value funcionam após instalação'

# 5) pkg_meta_value must preserve = and fail when key is absent
mkdir -p "$DBROOT/installed/metaeq"
cat > "$DBROOT/installed/metaeq/meta" <<'META'
name=metaeq
complex=a=b=c
META
assert_eq "$(call_func pkg_meta_value metaeq complex)" 'a=b=c'
if call_func pkg_meta_value metaeq missing >/dev/null 2>&1; then
  fail 'pkg_meta_value deveria falhar para chave ausente'
fi
pass 'pkg_meta_value preserva valores com = e falha corretamente para chave ausente'

# 6) cleanup_build_env and cleanup_runtime should clean env and workdir, and release_lock should unlock
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'INNER'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
pkg_name='lockpkg'
CURRENT_WORKDIR="$PKG_TMP_ROOT/runtime-case"
CURRENT_STAGE_DIR="$CURRENT_WORKDIR/stage"
CURRENT_SRC_DIR="$CURRENT_WORKDIR/src"
CURRENT_MANIFEST_DIR="$CURRENT_WORKDIR/manifest"
CURRENT_LOG_DIR="$PKG_LOG_ROOT/runtime-case"
mkdir -p "$CURRENT_WORKDIR" "$CURRENT_LOG_DIR"
export_build_env
[[ -n "${PKG_WORKDIR:-}" && -n "${PKG_DESTDIR:-}" ]] || exit 91
acquire_pkg_lock "$pkg_name"
cleanup_build_env
[[ -z "${PKG_WORKDIR:-}" && -z "${PKG_DESTDIR:-}" && -z "${CFLAGS:-}" ]] || exit 92
release_lock
CURRENT_WORKDIR="$PKG_TMP_ROOT/runtime-case"
CURRENT_STAGE_DIR="$CURRENT_WORKDIR/stage"
CURRENT_SRC_DIR="$CURRENT_WORKDIR/src"
CURRENT_MANIFEST_DIR="$CURRENT_WORKDIR/manifest"
CURRENT_LOG_DIR="$PKG_LOG_ROOT/runtime-case"
mkdir -p "$CURRENT_WORKDIR" "$CURRENT_LOG_DIR"
PKG_KEEP_WORKDIR=0
acquire_pkg_lock "lockpkg"
cleanup_runtime
[[ ! -d "$CURRENT_WORKDIR" ]] || exit 93
acquire_pkg_lock "lockpkg"
release_lock
INNER
pass 'export_build_env, cleanup_build_env, cleanup_runtime e release_lock mantêm ambiente e lock consistentes'

echo "Todos os testes focados passaram em $TEST_ROOT"

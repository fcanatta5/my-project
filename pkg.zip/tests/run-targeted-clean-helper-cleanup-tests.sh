#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG="$ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-clean-helper-XXXXXX)"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_ARCHIVE_ROOT="$TEST_ROOT/packages"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /usr/local /opt /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_CONFIGURE_FLAGS=("--prefix=/usr")
PKG_KEEP_WORKDIR=1
CFG
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG" "$@"; }
mk_tar(){ local src_name="$1"; local d="$SOURCES/${src_name}-src"; mkdir -p "$d"; printf 'src\n' > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/${src_name}.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/${src_name}.tar.gz"|awk '{print $1}'; }
sum="$(mk_tar alpha-1.0.0)"
mkdir -p "$RECIPES/alpha"/{patches,hooks,files}
cat > "$RECIPES/alpha/pkgbuild" <<PKG
pkg_name="alpha"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="alpha"
pkg_sources=("$SOURCES/alpha-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf 'alpha\n' > "\$PKG_DESTDIR/usr/bin/alpha"; }
PKG
run_pkg install alpha >/dev/null
run_pkg build alpha >/dev/null
mkdir -p "$TMPROOT/pkg-sysusers" "$TMPROOT/pkg-tmpfiles"
printf 'stub\n' > "$TMPROOT/pkg-sysusers/sysusers.conf"
printf 'stub\n' > "$TMPROOT/pkg-tmpfiles/tmpfiles.conf"
run_pkg clean alpha >/dev/null
[[ ! -e "$TMPROOT/pkg-sysusers" ]]
[[ ! -e "$TMPROOT/pkg-tmpfiles" ]]
[[ -z "$(find "$TMPROOT" -mindepth 1 -print -quit 2>/dev/null || true)" ]]
echo '[PASS] clean remove workdirs versionados e diretórios auxiliares de integração'

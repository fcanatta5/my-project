#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-immediate-rb-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
mk_src(){ local n="$1"; local d="$SOURCES/$n-src"; mkdir -p "$d"; printf '%s\n' "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz" | awk '{print $1}'; }
write_recipe(){ local r="$1"; local v="$2"; local body="$3"; local dir="$RECIPES/$r"; local sum; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="1"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
write_recipe failapp 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "failapp\\n" > "$PKG_DESTDIR/usr/bin/failapp"'
cat > "$RECIPES/failapp/hooks/post_install.sh" <<'HOOK'
#!/usr/bin/env bash
set -Eeuo pipefail
exit 5
HOOK
chmod +x "$RECIPES/failapp/hooks/post_install.sh"
if run_pkg install failapp >/dev/null 2>&1; then fail 'install deveria falhar'; fi
assert_not_exists "$SYSROOT/usr/bin/failapp"
assert_not_exists "$DBROOT/installed/failapp"
find "$STATEROOT/recovery" -mindepth 1 -print -quit | grep -q . && fail "recovery deixou journals pendentes" || true
pass 'install com post_install falhando faz rollback imediato e não deixa estado parcial'
echo "Teste de rollback imediato passou em $TEST_ROOT"

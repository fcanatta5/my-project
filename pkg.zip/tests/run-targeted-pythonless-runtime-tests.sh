#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-pythonless-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
FAKEBIN="$TEST_ROOT/fakebin"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES" "$FAKEBIN"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
cat > "$FAKEBIN/python3" <<'PY'
#!/usr/bin/env bash
echo blocked > "${PKG_PYTHON_BLOCK_MARKER:?}"
exit 99
PY
chmod +x "$FAKEBIN/python3"
mk_src(){
  local name="$1" dir
  dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}
write_recipe(){
  local recipe="$1" version="$2" body="$3" sum dir
  dir="$RECIPES/$recipe"
  mkdir -p "$dir"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="pythonless runtime test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package() {
$body
}
PKG
}
run_pkg(){
  PKG_PYTHON_BLOCK_MARKER="$TEST_ROOT/python3-blocked" PATH="$FAKEBIN:$PATH" PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"
}
write_recipe pyfree 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "#!/bin/sh\\necho pyfree\\n" > "$PKG_DESTDIR/usr/bin/pyfree"\n  chmod 0755 "$PKG_DESTDIR/usr/bin/pyfree"'
run_pkg install pyfree >/dev/null
[[ -x "$SYSROOT/usr/bin/pyfree" ]] || fail 'arquivo instalado ausente sem python3'
[[ -d "$DBROOT/installed/pyfree" ]] || fail 'banco do pacote ausente sem python3'
run_pkg remove pyfree >/dev/null
[[ ! -e "$SYSROOT/usr/bin/pyfree" ]] || fail 'arquivo permaneceu após remoção sem python3'
[[ ! -e "$TEST_ROOT/python3-blocked" ]] || fail 'pkg tentou invocar python3 em runtime crítico'
pass 'install/remove e journal funcionam sem depender de python3'

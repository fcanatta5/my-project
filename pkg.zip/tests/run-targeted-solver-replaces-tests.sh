#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-solver-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" provides="$4" conflicts="$5" replaces="$6" body="$7"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe solver test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=($replaces)
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe ambigliba 1.0.0 '' '"virtual/ambig"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "a\n" > "$PKG_DESTDIR/usr/lib/libambig-a.so"\n'
write_recipe ambiglibb 1.0.0 '' '"virtual/ambig"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "b\n" > "$PKG_DESTDIR/usr/lib/libambig-b.so"\n'
write_recipe ambigconsumer 1.0.0 '"virtual/ambig"' '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "ambig\n" > "$PKG_DESTDIR/usr/bin/ambigconsumer"\n'
if run_pkg install --deps ambigconsumer >/dev/null 2>&1; then
  fail 'solver deveria falhar para dependência com múltiplas receitas providers'
fi
pass 'solver rejeita provider de receita ambíguo'

write_recipe legacypkg 1.0.0 '' '"virtual/legacy"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "legacy\n" > "$PKG_DESTDIR/usr/bin/legacycmd"\n'
run_pkg install legacypkg >/dev/null
write_recipe newvirtual 2.0.0 '' '"virtual/legacy"' '"virtual/legacy"' '"virtual/legacy"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "new\n" > "$PKG_DESTDIR/usr/bin/legacycmd"\n'
run_pkg install newvirtual >/dev/null
assert_not_exists "$DBROOT/installed/legacypkg"
assert_file_contains "$SYSROOT/usr/bin/legacycmd" 'new'
pass 'replaces remove pacote via token fornecido em provides'

write_recipe oldvirt1 1.0.0 '' '"virtual/oldvirt"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/oldvirt1"\n  printf "1\n" > "$PKG_DESTDIR/usr/share/oldvirt1/file"\n'
write_recipe oldvirt2 1.0.0 '' '"virtual/oldvirt"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/oldvirt2"\n  printf "2\n" > "$PKG_DESTDIR/usr/share/oldvirt2/file"\n'
run_pkg install oldvirt1 >/dev/null
run_pkg install oldvirt2 >/dev/null
write_recipe replambig 1.0.0 '' '' '"virtual/oldvirt"' '"virtual/oldvirt"' $'  mkdir -p "$PKG_DESTDIR/usr/share/replambig"\n  printf "x\n" > "$PKG_DESTDIR/usr/share/replambig/file"\n'
if run_pkg install replambig >/dev/null 2>&1; then
  fail 'replaces deveria falhar quando token virtual corresponde a múltiplos pacotes instalados'
fi
pass 'replaces rejeita token virtual ambíguo entre pacotes instalados'

echo "Todos os testes de solver/replaces passaram em $TEST_ROOT"

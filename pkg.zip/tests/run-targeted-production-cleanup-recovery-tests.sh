#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-production-cleanup-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s
' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}
write_recipe() {
  local recipe="$1" version="$2" release="$3" depends="$4" body="$5" build_body="${6:-:;}"
  local dir="$RECIPES/$recipe" sum depends_line
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  depends_line='pkg_depends=()'
  [[ -n "$depends" ]] && depends_line="pkg_depends=($depends)"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe cleanup test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() {
$build_body
}
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
write_recipe depclean 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "depclean-v1\\n" > "$PKG_DESTDIR/usr/lib/depclean.so"'
write_recipe appclean 1.0.0 1 '"depclean"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "appclean-v1\\n" > "$PKG_DESTDIR/usr/bin/appclean"'
run_pkg install --deps appclean >/dev/null
assert_file_contains "$SYSROOT/usr/lib/depclean.so" 'depclean-v1'
assert_file_contains "$SYSROOT/usr/bin/appclean" 'appclean-v1'
assert_not_exists "$TMPROOT/depclean-1.0.0-1"
assert_not_exists "$TMPROOT/appclean-1.0.0-1"
pass "install --deps limpa workdirs de dependência e alvo após sucesso"
write_recipe libtxclean 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "libtxclean-v1\\n" > "$PKG_DESTDIR/usr/lib/libtxclean.so"'
write_recipe apptxclean 1.0.0 1 '"libtxclean"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "apptxclean-v1\\n" > "$PKG_DESTDIR/usr/bin/apptxclean"'
run_pkg install --deps apptxclean >/dev/null
write_recipe libtxclean 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "libtxclean-v2\\n" > "$PKG_DESTDIR/usr/lib/libtxclean.so"'
write_recipe apptxclean 2.0.0 1 '"libtxclean"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "apptxclean-v2\\n" > "$PKG_DESTDIR/usr/bin/apptxclean"' 'sleep 20'
(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" upgrade apptxclean >/dev/null 2>&1) &
upgrade_pid=$!
sleep 2
kill -TERM "$upgrade_pid" 2>/dev/null || true
wait "$upgrade_pid" 2>/dev/null || true
run_pkg list >/dev/null
assert_file_contains "$SYSROOT/usr/lib/libtxclean.so" 'libtxclean-v1'
assert_file_contains "$SYSROOT/usr/bin/apptxclean" 'apptxclean-v1'
assert_not_exists "$TMPROOT/libtxclean-2.0.0-1"
assert_not_exists "$TMPROOT/apptxclean-2.0.0-1"
pass "autorecovery transacional limpa workdirs após interrupção abrupta"
echo "Todos os testes de cleanup/recovery de prontidão passaram em $TEST_ROOT"

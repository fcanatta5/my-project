#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-git-integrity-XXXXXX)}"
CONF="$TEST_ROOT/pkg.conf"
RECIPES="$TEST_ROOT/recipes"
TMPROOT="$TEST_ROOT/tmp"
LOGROOT="$TEST_ROOT/logs"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
CACHEROOT="$TEST_ROOT/cache"
SNAPROOT="$TEST_ROOT/snapshots"
SYSROOT="$TEST_ROOT/sysroot"
SOURCES="$TEST_ROOT/sources"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

git_tree_sha256() {
  local repo="$1" tmp
  tmp="$(mktemp)"
  (
    cd "$repo"
    find . -path ./.git -prune -o -type f -print0 | sort -z | while IFS= read -r -d '' f; do
      f="${f#./}"
      printf '%s\0' "$f"
      sha256sum -- "$f" | awk '{print $1}'
    done
  ) > "$tmp"
  sha256sum "$tmp" | awk '{print $1}'
  rm -f -- "$tmp"
}

mkdir -p "$RECIPES" "$TMPROOT" "$LOGROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$CACHEROOT" "$SNAPROOT" "$SYSROOT/usr" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_DEFAULT_GIT_CLONE_DEPTH=1
CFG

repo="$SOURCES/gitpkg-repo"
git init -q -b main "$repo"
(
  cd "$repo"
  git config user.name 'Test User'
  git config user.email 'test@example.invalid'
  printf 'git-source\n' > git.txt
  mkdir -p nested
  printf 'nested\n' > nested/value.txt
  git add git.txt nested/value.txt
  git commit -q -m 'init'
)
treehash="$(git_tree_sha256 "$repo")"
mkdir -p "$RECIPES/gitpkg"
cat > "$RECIPES/gitpkg/pkgbuild" <<PKG
pkg_name="gitpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="git source test"
pkg_sources=("git+$repo#ref=main")
pkg_sha256s=("$treehash")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
  mkdir -p "\$PKG_DESTDIR/usr/share/gitpkg"
  cp -f git.txt "\$PKG_DESTDIR/usr/share/gitpkg/git.txt"
  cp -f nested/value.txt "\$PKG_DESTDIR/usr/share/gitpkg/value.txt"
}
PKG
run_pkg install gitpkg >/dev/null || fail "install gitpkg"
[[ -f "$SYSROOT/usr/share/gitpkg/git.txt" ]] || fail "arquivo git restaurado ausente"
[[ -f "$SYSROOT/usr/share/gitpkg/value.txt" ]] || fail "arquivo aninhado ausente"
grep -q '^git-source$' "$SYSROOT/usr/share/gitpkg/git.txt" || fail "conteúdo git incorreto"
grep -q '^nested$' "$SYSROOT/usr/share/gitpkg/value.txt" || fail "conteúdo aninhado incorreto"
pass "instalação com fonte git+ e checksum determinístico"
echo "Todos os testes de integridade git passaram em $TEST_ROOT"

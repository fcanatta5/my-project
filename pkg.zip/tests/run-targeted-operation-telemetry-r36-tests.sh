#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r36-telemetry-XXXXXX)}"
CONF="$TEST_ROOT/pkg.conf"
RECIPES="$TEST_ROOT/recipes"
TMPROOT="$TEST_ROOT/tmp"
LOGROOT="$TEST_ROOT/logs"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
CACHEROOT="$TEST_ROOT/cache"
SNAPROOT="$TEST_ROOT/snapshots"
SYSROOT="$TEST_ROOT/sysroot"
SOURCES="$TEST_ROOT/sources"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

mkdir -p "$RECIPES" "$TMPROOT" "$LOGROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$CACHEROOT" "$SNAPROOT" "$SYSROOT/usr" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG

printf 'telemetry-source\n' > "$SOURCES/okpkg-1.0.0.txt"
ok_sha="$(sha256sum "$SOURCES/okpkg-1.0.0.txt" | awk '{print $1}')"
mkdir -p "$RECIPES/okpkg"
cat > "$RECIPES/okpkg/pkgbuild" <<PKG
pkg_name="okpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="ok"
pkg_sources=("$SOURCES/okpkg-1.0.0.txt")
pkg_sha256s=("$ok_sha")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf '#!/usr/bin/env bash\necho ok\n' > "\$PKG_DESTDIR/usr/bin/okpkg"; chmod +x "\$PKG_DESTDIR/usr/bin/okpkg"; }
PKG

run_pkg install okpkg >/dev/null
ok_diag="$(run_pkg diagnose okpkg latest)"
printf '%s\n' "$ok_diag" | grep -q '^status=ok$' || fail "diagnose latest não registrou status=ok"
printf '%s\n' "$ok_diag" | grep -q '^operation=install$' || fail "diagnose latest não registrou operation=install"
printf '%s\n' "$ok_diag" | grep -q '^exit_code=0$' || fail "diagnose latest não registrou exit_code=0"
pass "diagnose latest expõe metadados finais de sucesso"

printf 'broken-source\n' > "$SOURCES/broken-1.0.0.txt"
broken_sha="$(sha256sum "$SOURCES/broken-1.0.0.txt" | awk '{print $1}')"
mkdir -p "$RECIPES/broken"
cat > "$RECIPES/broken/pkgbuild" <<PKG
pkg_name="broken"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="broken"
pkg_sources=("$SOURCES/broken-1.0.0.txt")
pkg_sha256s=("$broken_sha")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ false; }
package(){ :; }
PKG

if run_pkg build broken >"$TEST_ROOT/broken.out" 2>&1; then
  fail "build quebrado deveria falhar"
fi
grep -q 'Consulte os logs em:' "$TEST_ROOT/broken.out" || fail "mensagem de erro não apontou para os logs"
broken_log_dir="$(awk -F': ' '/Consulte os logs em:/{print $2; exit}' "$TEST_ROOT/broken.out" | sed 's/ (ou:.*$//')"
[[ -n "$broken_log_dir" && -d "$broken_log_dir" ]] || fail "não consegui extrair diretório de logs da falha"
[[ -f "$broken_log_dir/operation.meta" ]] || fail "operation.meta ausente em falha"
[[ -f "$broken_log_dir/last_error.meta" ]] || fail "last_error.meta ausente em falha"
grep -q '^status=failed$' "$broken_log_dir/operation.meta" || fail "operation.meta não marcou status=failed"
grep -q '^detail=Falha na função build()$' "$broken_log_dir/last_error.meta" || fail "last_error.meta não registrou detalhe da falha"
printf '%s\n' "$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" diagnose broken error)" | grep -q '^status=failed$' || fail "diagnose error não exibiu last_error.meta"
pass "falha registra telemetria estruturada e mensagem ergonômica de logs"

echo "Todos os testes de telemetria operacional r36 passaram em $TEST_ROOT"

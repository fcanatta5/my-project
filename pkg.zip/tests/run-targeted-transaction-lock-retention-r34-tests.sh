#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r34-lock-retention-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() {
  jobs -p >/dev/null 2>&1 && jobs -p | xargs -r kill 2>/dev/null || true
  [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"
}
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_ARCHIVE_ROOT="$TEST_ROOT/packages"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_PROTECTED_PATHS=(/ /bin /sbin /etc /lib /lib64 /usr /usr/bin /usr/sbin /var /boot /dev /proc /sys /run)
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /usr/local /opt /etc /var)
PKG_BUILD_USER="root"
PKG_JOBS="1"
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_COLOR=0
PKG_KEEP_WORKDIR=0
PKG_KEEP_STAGE=0
PKG_CLEAN_ENV_AFTER_BUILD=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" release="$3" depends="$4" body="$5"
  local dir="$RECIPES/$recipe"
  local sum
  mkdir -p "$dir"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/$recipe-$version.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
package() {
$body
}
PKG
}

base_v1_body='  mkdir -p "$PKG_DESTDIR/usr/lib"'$'\n''  printf "base-v1\n" > "$PKG_DESTDIR/usr/lib/libbase.so"'
app_v1_body='  mkdir -p "$PKG_DESTDIR/usr/bin"'$'\n''  printf "app-v1\n" > "$PKG_DESTDIR/usr/bin/app"'
write_recipe base 1.0.0 1 '' "$base_v1_body"
write_recipe app 1.0.0 1 'base' "$app_v1_body"
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" install --deps app >/dev/null

base_v2_body='  mkdir -p "$PKG_DESTDIR/usr/lib"'$'\n''  printf "base-v2\n" > "$PKG_DESTDIR/usr/lib/libbase.so"'
app_v2_body=$(cat <<BODY
  printf 'started\n' > '$TEST_ROOT/app-build-started'
  sleep 5
  mkdir -p "\$PKG_DESTDIR/usr/bin"
  printf "app-v2\\n" > "\$PKG_DESTDIR/usr/bin/app"
BODY
)
write_recipe base 2.0.0 1 '' "$base_v2_body"
write_recipe app 2.0.0 1 'base' "$app_v2_body"

PKG_CONFIG_FILE="$CONF" "$PKG_BIN" upgrade app >"$TEST_ROOT/upgrade.out" 2>"$TEST_ROOT/upgrade.err" &
up_pid=$!

for _ in $(seq 1 100); do
  [[ -f "$TEST_ROOT/app-build-started" ]] && break
  sleep 0.1
done
[[ -f "$TEST_ROOT/app-build-started" ]] || fail "upgrade não iniciou o build do segundo payload"

exec 9>"$LOCKROOT/base.lock"
if flock -n 9; then
  kill "$up_pid" 2>/dev/null || true
  wait "$up_pid" 2>/dev/null || true
  fail "lock de base foi liberado no meio do planejamento transacional"
fi
exec 9>&-

wait "$up_pid" || fail "upgrade transacional falhou"
grep -Fqx 'base-v2' "$SYSROOT/usr/lib/libbase.so" || fail "base não foi atualizada"
grep -Fqx 'app-v2' "$SYSROOT/usr/bin/app" || fail "app não foi atualizada"

pass "locks do conjunto transacional permanecem retidos durante todo o planejamento do upgrade"
echo "Todos os testes de retenção de lock transacional r34 passaram em $TEST_ROOT"

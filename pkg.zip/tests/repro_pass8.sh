#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$1' == '$2'"; }
assert_contains() { grep -Fq "$2" <<<"$1" || fail "texto ausente: $2"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$SYSROOT/etc"
mkdir -p "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" provides="$4" conflicts="$5" body="$6"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe targeted test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
prepare() {
  printf 'prepare-ran\n' > "\$PKG_WORKDIR/prepare.marker"
}
build() {
  printf 'build-ran\n' > "\$PKG_WORKDIR/build.marker"
}
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

call_func() {
  local func="$1"
  shift
  PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s -- "$func" "$@" <<'BASH'
set -Eeuo pipefail
func="$1"
shift
source <(sed '$d' "$PKG_BIN")
load_config
"$func" "$@"
BASH
}

# 1) prepare/build/package + manifest + metadata
write_recipe metapkg 1.0.0 '' '"virtual/metapkg"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin" "$PKG_DESTDIR/usr/share/metapkg"
  printf "#!/bin/sh\nexit 0\n" > "$PKG_DESTDIR/usr/bin/metapkg"
  chmod +x "$PKG_DESTDIR/usr/bin/metapkg"
  ln -s ../bin/metapkg "$PKG_DESTDIR/usr/share/metapkg/tool-link"\n'
run_pkg build metapkg >/dev/null
latest_build_dir="$(find "$LOGROOT/metapkg" -mindepth 1 -maxdepth 1 -type d | sort | tail -n1)"
assert_file "$latest_build_dir/environment.exported"
manifest_root="$(find "$TMPROOT" -maxdepth 1 -type d -name 'metapkg-*' | sort | tail -n1)/manifest"
assert_file "$manifest_root/files"
assert_file "$manifest_root/dirs"
assert_file "$manifest_root/meta"
assert_file_contains "$manifest_root/files" '/usr/bin/metapkg'
assert_file_contains "$manifest_root/files" '/usr/share/metapkg/tool-link'
assert_file_contains "$manifest_root/dirs" '/usr/share/metapkg'
assert_file_contains "$manifest_root/meta" 'file_count=2'
assert_file_contains "$manifest_root/meta" 'dir_count=4'
assert_file_contains "$manifest_root/meta" 'provides_count=1'
pass 'run_prepare_build_package, create_manifest e write_metadata geram stage, manifesto e metadados corretos'

# 2) empty disallowed dir must be rejected (real bug guard)
write_recipe bademptydir 1.0.0 '' '' '' $'  mkdir -p "$PKG_DESTDIR/opt/forbidden-empty"\n'
if run_pkg build bademptydir >/dev/null 2>&1; then
  fail 'build deveria falhar para diretório vazio fora dos prefixos permitidos'
fi
pass 'create_manifest rejeita diretório vazio fora dos prefixos permitidos'

# 3) provides/declares/provider helpers
write_recipe provider 1.0.0 '' '"virtual/libalpha"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "alpha\n" > "$PKG_DESTDIR/usr/lib/libalpha.so"\n'
run_pkg install provider >/dev/null
assert_eq "$(call_func pkg_provides_name virtual/libalpha)" 'provider'
call_func pkg_declares_name_or_provide provider virtual/libalpha >/dev/null
call_func pkg_declares_name_or_provide provider provider >/dev/null
assert_eq "$(call_func find_installed_provider virtual/libalpha)" 'provider'
pass 'pkg_provides_name, pkg_declares_name_or_provide e find_installed_provider resolvem provides instalados'

# 4) direct dependency check uses installed provider
write_recipe app 1.0.0 '"virtual/libalpha"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app\n" > "$PKG_DESTDIR/usr/bin/app"\n'
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
load_recipe app
CURRENT_LOG_DIR="$PKG_LOG_ROOT/direct-check"
mkdir -p "$CURRENT_LOG_DIR"
check_declared_dependencies_installed
BASH
pass 'check_declared_dependencies_installed aceita dependência satisfeita por provider instalado'

# 5) dependency order via recipe provider
write_recipe libdep 1.0.0 '' '"virtual/dep"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "dep\n" > "$PKG_DESTDIR/usr/lib/libdep.so"\n'
write_recipe mid 1.0.0 '"virtual/dep"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/mid"\n  printf "mid\n" > "$PKG_DESTDIR/usr/share/mid/data"\n'
write_recipe top 1.0.0 '"mid"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/top"\n  printf "top\n" > "$PKG_DESTDIR/usr/share/top/data"\n'
order_out="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
order=()
resolve_recipe_dep_order top order
printf '%s\n' "${order[@]}"
BASH
)"
assert_eq "$order_out" $'libdep\nmid\ntop'
pass 'resolve_recipe_dep_order calcula ordem topológica correta com provider de receita'

# 6) installed package conflicts against new recipe through provide token
write_recipe blocker 1.0.0 '' '' '"virtual/editor"' $'  mkdir -p "$PKG_DESTDIR/usr/share/blocker"\n  printf "block\n" > "$PKG_DESTDIR/usr/share/blocker/file"\n'
run_pkg install blocker >/dev/null
write_recipe editor 1.0.0 '' '"virtual/editor"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "editor\n" > "$PKG_DESTDIR/usr/bin/editor"\n'
if run_pkg install editor >/dev/null 2>&1; then
  fail 'install deveria falhar quando pacote instalado conflita com provide da nova receita'
fi
pass 'installed_pkg_conflicts_with_new_recipe bloqueia conflito por provide'

# 7) ambiguous recipe providers must be rejected by solver
write_recipe ambigliba 1.0.0 '' '"virtual/ambig"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "a\n" > "$PKG_DESTDIR/usr/lib/libambig-a.so"\n'
write_recipe ambiglibb 1.0.0 '' '"virtual/ambig"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "b\n" > "$PKG_DESTDIR/usr/lib/libambig-b.so"\n'
write_recipe ambigconsumer 1.0.0 '"virtual/ambig"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "ambig\n" > "$PKG_DESTDIR/usr/bin/ambigconsumer"\n'
if run_pkg install --deps ambigconsumer >/dev/null 2>&1; then
  fail 'solver deveria falhar para dependência com múltiplas receitas providers'
fi
pass 'resolve_recipe_dep_order rejeita providers ambíguos em receitas'

# 8) replaces must match installed package by provided token, not only exact name
write_recipe legacypkg 1.0.0 '' '"virtual/legacy"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "legacy\n" > "$PKG_DESTDIR/usr/bin/legacycmd"\n'
run_pkg install legacypkg >/dev/null
write_recipe newvirtual 2.0.0 '' '"virtual/legacy"' '"virtual/legacy"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "new\n" > "$PKG_DESTDIR/usr/bin/legacycmd"\n'
python - <<PY
from pathlib import Path
p=Path(r"$RECIPES/newvirtual/pkgbuild")
s=p.read_text()
s=s.replace('pkg_replaces=()', 'pkg_replaces=("virtual/legacy")')
p.write_text(s)
PY
run_pkg install newvirtual >/dev/null
assert_not_exists "$DBROOT/installed/legacypkg"
assert_file_contains "$SYSROOT/usr/bin/legacycmd" 'new'
pass 'replaces remove pacote instalado quando o token casa via provides'
echo TEST_ROOT=$TEST_ROOT
echo CONF=$CONF
exit 0

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTDIR="${OUTDIR:-$REPO_ROOT/QA_RESULTS_R35_SEALED}"
LIVE="$OUTDIR/live"
mkdir -p "$OUTDIR" "$LIVE"
REPORT="$OUTDIR/REPORT_R35.tsv"
SUMMARY="$OUTDIR/SUMMARY_R35.txt"
VERDICT_FILE="$OUTDIR/VERDICT_R35.txt"
MANIFEST="$OUTDIR/MANIFEST_IMMUTABLE_R35.sha256"
SEAL="$OUTDIR/SEAL_R35.txt"
: > "$REPORT"
status=0
log_result(){ printf '%s	%s	%s	%s
' "$1" "$2" "$3" "$4" >> "$REPORT"; }
check_cmd(){ local gate="$1"; shift; local logfile="$LIVE/${gate}.log"; if "$@" >"$logfile" 2>&1; then log_result "$gate" PASS "$(tail -n 1 "$logfile" 2>/dev/null || echo ok)" "$logfile"; else local rc=$?; log_result "$gate" FAIL "rc=$rc $(tail -n 20 "$logfile" 2>/dev/null | tr '
' ' ' | sed 's/[[:space:]]\+/ /g')" "$logfile"; status=1; fi; }
check_timeout(){ local gate="$1" secs="$2" script="$3"; local logfile="$LIVE/${gate}.log"; if timeout "$secs" bash "$REPO_ROOT/$script" >"$logfile" 2>&1; then log_result "$gate" PASS "$(tail -n 1 "$logfile" 2>/dev/null || echo ok)" "$script"; else local rc=$?; log_result "$gate" FAIL "rc=$rc $(tail -n 20 "$logfile" 2>/dev/null | tr '
' ' ' | sed 's/[[:space:]]\+/ /g')" "$script"; status=1; fi; }
check_cmd syntax-main bash -n "$REPO_ROOT/usr/pkg/bin/pkg"
check_cmd syntax-tests bash -lc 'find "$1/tests" -maxdepth 1 -type f -name "*.sh" -print0 | xargs -0 -n1 bash -n' _ "$REPO_ROOT"
check_cmd smoke-help bash -lc '"$1/usr/pkg/bin/pkg" help | grep -Fq "pkg 0.4.0"' _ "$REPO_ROOT"
for item in README.md docs/TESTING.md docs/GO_NO_GO_PRIMARY_MANAGER.md etc/pkg/pkg.conf; do check_cmd "presence-$(basename "$item" | tr . -)" test -f "$REPO_ROOT/$item"; done
check_timeout config-runtime 180 tests/run-targeted-config-runtime-hardening-tests.sh
check_timeout config-derived-paths 180 tests/run-targeted-config-derived-path-hardening-r32-tests.sh
check_timeout input-validation 180 tests/run-targeted-input-validation-tests.sh
check_timeout repo-dispatch 180 tests/run-targeted-repo-command-tests.sh
check_timeout repo-index-path-hardening 180 tests/run-targeted-repo-index-path-hardening-tests.sh
check_timeout binary-path-traversal 180 tests/run-targeted-binary-package-safety-tests.sh
check_timeout binary-link-safety 180 tests/run-targeted-binary-package-link-safety-tests.sh
check_timeout binary-manifest-hardening 180 tests/run-targeted-binary-package-manifest-hardening-tests.sh
check_timeout binary-manifest-drift 180 tests/run-targeted-binary-package-payload-manifest-drift-tests.sh
check_timeout git-integrity 240 tests/run-targeted-git-source-integrity-tests.sh
check_timeout immediate-rollback 240 tests/run-targeted-immediate-rollback-tests.sh
check_timeout tx-stale-cleanup 240 tests/run-targeted-tx-stale-cleanup-tests.sh
check_timeout production-matrix-r35 180 tests/run-targeted-production-matrix-r35-tests.sh
check_timeout failover-recovery-r35 1200 tests/run-targeted-failover-recovery-r35-tests.sh
(
  cd "$REPO_ROOT"
  sha256sum     usr/pkg/bin/pkg     tests/run-go-no-go-primary-manager-r35.sh     tests/run-targeted-production-matrix-r35-tests.sh     tests/run-targeted-failover-recovery-r35-tests.sh     docs/GO_NO_GO_PRIMARY_MANAGER.md     etc/pkg/pkg.conf     CHANGE_SUMMARY_R35.txt     CHANGE_SUMMARY_LATEST.txt > "$MANIFEST"
)
manifest_hash="$(sha256sum "$MANIFEST" | awk '{print $1}')"
pass_count=$(awk -F'	' '$2=="PASS"{c++} END{print c+0}' "$REPORT")
fail_count=$(awk -F'	' '$2=="FAIL"{c++} END{print c+0}' "$REPORT")
verdict=GO
reason='GO: harness único R35 passou, rollback e recovery testados, matriz de ambiente executada e manifesto selado gerado.'
if [[ "$fail_count" -gt 0 ]]; then verdict=NO-GO; reason='NO-GO: houve falha em pelo menos um gate crítico do harness único R35.'; fi
cat > "$SEAL" <<TXT
R35 Production Seal
Generated at: $(date -Is)
Repository root: $REPO_ROOT
Manifest: $MANIFEST
Manifest SHA256: $manifest_hash
Rule: qualquer alteração posterior em arquivo manifestado invalida o selo.
TXT
cat > "$SUMMARY" <<TXT
R35 Production Sealed Summary
Generated at: $(date -Is)
Repository root: $REPO_ROOT
Output dir: $OUTDIR

Verdict: $verdict
Reason: $reason

Pass gates: $pass_count
Fail gates: $fail_count

Decision rule:
- GO: zero FAIL no harness único R35.
- NO-GO: qualquer FAIL estrutural, funcional, transacional ou de matriz.

Coverage in this run:
- hardening estrutural e de entrada
- segurança de pacote binário e dispatcher de repositório
- integridade git
- rollback imediato
- falha transacional com lock
- recovery com contenção de lock
- limpeza de tx stale
- recovery com PID estrangeiro
- matriz de ambiente ampliada
- rollback/recovery selados
- manifesto imutável + hash do próprio manifesto

Detailed report:
$(cat "$REPORT")
TXT
printf '%s
' "$verdict" > "$VERDICT_FILE"
[[ "$status" -eq 0 ]]

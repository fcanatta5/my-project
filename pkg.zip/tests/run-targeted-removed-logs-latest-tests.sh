#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-removed-logs-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" release="$3" body="$4"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe removed logs test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe auditpkg 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "v1\\n" > "$PKG_DESTDIR/usr/bin/auditpkg"'
run_pkg install auditpkg >/dev/null
run_pkg remove auditpkg >/dev/null
first_removed_dir="$(find "$STATEROOT/removed/auditpkg" -mindepth 1 -maxdepth 1 -type d | head -n1)"
assert_file_contains "$first_removed_dir/runtime-logs/main.log" 'Pacote removido: auditpkg'

# Cria um diretório lexicograficamente "maior", mas mais antigo, para provar que logs usa mtime real.
mkdir -p "$STATEROOT/removed/auditpkg/z-older/runtime-logs"
printf 'old-log\n' > "$STATEROOT/removed/auditpkg/z-older/runtime-logs/main.log"
touch -t 200001010000 "$STATEROOT/removed/auditpkg/z-older" "$STATEROOT/removed/auditpkg/z-older/runtime-logs" "$STATEROOT/removed/auditpkg/z-older/runtime-logs/main.log"

sleep 1
write_recipe auditpkg 2.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "v2\\n" > "$PKG_DESTDIR/usr/bin/auditpkg"'
run_pkg install auditpkg >/dev/null
run_pkg remove auditpkg >/dev/null

logs_output="$(run_pkg logs auditpkg main)"
printf '%s' "$logs_output" | grep -Fq 'Pacote removido: auditpkg' || fail 'cmd_logs não retornou o log do último banco removido por mtime'
printf '%s' "$logs_output" | grep -Fq 'old-log' && fail 'cmd_logs escolheu o banco removido errado por ordem lexicográfica'
pass 'cmd_logs usa o banco removido mais recente por mtime, não por nome do diretório'

echo "Todos os testes focados de logs removidos passaram em $TEST_ROOT"

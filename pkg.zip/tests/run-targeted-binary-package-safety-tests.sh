#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-bin-safety-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
REPOROOT="$TEST_ROOT/repo"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_not_grep() { ! grep -Fq "$2" "$1" || fail "texto inesperado em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$REPOROOT"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$TEST_ROOT/recipes"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPOROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG

mkdir -p "$TEST_ROOT/malicious/payload" "$TEST_ROOT/malicious/meta"
cat > "$TEST_ROOT/malicious/.PKGINFO" <<PKG
pkgname=evil
pkgver=1.0.0
pkgrelease=1
pkgdesc=malicious archive member test
PKG
printf '/usr/bin/evil\n' > "$TEST_ROOT/malicious/meta/files"
printf '/usr/bin\n/usr\n' > "$TEST_ROOT/malicious/meta/dirs"
printf 'name=evil\nversion=1.0.0\nrelease=1\n' > "$TEST_ROOT/malicious/meta/meta"
printf '#!/bin/sh\necho evil\n' > "$TEST_ROOT/malicious/payload/usr-bin-evil"
mkdir -p "$TEST_ROOT/malicious/payload/usr/bin"
cp "$TEST_ROOT/malicious/payload/usr-bin-evil" "$TEST_ROOT/malicious/payload/usr/bin/evil"
mkdir -p "$TEST_ROOT/escape-target"
printf 'owned\n' > "$TEST_ROOT/escape-target/pwned.txt"

tar --zstd -cf "$REPOROOT/evil-1.0.0-1.pkg.tar.zst" \
  -C "$TEST_ROOT/malicious" . \
  --transform='s#^\./payload/usr/bin/evil$#./payload/../../escape-target/pwned.txt#'

set +e
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install-bin "$REPOROOT/evil-1.0.0-1.pkg.tar.zst" > "$TEST_ROOT/cmd.out" 2> "$TEST_ROOT/cmd.err"
rc=$?
set -e
[[ $rc -ne 0 ]] || fail 'install-bin deveria rejeitar pacote binário com path traversal no archive'
grep -Fq 'Pacote binário inválido' "$TEST_ROOT/cmd.err" || fail 'mensagem de erro esperada ausente'
assert_not_exists "$SYSROOT/usr/bin/evil"
assert_not_grep "$TEST_ROOT/escape-target/pwned.txt" '#!/bin/sh'
pass 'install-bin rejeita pacote binário com path traversal antes da extração'

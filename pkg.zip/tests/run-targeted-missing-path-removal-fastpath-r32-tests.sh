#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r32-missing-remove-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1" d; d="$SOURCES/${n}-src"; mkdir -p "$d"; printf '%s\n' "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/${n}.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/${n}.tar.gz"|awk '{print $1}'; }
write_recipe(){
  local r="$1" v="$2" body="$3" dir sum
  dir="$RECIPES/$r"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$r-$v")"
  {
    printf 'pkg_name="%s"\n' "$r"
    printf 'pkg_version="%s"\n' "$v"
    printf 'pkg_release="1"\n'
    printf 'pkg_desc="%s"\n' "$r"
    printf 'pkg_homepage=x\n'
    printf 'pkg_license=x\n'
    printf 'pkg_sources=("%s/%s-%s.tar.gz")\n' "$SOURCES" "$r" "$v"
    printf 'pkg_sha256s=("%s")\n' "$sum"
    printf 'pkg_depends=()\n'
    printf 'pkg_build_depends=()\n'
    printf 'pkg_conflicts=()\n'
    printf 'pkg_provides=()\n'
    printf 'pkg_replaces=()\n'
    printf 'pkg_patches=()\n'
    printf 'pkg_options=()\n'
    printf 'pkg_config_files=()\n'
    printf 'build(){ :; }\n'
    printf 'package(){\n%s\n}\n' "$body"
  } > "$dir/pkgbuild"
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 120 bash "$PKG_BIN" "$@"; }
write_recipe missrm 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin" "$PKG_DESTDIR/usr/share/missrm/sub"\n  printf "missrm\\n" > "$PKG_DESTDIR/usr/bin/missrm"\n  printf "data\\n" > "$PKG_DESTDIR/usr/share/missrm/sub/data.txt"'
run_pkg install missrm >/dev/null
rm -f -- "$SYSROOT/usr/bin/missrm" "$SYSROOT/usr/share/missrm/sub/data.txt"
rmdir "$SYSROOT/usr/share/missrm/sub" "$SYSROOT/usr/share/missrm" 2>/dev/null || true
run_pkg remove missrm >/dev/null
assert_not_exists "$DBROOT/installed/missrm"
pass "remoção ignora caminhos já ausentes sem depender de ownership scan para concluir"
echo "Todos os testes de fast-path para caminhos ausentes r32 passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-prod-e2e-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file(){ [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_dir(){ [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_no_match(){ ! compgen -G "$1" >/dev/null || fail "match inesperado: $1"; }
latest_snapshot(){ find "$SNAPROOT/$1" -maxdepth 1 -type f -name '*.tar' | sort | tail -n1; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1"; local d="$SOURCES/$n-src"; mkdir -p "$d"; printf '%s\n' "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz" | awk '{print $1}'; }
write_recipe(){ local r="$1" v="$2" rel="$3" deps="$4" body="$5" dir sum depends_line; dir="$RECIPES/$r"; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; depends_line='pkg_depends=()'; [[ -n "$deps" ]] && depends_line="pkg_depends=($deps)"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="$rel"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 60s bash "$PKG_BIN" "$@"; }
# install --deps
write_recipe baselib 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "baselib-v1\\n" > "$PKG_DESTDIR/usr/lib/baselib.so"'
write_recipe baseapp 1.0.0 1 '"baselib"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "baseapp-v1\\n" > "$PKG_DESTDIR/usr/bin/baseapp"'
run_pkg install --deps baseapp >/dev/null
assert_file_contains "$SYSROOT/usr/lib/baselib.so" 'baselib-v1'
assert_file_contains "$SYSROOT/usr/bin/baseapp" 'baseapp-v1'
pass 'install --deps instala dependência e alvo em cenário real'
# global upgrade includes dependency
write_recipe baselib 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "baselib-v2\\n" > "$PKG_DESTDIR/usr/lib/baselib.so"'
write_recipe baseapp 2.0.0 1 '"baselib"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "baseapp-v2\\n" > "$PKG_DESTDIR/usr/bin/baseapp"'
run_pkg upgrade baseapp >/dev/null
assert_file_contains "$SYSROOT/usr/lib/baselib.so" 'baselib-v2'
assert_file_contains "$SYSROOT/usr/bin/baseapp" 'baseapp-v2'
assert_file_contains "$DBROOT/installed/baselib/meta" 'version=2.0.0'
assert_file_contains "$DBROOT/installed/baseapp/meta" 'version=2.0.0'
pass 'upgrade transacional global inclui dependência instalada com receita mais nova'
# hook failure rollback full tx
write_recipe crashdep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "crashdep-v1\\n" > "$PKG_DESTDIR/usr/lib/crashdep.so"'
write_recipe crashapp 1.0.0 1 '"crashdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "crashapp-v1\\n" > "$PKG_DESTDIR/usr/bin/crashapp"'
run_pkg install --deps crashapp >/dev/null
write_recipe crashdep 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "crashdep-v2\\n" > "$PKG_DESTDIR/usr/lib/crashdep.so"'
write_recipe crashapp 2.0.0 1 '"crashdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "crashapp-v2\\n" > "$PKG_DESTDIR/usr/bin/crashapp"'
cat > "$RECIPES/crashapp/hooks/post_install.sh" <<'HOOK'
#!/usr/bin/env bash
set -Eeuo pipefail
exit 42
HOOK
chmod +x "$RECIPES/crashapp/hooks/post_install.sh"
if run_pkg upgrade crashapp >/dev/null 2>&1; then
  fail 'upgrade crashapp deveria falhar via post_install'
fi
assert_file_contains "$SYSROOT/usr/lib/crashdep.so" 'crashdep-v1'
assert_file_contains "$SYSROOT/usr/bin/crashapp" 'crashapp-v1'
assert_file_contains "$DBROOT/installed/crashdep/meta" 'version=1.0.0'
assert_file_contains "$DBROOT/installed/crashapp/meta" 'version=1.0.0'
assert_no_match "$TMPROOT/tx-*"
pass 'falha em post_install faz rollback completo do conjunto'
# lock occupied dependency
write_recipe lockdep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "lockdep-v1\\n" > "$PKG_DESTDIR/usr/lib/lockdep.so"'
write_recipe lockapp 1.0.0 1 '"lockdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lockapp-v1\\n" > "$PKG_DESTDIR/usr/bin/lockapp"'
run_pkg install --deps lockapp >/dev/null
write_recipe lockdep 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "lockdep-v2\\n" > "$PKG_DESTDIR/usr/lib/lockdep.so"'
write_recipe lockapp 2.0.0 1 '"lockdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lockapp-v2\\n" > "$PKG_DESTDIR/usr/bin/lockapp"'
( exec 9>"$LOCKROOT/lockdep.lock"; flock -n 9; sleep 5 ) & locker_pid=$!; sleep 0.3
if run_pkg upgrade lockapp >/dev/null 2>&1; then kill "$locker_pid" 2>/dev/null || true; wait "$locker_pid" 2>/dev/null || true; fail 'upgrade lockapp deveria falhar por lock ocupado'; fi
kill "$locker_pid" 2>/dev/null || true; wait "$locker_pid" 2>/dev/null || true
assert_file_contains "$SYSROOT/usr/lib/lockdep.so" 'lockdep-v1'
assert_file_contains "$SYSROOT/usr/bin/lockapp" 'lockapp-v1'
pass 'lock ocupado em dependência barra a transação'
# shared ownership without false owner error
write_recipe shareda 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/share/shared-empty"\n  : > "$PKG_DESTDIR/usr/share/shared-empty/.a"\n  rm -f "$PKG_DESTDIR/usr/share/shared-empty/.a"'
write_recipe sharedb 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/share/shared-empty"\n  : > "$PKG_DESTDIR/usr/share/shared-empty/.b"\n  rm -f "$PKG_DESTDIR/usr/share/shared-empty/.b"'
run_pkg install shareda >/dev/null
run_pkg install sharedb >/dev/null
owner_output="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" owner /usr/share/shared-empty 2>"$TEST_ROOT/owner.err" || true)"
[[ -z "$owner_output" ]] || fail 'owner não deveria retornar owner único para diretório compartilhado'
grep -Fq 'Múltiplos owners' "$TEST_ROOT/owner.err" && fail 'owner registrou erro falso para diretório compartilhado'
run_pkg remove shareda >/dev/null
assert_dir "$SYSROOT/usr/share/shared-empty"
run_pkg verify sharedb >/dev/null
pass 'ownership compartilhado preserva diretório e não gera erro falso'
# synthetic interrupted transaction recovery
write_recipe txdep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "txdep-v1\\n" > "$PKG_DESTDIR/usr/lib/txdep.so"'
write_recipe txapp 1.0.0 1 '"txdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "txapp-v1\\n" > "$PKG_DESTDIR/usr/bin/txapp"'
run_pkg install --deps txapp >/dev/null
write_recipe txdep 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "txdep-v2\\n" > "$PKG_DESTDIR/usr/lib/txdep.so"'
write_recipe txapp 2.0.0 1 '"txdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "txapp-v2\\n" > "$PKG_DESTDIR/usr/bin/txapp"'
run_pkg upgrade txapp >/dev/null
snap_dep="$(latest_snapshot txdep)"; snap_app="$(latest_snapshot txapp)"; [[ -f "$snap_dep" && -f "$snap_app" ]] || fail 'snapshots tx ausentes'
mkdir -p "$TMPROOT/tx-stale/payloads"
cat > "$TMPROOT/tx-stale/tx.meta" <<META
id=tx-stale
state=applying
pid=999999
target_recipe=txapp
started_at=$(date -Is)
META
cat > "$TMPROOT/tx-stale/prestate.list" <<PRE
txdep	installed	$snap_dep
txapp	installed	$snap_app
PRE
run_pkg list >/dev/null
assert_file_contains "$SYSROOT/usr/lib/txdep.so" 'txdep-v1'
assert_file_contains "$SYSROOT/usr/bin/txapp" 'txapp-v1'
assert_not_exists "$TMPROOT/tx-stale"
pass 'recovery automático de transação interrompida restaura o conjunto'
assert_no_match "$DBROOT/installed/*.prev"
assert_no_match "$DBROOT/installed/*.tmp*"
pass 'banco instalado fica limpo após cenários end-to-end'
echo "Validação end-to-end de produção passou em $TEST_ROOT"

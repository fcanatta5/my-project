#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-txpid-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1"; local d="$SOURCES/$n-src"; mkdir -p "$d"; echo "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz"|awk '{print $1}'; }
write_recipe(){ local r="$1" v="$2" rel="$3" body="$4" dir sum; dir="$RECIPES/$r"; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="$rel"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 240s bash "$PKG_BIN" "$@"; }
latest_snapshot(){ find "$SNAPROOT/$1" -maxdepth 1 -type f -name '*.tar' 2>/dev/null | sort | tail -n1; }
write_recipe txpid 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "txpid-v1\\n" > "$PKG_DESTDIR/usr/bin/txpid"'
run_pkg install txpid >/dev/null
write_recipe txpid 2.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "txpid-v2\\n" > "$PKG_DESTDIR/usr/bin/txpid"'
run_pkg upgrade txpid >/dev/null
archive="$(latest_snapshot txpid)"; [[ -f "$archive" ]] || fail "snapshot ausente"
mkdir -p "$TMPROOT/tx-foreign/payloads"
cat > "$TMPROOT/tx-foreign/prestate.list" <<PRE
txpid	installed	$archive
PRE
sleep 8 &
foreign_sleep_pid=$!
echo "[INFO] preparando journal transacional com PID estrangeiro vivo"
cat > "$TMPROOT/tx-foreign/tx.meta" <<META
id=tx-foreign
state=applying
pid=$foreign_sleep_pid
target_recipe=txpid
started_at=$(date -Is)
META
echo "[INFO] disparando autorecovery transacional"
run_pkg list >/dev/null
kill "$foreign_sleep_pid" 2>/dev/null || true
wait "$foreign_sleep_pid" 2>/dev/null || true
assert_file_contains "$SYSROOT/usr/bin/txpid" 'txpid-v1'
assert_not_exists "$TMPROOT/tx-foreign"
pass "recovery de transação ignora PID vivo que não pertence ao pkg"

#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-removed-logs-partial-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
RECIPES="$TEST_ROOT/recipes"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$2', obtido '$1'"; }

mkdir -p "$SYSROOT" "$DBROOT/installed" "$STATEROOT/removed" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$RECIPES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG

removed="$STATEROOT/removed/ghost/20260315-remove-1"
mkdir -p "$removed/runtime-logs" "$removed/logs"
printf 'runtime-main\n' > "$removed/runtime-logs/main.log"
printf 'archived-hook\n' > "$removed/logs/hook.log"

main_out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" logs ghost main)"
hook_out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" logs ghost hook)"
assert_eq "$main_out" 'runtime-main'
assert_eq "$hook_out" 'archived-hook'
pass 'cmd_logs usa runtime-logs quando disponível, mas faz fallback por arquivo para logs arquivados ausentes no runtime-logs'

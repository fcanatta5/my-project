#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-config-runtime-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == 1 ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_PROTECTED_PATHS=(/ /usr /etc /var)
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
PKG_CREATE_BINARY_ARCHIVE=1
PKG_KEEP_WORKDIR=1
CFG
mk_src(){ local name="$1" dir; dir="$SOURCES/$name-src"; mkdir -p "$dir"; printf '%s\n' "$name" > "$dir/README"; tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"; sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'; }
sum="$(mk_src tiny-1.0.0)"
mkdir -p "$RECIPES/tiny"
cat > "$RECIPES/tiny/pkgbuild" <<PKG
pkg_name="tiny"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="tiny"
pkg_homepage="https://example.invalid/tiny"
pkg_license="MIT"
pkg_sources=("$SOURCES/tiny-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
build(){ :; }
package(){
  mkdir -p "\$PKG_DESTDIR/usr/bin"
  printf tiny > "\$PKG_DESTDIR/usr/bin/tiny"
}
PKG
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" build tiny >/dev/null
archive="$CACHEROOT/packages/tiny-1.0.0-1.pkg.tar.zst"
[[ -f "$archive" ]] || fail "pacote binário não foi criado sob PKG_CACHE_ROOT"
[[ ! -f "/var/cache/pkg/packages/tiny-1.0.0-1.pkg.tar.zst" ]] || fail "build vazou para /var/cache/pkg/packages"
pass 'binary archive root acompanha PKG_CACHE_ROOT por padrão'
mapfile -t workdirs < <(find "$TMPROOT" -maxdepth 1 -mindepth 1 -type d -name 'tiny-1.0.0-1-*' | sort)
(( ${#workdirs[@]} == 1 )) || fail "esperado 1 workdir versionado, obtido ${#workdirs[@]}"
[[ -d "${workdirs[0]}/stage" && -d "${workdirs[0]}/manifest" ]] || fail 'workdir preservado incompleto'
pass 'setup_runtime usa workdir único versionado sob PKG_TMP_ROOT'

INVALID_ROOT="$TEST_ROOT/invalid-rel-root-case"
mkdir -p "$INVALID_ROOT"
cat > "$INVALID_ROOT/pkg-invalid.conf" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="relative-db"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG
(
  cd "$INVALID_ROOT"
  if PKG_CONFIG_FILE="$INVALID_ROOT/pkg-invalid.conf" "$PKG_BIN" list >/tmp/pkg-invalid-config.out 2>/tmp/pkg-invalid-config.err; then
    fail 'configuração relativa inválida foi aceita'
  fi
)
grep -q 'Configuração deve usar caminho absoluto: PKG_DB_ROOT=relative-db' /tmp/pkg-invalid-config.err || fail 'mensagem de erro inesperada para config relativa'
[[ ! -e "$INVALID_ROOT/relative-db" ]] || fail 'load_config criou diretório relativo antes da validação'
pass 'configuração relativa é rejeitada antes de qualquer mkdir'

NONCAN_ROOT="$TEST_ROOT/invalid-noncanonical-case"
mkdir -p "$NONCAN_ROOT/inside"
cat > "$NONCAN_ROOT/pkg-noncanonical.conf" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$NONCAN_ROOT/inside/../db"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG
if PKG_CONFIG_FILE="$NONCAN_ROOT/pkg-noncanonical.conf" "$PKG_BIN" list >/tmp/pkg-noncanonical-config.out 2>/tmp/pkg-noncanonical-config.err; then
  fail 'configuração absoluta não canônica foi aceita'
fi
grep -q 'Configuração deve usar caminho canônico: PKG_DB_ROOT=' /tmp/pkg-noncanonical-config.err || fail 'mensagem de erro inesperada para config não canônica'
[[ ! -d "$NONCAN_ROOT/db" ]] || fail 'load_config materializou caminho não canônico antes da validação'
pass 'configuração absoluta não canônica é rejeitada antes de qualquer mkdir'

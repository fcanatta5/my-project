#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-snapshot-identity-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_exists() { [[ -e "$1" ]] || fail "deveria existir: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/alpha" "$RECIPES/beta" "$SOURCES" "$SNAPROOT/beta"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=1
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  mkdir -p "$SOURCES/${name}-src"
  printf '%s
' "$name source" > "$SOURCES/${name}-src/README"
  tar -C "$SOURCES" -czf "$SOURCES/${name}.tar.gz" "${name}-src"
  sha256sum "$SOURCES/${name}.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local pkg="$1" body="$2" sum
  sum="$(mk_src "$pkg")"
  cat > "$RECIPES/$pkg/pkgbuild" <<PKG
pkg_name="$pkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="$pkg snapshot identity test"
pkg_homepage="https://example.invalid/$pkg"
pkg_license="MIT"
pkg_sources=("$SOURCES/$pkg.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

write_recipe alpha '  mkdir -p "$PKG_DESTDIR/usr/share/alpha"; printf "alpha
" > "$PKG_DESTDIR/usr/share/alpha/payload.txt"'
write_recipe beta '  mkdir -p "$PKG_DESTDIR/usr/share/beta"; printf "beta
" > "$PKG_DESTDIR/usr/share/beta/payload.txt"'

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

run_pkg install alpha >/dev/null
run_pkg remove alpha >/dev/null
snapshot_archive="$(find "$SNAPROOT/alpha" -maxdepth 1 -type f -name '*.tar' | head -n1)"
assert_exists "$snapshot_archive"
assert_exists "${snapshot_archive%.tar}.meta"
assert_exists "${snapshot_archive%.tar}.db/meta"

grep -Ev '^package=' "${snapshot_archive%.tar}.meta" > "${snapshot_archive%.tar}.meta.tmp"
mv "${snapshot_archive%.tar}.meta.tmp" "${snapshot_archive%.tar}.meta"
grep -Ev '^name=' "${snapshot_archive%.tar}.db/meta" > "${snapshot_archive%.tar}.db/meta.tmp"
mv "${snapshot_archive%.tar}.db/meta.tmp" "${snapshot_archive%.tar}.db/meta"

if run_pkg rollback beta "$snapshot_archive" >"$TEST_ROOT/rollback.out" 2>"$TEST_ROOT/rollback.err"; then
  fail 'rollback deveria rejeitar snapshot adulterado sem identidade obrigatória'
fi
assert_file_contains "$TEST_ROOT/rollback.err" 'sem campo package no metadata'
assert_not_exists "$DBROOT/installed/beta"
assert_not_exists "$SYSROOT/usr/share/alpha/payload.txt"
assert_not_exists "$SYSROOT/usr/share/beta/payload.txt"
pass 'rollback rejeita snapshot adulterado com falha controlada e sem restauração parcial'
echo "Todos os testes de identidade de snapshot passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-targeted-trigger-safe-XXXXXX)"
trap 'rm -rf "$TEST_ROOT"' EXIT
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; BINROOT="$TEST_ROOT/bin"; CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/share/man/man1" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/manpkg/patches" "$RECIPES/manpkg/files" "$RECIPES/manpkg/hooks" "$SOURCES" "$BINROOT"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_MANDb_BIN="$BINROOT/mandb"
CFG
cat > "$BINROOT/mandb" <<'MAND'
#!/usr/bin/env bash
set -euo pipefail
printf 'MANDb-called
' >> "${MANDb_MARKER:?}"
MAND
chmod +x "$BINROOT/mandb"
printf 'dummy man source
' > "$SOURCES/manpkg-1.0.0.txt"
sum="$(sha256sum "$SOURCES/manpkg-1.0.0.txt" | awk '{print $1}')"
cat > "$RECIPES/manpkg/pkgbuild" <<PKG
pkg_name="manpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="manual pages"
pkg_sources=("$SOURCES/manpkg-1.0.0.txt")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/man/man1"; printf '.TH MANPKG 1
.SH NAME
manpkg
' > "\$PKG_DESTDIR/usr/share/man/man1/manpkg.1"; }
PKG
MANDb_MARKER="$TEST_ROOT/mandb.marker" PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install manpkg >/dev/null
[[ ! -e "$TEST_ROOT/mandb.marker" ]] || { echo '[FAIL] mandb foi executado contra sysroot não-raiz'; exit 1; }
grep -R -Fq 'Ignorando mandb fora da raiz ativa' "$LOGROOT" || { echo '[FAIL] aviso de skip do mandb não encontrado'; exit 1; }
echo '[PASS] mandb é ignorado com sysroot isolado para evitar alterar o host'

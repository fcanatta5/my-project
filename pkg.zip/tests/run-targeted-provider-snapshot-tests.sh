#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-provider-snapshot-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$2', obtido '$1'"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_dir() { [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$SYSROOT/etc"
mkdir -p "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
PKG_MAX_SNAPSHOTS_PER_PACKAGE=3
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" provides="$4" conflicts="$5" body="$6"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe targeted provider/snapshot test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

call_func() {
  local func="$1"
  shift
  PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s -- "$func" "$@" <<'BASH'
set -Eeuo pipefail
func="$1"
shift
source <(sed '$d' "$PKG_BIN")
load_config
"$func" "$@"
BASH
}

# 1) recipe_declares_name_or_provide aceita nome e provide da receita
write_recipe recipedup 1.0.0 '' '"recipedup" "virtual/recipe"' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/recipedup"\n  printf "ok\\n" > "$PKG_DESTDIR/usr/share/recipedup/file"\n'
call_func recipe_declares_name_or_provide recipedup recipedup >/dev/null
call_func recipe_declares_name_or_provide recipedup virtual/recipe >/dev/null
if call_func recipe_declares_name_or_provide recipedup virtual/missing >/dev/null 2>&1; then
  fail 'recipe_declares_name_or_provide deveria retornar falso para token inexistente'
fi
pass 'recipe_declares_name_or_provide resolve nome, provide e ausência corretamente'

# 2) pkg_names_and_provides deduplica nome repetido em provides
run_pkg install recipedup >/dev/null
names_and_provides="$(call_func pkg_names_and_provides recipedup)"
assert_eq "$names_and_provides" $'recipedup\nvirtual/recipe'
pass 'pkg_names_and_provides retorna conjunto único de nome+provides'

# 3) find_installed_provider prioriza match exato sobre provider colidente
write_recipe exactdep 1.0.0 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "real\\n" > "$PKG_DESTDIR/usr/lib/libexactdep.so"\n'
write_recipe altprovider 1.0.0 '' '"exactdep"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "alt\\n" > "$PKG_DESTDIR/usr/lib/libaltprovider.so"\n'
run_pkg install exactdep >/dev/null
run_pkg install altprovider >/dev/null
assert_eq "$(call_func find_installed_provider exactdep)" 'exactdep'
pass 'find_installed_provider prioriza pacote instalado com nome exato'

# 4) check_declared_dependencies_installed aceita dependência exata mesmo com provider extra
write_recipe exactconsumer 1.0.0 '"exactdep"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "consumer\\n" > "$PKG_DESTDIR/usr/bin/exactconsumer"\n'
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
load_recipe exactconsumer
CURRENT_LOG_DIR="$PKG_LOG_ROOT/check-deps"
mkdir -p "$CURRENT_LOG_DIR"
check_declared_dependencies_installed
BASH
pass 'check_declared_dependencies_installed usa o match exato sem marcar ambiguidade'

# 5) find_recipe_provider prioriza receita com nome exato sobre provider colidente
write_recipe exactrecipe 1.0.0 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/exactrecipe"\n  printf "exact\\n" > "$PKG_DESTDIR/usr/share/exactrecipe/file"\n'
write_recipe aliasrecipe 1.0.0 '' '"exactrecipe"' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/aliasrecipe"\n  printf "alias\\n" > "$PKG_DESTDIR/usr/share/aliasrecipe/file"\n'
assert_eq "$(call_func find_recipe_provider exactrecipe)" 'exactrecipe'
pass 'find_recipe_provider prioriza receita com diretório/nome exato'

# 6) resolve_recipe_dep_order mantém ordem topológica com provider de receita
write_recipe depvirt 1.0.0 '' '"virtual/depvirt"' '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "dep\\n" > "$PKG_DESTDIR/usr/lib/libdepvirt.so"\n'
write_recipe midvirt 1.0.0 '"virtual/depvirt"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/midvirt"\n  printf "mid\\n" > "$PKG_DESTDIR/usr/share/midvirt/file"\n'
write_recipe topvirt 1.0.0 '"midvirt"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/topvirt"\n  printf "top\\n" > "$PKG_DESTDIR/usr/share/topvirt/file"\n'
order_out="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
order=()
resolve_recipe_dep_order topvirt order
printf '%s\n' "${order[@]}"
BASH
)"
assert_eq "$order_out" $'depvirt\nmidvirt\ntopvirt'
pass 'resolve_recipe_dep_order calcula ordem topológica via provider de receita'

# 7) new_recipe_conflicts_with_installed_pkg detecta conflito contra provide instalado
write_recipe basevirt 1.0.0 '' '"virtual/editor"' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/basevirt"\n  printf "base\\n" > "$PKG_DESTDIR/usr/share/basevirt/file"\n'
run_pkg install basevirt >/dev/null
write_recipe editornew 1.0.0 '' '' '"virtual/editor"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "editor\\n" > "$PKG_DESTDIR/usr/bin/editornew"\n'
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
load_recipe editornew
new_recipe_conflicts_with_installed_pkg basevirt
BASH
pass 'new_recipe_conflicts_with_installed_pkg detecta conflito via provide do pacote instalado'

# 8) installed_pkg_conflicts_with_new_recipe ignora comentários/espaços no banco de conflitos
write_recipe blockerdb 1.0.0 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/blockerdb"\n  printf "block\\n" > "$PKG_DESTDIR/usr/share/blockerdb/file"\n'
run_pkg install blockerdb >/dev/null
cat > "$DBROOT/installed/blockerdb/conflicts" <<'CONFLICTS'
# comentário

   virtual/cli   
CONFLICTS
write_recipe cliapp 1.0.0 '' '"virtual/cli"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "cli\\n" > "$PKG_DESTDIR/usr/bin/cliapp"\n'
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
load_recipe cliapp
installed_pkg_conflicts_with_new_recipe blockerdb
BASH
pass 'installed_pkg_conflicts_with_new_recipe lida com comentários e espaços em branco'

# 9) snapshot_installed_package funciona sem CURRENT_LOG_DIR e sanitiza o reason no filename
write_recipe snappkg 1.0.0 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "snap\\n" > "$PKG_DESTDIR/usr/bin/snappkg"\n'
run_pkg install snappkg >/dev/null
snapshot_tar="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
CURRENT_LOG_DIR=""
snapshot_installed_package snappkg 'manual/run'
find "$PKG_SNAPSHOT_ROOT/snappkg" -maxdepth 1 -type f -name '*manual_run*.tar' | sort | tail -n1
BASH
)"
assert_file "$snapshot_tar"
assert_file "${snapshot_tar%.tar}.files"
assert_file "${snapshot_tar%.tar}.manifest"
assert_file "${snapshot_tar%.tar}.meta"
assert_dir "${snapshot_tar%.tar}.db"
assert_file_contains "${snapshot_tar%.tar}.meta" 'reason=manual/run'
pass 'snapshot_installed_package cria snapshot válido sem CURRENT_LOG_DIR e sanitiza o filename'

# 10) prune_snapshots remove sidecars órfãos antigos e respeita o limite
manual_snapdir="$SNAPROOT/orphanpkg"
mkdir -p "$manual_snapdir/20240101-old.db" "$manual_snapdir/20240102-mid.db" "$manual_snapdir/20240103-new.db"
: > "$manual_snapdir/20240101-old.meta"
: > "$manual_snapdir/20240101-old.files"
: > "$manual_snapdir/20240102-mid.tar"
: > "$manual_snapdir/20240102-mid.meta"
: > "$manual_snapdir/20240102-mid.files"
: > "$manual_snapdir/20240103-new.tar"
: > "$manual_snapdir/20240103-new.meta"
: > "$manual_snapdir/20240103-new.files"
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
PKG_MAX_SNAPSHOTS_PER_PACKAGE=2
prune_snapshots orphanpkg
BASH
assert_not_exists "$manual_snapdir/20240101-old.meta"
assert_not_exists "$manual_snapdir/20240101-old.files"
assert_not_exists "$manual_snapdir/20240101-old.db"
assert_file "$manual_snapdir/20240102-mid.tar"
assert_file "$manual_snapdir/20240103-new.tar"
pass 'prune_snapshots remove conjuntos órfãos antigos e respeita o limite configurado'

# 11) prune_snapshots preserva o snapshot realmente mais novo por mtime, não por nome
mtime_snapdir="$SNAPROOT/mtimepkg"
mkdir -p "$mtime_snapdir/z-old.db" "$mtime_snapdir/a-new.db"
: > "$mtime_snapdir/z-old.tar"
: > "$mtime_snapdir/z-old.meta"
: > "$mtime_snapdir/z-old.files"
: > "$mtime_snapdir/a-new.tar"
: > "$mtime_snapdir/a-new.meta"
: > "$mtime_snapdir/a-new.files"
touch -t 202401010101 "$mtime_snapdir/z-old.tar" "$mtime_snapdir/z-old.meta" "$mtime_snapdir/z-old.files" "$mtime_snapdir/z-old.db"
touch -t 202401020101 "$mtime_snapdir/a-new.tar" "$mtime_snapdir/a-new.meta" "$mtime_snapdir/a-new.files" "$mtime_snapdir/a-new.db"
PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
PKG_MAX_SNAPSHOTS_PER_PACKAGE=1
prune_snapshots mtimepkg
BASH
assert_not_exists "$mtime_snapdir/z-old.tar"
assert_not_exists "$mtime_snapdir/z-old.meta"
assert_not_exists "$mtime_snapdir/z-old.files"
assert_not_exists "$mtime_snapdir/z-old.db"
assert_file "$mtime_snapdir/a-new.tar"
assert_file "$mtime_snapdir/a-new.meta"
assert_file "$mtime_snapdir/a-new.files"
assert_dir "$mtime_snapdir/a-new.db"
pass 'prune_snapshots preserva o snapshot realmente mais novo por mtime'

echo "Todos os testes focados de providers/conflicts/snapshots passaram em $TEST_ROOT"

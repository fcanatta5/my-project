#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-targeted-repo-cmd-XXXXXX)"
trap 'rm -rf "$TEST_ROOT"' EXIT
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; REPO="$TEST_ROOT/repo"; CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/share/test" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/repopkg/patches" "$RECIPES/repopkg/files" "$RECIPES/repopkg/hooks" "$SOURCES" "$REPO"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPO"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
printf 'repo cmd source
' > "$SOURCES/repopkg-1.0.0.txt"
sum="$(sha256sum "$SOURCES/repopkg-1.0.0.txt"|awk '{print $1}')"
cat > "$RECIPES/repopkg/pkgbuild" <<PKG
pkg_name="repopkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="repo cmd"
pkg_sources=("$SOURCES/repopkg-1.0.0.txt")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/test"; printf ok > "\$PKG_DESTDIR/usr/share/test/repopkg"; }
PKG
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" pack repopkg "$REPO" >/dev/null
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" repo-index "$REPO" >/dev/null
out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" repo-list "$REPO")"
grep -Fq 'repopkg' <<<"$out" || { echo '[FAIL] repo-list não listou repopkg'; exit 1; }
echo '[PASS] repo-index e repo-list funcionam pelo dispatcher principal'

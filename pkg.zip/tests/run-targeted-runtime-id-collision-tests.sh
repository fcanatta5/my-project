#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-runtime-id-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$2', obtido '$1'"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_dir() { [[ -d "$1" ]] || fail "diretório ausente: $1"; }

mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" body="$3"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe runtime id collision test"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
call_func() {
  local func="$1"; shift
  PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s -- "$func" "$@" <<'INNER'
set -Eeuo pipefail
func="$1"; shift
source <(sed '$d' "$PKG_BIN")
load_config
"$func" "$@"
INNER
}

write_recipe fastpkg 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "fast\\n" > "$PKG_DESTDIR/usr/bin/fastpkg"'
run_pkg install fastpkg >/dev/null

before_logs=$(find "$LOGROOT/fastpkg" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
run_pkg reinstall fastpkg >/dev/null
run_pkg reinstall fastpkg >/dev/null
after_logs=$(find "$LOGROOT/fastpkg" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')
if (( after_logs < before_logs + 2 )); then
  fail 'reexecuções rápidas reutilizaram diretório de log em vez de criar IDs únicos'
fi
pass 'setup_runtime cria diretórios de log únicos para execuções rápidas'

snap1="$(call_func snapshot_installed_package fastpkg manual >/dev/null; find "$SNAPROOT/fastpkg" -maxdepth 1 -type f -name '*-manual.tar' | sort | tail -n1)"
snap2="$(call_func snapshot_installed_package fastpkg manual >/dev/null; find "$SNAPROOT/fastpkg" -maxdepth 1 -type f -name '*-manual.tar' | sort | tail -n1)"
assert_file "$snap1"
assert_file "$snap2"
[[ "$snap1" != "$snap2" ]] || fail 'snapshots rápidos com mesmo reason colidiram no mesmo nome de arquivo'
pass 'snapshot_installed_package cria arquivos únicos para mesmo pacote/reason em sequência rápida'

call_func register_removed_package fastpkg "$DBROOT/installed/fastpkg" remove >/dev/null
call_func register_removed_package fastpkg "$DBROOT/installed/fastpkg" remove >/dev/null
removed_count=$(find "$STATEROOT/removed/fastpkg" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')
assert_eq "$removed_count" '2'
pass 'register_removed_package preserva múltiplas remoções rápidas sem sobrescrever histórico'

echo "Todos os testes de IDs únicos passaram em $TEST_ROOT"

# 4) unique_runtime_id sanitizes unsafe prefixes used in filesystem artifacts
raw_id="$(PKG_CONFIG_FILE="$CONF" PKG_BIN="$PKG_BIN" bash -s <<'BASH'
set -Eeuo pipefail
source <(sed '$d' "$PKG_BIN")
load_config
unique_runtime_id 'manual/run with spaces'
BASH
)"
case "$raw_id" in
  *'/'*|*' '*) fail "unique_runtime_id deveria sanitizar prefixo inseguro: $raw_id" ;;
esac
pass 'unique_runtime_id sanitiza prefixos inseguros para uso em paths'

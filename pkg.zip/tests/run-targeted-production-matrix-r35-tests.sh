#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r35-matrix-XXXXXX)}"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_case(){
  local profile="$1" umask_value="$2" locale="$3"
  local root="$TEST_ROOT/$profile"
  local sysroot="$root/sysroot" dbroot="$root/db" stateroot="$root/state" lockroot="$root/locks" logroot="$root/logs" cacheroot="$root/cache" tmproot="$root/tmp" snaproot="$root/snapshots" recipes="$root/recipes"
  local conf="$root/pkg.conf"
  mkdir -p "$sysroot/usr/bin" "$dbroot" "$stateroot" "$lockroot" "$logroot" "$cacheroot" "$tmproot" "$snaproot" "$recipes"
  cat > "$conf" <<CFG
PKG_SYSROOT="$sysroot"
PKG_DB_ROOT="$dbroot"
PKG_STATE_ROOT="$stateroot"
PKG_LOCK_ROOT="$lockroot"
PKG_REMOVED_DB_ROOT="$stateroot/removed"
PKG_LOG_ROOT="$logroot"
PKG_HISTORY_FILE="$logroot/history.log"
PKG_CACHE_ROOT="$cacheroot"
PKG_TMP_ROOT="$tmproot"
PKG_RECIPES_ROOT="$recipes"
PKG_SNAPSHOT_ROOT="$snaproot"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
  local out="$root/output.log"
  (
    umask "$umask_value"
    export LC_ALL="$locale"
    export LANG="$locale"
    export HOME="$root/home"
    mkdir -p "$HOME"
    PKG_CONFIG_FILE="$conf" bash "$PKG_BIN" help
    PKG_CONFIG_FILE="$conf" bash "$PKG_BIN" list
    PKG_CONFIG_FILE="$conf" bash "$PKG_BIN" doctor || true
  ) >"$out" 2>&1
  grep -Fq 'pkg 0.4.0' "$out" || fail "help não mostrou versão no profile $profile"
  [[ -d "$sysroot" && -d "$dbroot" && -d "$lockroot" && -d "$snaproot" ]] || fail "árvore incompleta no profile $profile"
  pass "profile $profile passou com umask=$umask_value locale=$locale"
}
run_case baseline 022 C
run_case hardened 077 C.UTF-8
run_case portable 022 POSIX
echo "Todos os testes de matriz de ambiente R35 passaram em $TEST_ROOT"

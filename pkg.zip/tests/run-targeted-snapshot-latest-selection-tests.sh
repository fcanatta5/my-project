#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-snapshot-latest-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_meta_value(){ grep -Fq "$1=$2" "$3" || fail "meta ausente em $3: $1=$2"; }

mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_MAX_SNAPSHOTS_PER_PACKAGE=20
CFG

mk_src(){
  local name="$1" dir
  dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe(){
  local recipe="$1" version="$2" provides="$3" conflicts="$4" replaces="$5" body="$6"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe latest snapshot selection test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=($replaces)
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package() {
$body
}
PKG
}

run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe snapsel 1.0.0 '"virtual/snapsel"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "snapsel-v1\\n" > "$PKG_DESTDIR/usr/bin/snapsel"\n'
run_pkg install snapsel >/dev/null

write_recipe snapreplacer 1.0.0 '"virtual/snapsel"' '"virtual/snapsel"' '"virtual/snapsel"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "replaced\\n" > "$PKG_DESTDIR/usr/bin/snapsel"\n'
run_pkg install snapreplacer >/dev/null
assert_file_contains "$SYSROOT/usr/bin/snapsel" 'replaced'
run_pkg remove snapreplacer >/dev/null

write_recipe snapsel 2.0.0 '"virtual/snapsel"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "snapsel-v2\\n" > "$PKG_DESTDIR/usr/bin/snapsel"\n'
run_pkg install snapsel >/dev/null
assert_file_contains "$SYSROOT/usr/bin/snapsel" 'snapsel-v2'

write_recipe snapsel 3.0.0 '"virtual/snapsel"' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "snapsel-v3\\n" > "$PKG_DESTDIR/usr/bin/snapsel"\n'
run_pkg upgrade snapsel >/dev/null
assert_file_contains "$SYSROOT/usr/bin/snapsel" 'snapsel-v3'
assert_meta_value version 3.0.0 "$DBROOT/installed/snapsel/meta"

run_pkg rollback snapsel >/dev/null
assert_file_contains "$SYSROOT/usr/bin/snapsel" 'snapsel-v2'
assert_meta_value version 2.0.0 "$DBROOT/installed/snapsel/meta"
pass 'rollback latest seleciona o snapshot mais recente por tempo, não por ordem lexicográfica do nome'

echo "Todos os testes de seleção do latest snapshot passaram em $TEST_ROOT"

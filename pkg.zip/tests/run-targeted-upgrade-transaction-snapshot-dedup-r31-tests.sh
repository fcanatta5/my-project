#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r31-snapshot-dedup-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1" d; d="$SOURCES/${n}-src"; mkdir -p "$d"; printf '%s
' "${n} source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/${n}.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/${n}.tar.gz"|awk '{print $1}'; }
write_recipe(){
  local r="$1" v="$2" rel="$3" body="$4" dir sum
  dir="$RECIPES/$r"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$r-$v")"
  {
    printf 'pkg_name="%s"
' "$r"
    printf 'pkg_version="%s"
' "$v"
    printf 'pkg_release="%s"
' "$rel"
    printf 'pkg_desc="%s"
' "$r"
    printf 'pkg_homepage=x
'
    printf 'pkg_license=x
'
    printf 'pkg_sources=("%s/%s-%s.tar.gz")
' "$SOURCES" "$r" "$v"
    printf 'pkg_sha256s=("%s")
' "$sum"
    printf 'pkg_depends=()
'
    printf 'pkg_build_depends=()
'
    printf 'pkg_conflicts=()
'
    printf 'pkg_provides=()
'
    printf 'pkg_replaces=()
'
    printf 'pkg_patches=()
'
    printf 'pkg_options=()
'
    printf 'pkg_config_files=()
'
    printf 'build(){ :; }
'
    printf 'package(){
%s
}
' "$body"
  } > "$dir/pkgbuild"
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 120s bash "$PKG_BIN" "$@"; }
write_recipe dedup 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "v1\n" > "$PKG_DESTDIR/usr/bin/dedup"'
run_pkg install dedup >/dev/null
write_recipe dedup 1.1.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "v2\n" > "$PKG_DESTDIR/usr/bin/dedup"'
run_pkg upgrade dedup >/dev/null
count_pre=$(find "$SNAPROOT/dedup" -maxdepth 1 -type f -name '*-pre.tar' | wc -l | tr -d ' ')
count_preinstall=$(find "$SNAPROOT/dedup" -maxdepth 1 -type f -name '*-preinstall.tar' | wc -l | tr -d ' ')
[[ "$count_pre" == "1" ]] || fail "esperado 1 snapshot transacional pre, obtido $count_pre"
[[ "$count_preinstall" == "0" ]] || fail "snapshot preinstall redundante ainda foi criado: $count_preinstall"
pass "upgrade transacional reutiliza snapshot prestate sem duplicar preinstall"

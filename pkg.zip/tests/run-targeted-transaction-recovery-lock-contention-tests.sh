#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-tx-recovery-lock-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT/installed/heldpkg" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
printf '/usr/bin/held\n' > "$DBROOT/installed/heldpkg/files"
: > "$DBROOT/installed/heldpkg/dirs"
cat > "$DBROOT/installed/heldpkg/meta" <<META
name=heldpkg
version=1.0.0
release=1
META
TXROOT="$TMPROOT/tx-stale-lock-test"
mkdir -p "$TXROOT/payloads"
cat > "$TXROOT/tx.meta" <<META
state=prepared
pid=999999
target_recipe=heldpkg
META
printf 'heldpkg\tinstalled\t\n' > "$TXROOT/prestate.list"
exec 9>"$LOCKROOT/heldpkg.lock"
flock -n 9 || fail "não conseguiu preparar lock ocupado"
if ! PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" list >/dev/null; then
  fail "execução não deveria falhar quando recovery transacional encontra lock ocupado"
fi
[[ -d "$TXROOT" ]] || fail "tx_root não deveria ser removido quando recovery é adiado por lock ocupado"
recovery_log_dir="$LOGROOT/transactions/$(basename "$TXROOT")"
assert_file_contains "$recovery_log_dir/main.log" 'Recovery transacional adiado por lock ocupado'
pass 'autorecovery transacional adia recovery com lock ocupado sem abortar execução concorrente'
echo "Todos os testes de contenção de lock na recovery transacional passaram em $TEST_ROOT"

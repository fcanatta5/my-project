#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-implicit-dirs-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
REPOROOT="$TEST_ROOT/repo"
CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$REPOROOT"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$TEST_ROOT/recipes"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPOROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
mkdir -p "$TEST_ROOT/pkg/payload/usr/bin" "$TEST_ROOT/pkg/meta"
cat > "$TEST_ROOT/pkg/.PKGINFO" <<PKG
pkgname=implicit-parent-dirs
pkgver=1.0.0
pkgrelease=1
pkgdesc=implicit parent dirs
PKG
printf '/usr/bin/hello\n' > "$TEST_ROOT/pkg/meta/files"
: > "$TEST_ROOT/pkg/meta/dirs"
printf 'name=implicit-parent-dirs\nversion=1.0.0\nrelease=1\n' > "$TEST_ROOT/pkg/meta/meta"
printf '#!/bin/sh\necho implicit-ok\n' > "$TEST_ROOT/pkg/payload/usr/bin/hello"
chmod +x "$TEST_ROOT/pkg/payload/usr/bin/hello"
tar --zstd -cf "$REPOROOT/implicit-parent-dirs-1.0.0-1.pkg.tar.zst" -C "$TEST_ROOT/pkg" .
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install-bin "$REPOROOT/implicit-parent-dirs-1.0.0-1.pkg.tar.zst" >/dev/null
assert_file_contains "$SYSROOT/usr/bin/hello" 'implicit-ok'
assert_file_contains "$DBROOT/installed/implicit-parent-dirs/files" '/usr/bin/hello'
pass 'install-bin aceita apenas diretórios-pai implícitos do payload quando o manifesto declara o arquivo final'

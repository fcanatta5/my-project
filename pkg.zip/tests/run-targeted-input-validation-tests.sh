#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-validate-XXXXXX)}"
CONF="$TEST_ROOT/pkg.conf"
RECIPES="$TEST_ROOT/recipes"
TMPROOT="$TEST_ROOT/tmp"
LOGROOT="$TEST_ROOT/logs"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
CACHEROOT="$TEST_ROOT/cache"
SNAPROOT="$TEST_ROOT/snapshots"
SYSROOT="$TEST_ROOT/sysroot"
SOURCES="$TEST_ROOT/sources"
trap 'rm -rf "$TEST_ROOT"' EXIT

mkdir -p "$RECIPES" "$TMPROOT" "$LOGROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$CACHEROOT" "$SNAPROOT" "$SYSROOT/usr" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
pass() { echo "[PASS] $*"; }
fail() { echo "[FAIL] $*" >&2; exit 1; }

mk_recipe() {
  local name="$1" body="$2"
  mkdir -p "$RECIPES/$name"
  cat > "$RECIPES/$name/pkgbuild" <<PKG
$body
PKG
}

mk_recipe badname '
pkg_name="../../evil"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ :; }
'
if run_pkg build badname >/dev/null 2>&1; then
  fail "pkg_name inseguro deveria falhar"
fi
pass "pkg_name com path traversal é rejeitado"

mk_recipe badtoken '
pkg_name="okpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=("../escape")
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ :; }
'
if run_pkg build badtoken >/dev/null 2>&1; then
  fail "token de relacionamento inseguro deveria falhar"
fi
pass "depends/provides/conflicts/replaces com traversal são rejeitados"

mk_recipe badconfig '
pkg_name="cfgpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=("/etc/../shadow")
build(){ :; }
package(){ :; }
'
if run_pkg build badconfig >/dev/null 2>&1; then
  fail "pkg_config_files não canônico deveria falhar"
fi
pass "pkg_config_files exige caminho absoluto e canônico"

mk_recipe badbuilddep '
pkg_name="builddepbad"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=()
pkg_build_depends=("../toolchain")
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ :; }
'
if run_pkg build badbuilddep >/tmp/input4.out 2>&1; then
  fail "pkg_build_depends com traversal deveria falhar"
fi
pass "pkg_build_depends com traversal é rejeitado"

printf 'rootenvsync-source\n' > "$SOURCES/rootenvsync-1.0.0.txt"
rootenvsync_sha="$(sha256sum "$SOURCES/rootenvsync-1.0.0.txt" | awk '{print $1}')"
mkdir -p "$RECIPES/rootenvsync/hooks"
cat > "$RECIPES/rootenvsync/hooks/pre_fetch.sh" <<'HOOK'
#!/usr/bin/env bash
set -euo pipefail
[[ "$PKG_ROOT" == "$PKG_SYSROOT" ]]
mkdir -p "$PKG_SYSROOT/var/lib/rootenvsync"
printf '%s\n' "$PKG_ROOT" > "$PKG_SYSROOT/var/lib/rootenvsync/root.txt"
HOOK
chmod +x "$RECIPES/rootenvsync/hooks/pre_fetch.sh"
cat > "$RECIPES/rootenvsync/pkgbuild" <<PKG
pkg_name="rootenvsync"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="test"
pkg_sources=("$SOURCES/rootenvsync-1.0.0.txt")
pkg_sha256s=("$rootenvsync_sha")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ test -f rootenvsync-1.0.0.txt; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/rootenvsync"; printf ok > "\$PKG_DESTDIR/usr/share/rootenvsync/installed.txt"; }
PKG
run_pkg install rootenvsync >/dev/null
[[ "$(cat "$SYSROOT/var/lib/rootenvsync/root.txt")" == "$SYSROOT" ]] || fail 'PKG_ROOT exportado diverge do sysroot configurado'
pass "PKG_ROOT é sincronizado com PKG_SYSROOT para hooks e build isolado"



mk_recipe badunit '
pkg_name="unitbad"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_systemd_units_enable=("../evil.service")
build(){ :; }
package(){ :; }
'
if run_pkg build badunit >/dev/null 2>&1; then
  fail "pkg_systemd_units_enable inseguro deveria falhar"
fi
pass "unidades systemd inválidas são rejeitadas na receita"

mk_recipe badalt '
pkg_name="altbad"
pkg_version="1.0.0"
pkg_release="1"
pkg_sources=("/dev/null")
pkg_sha256s=("SKIP")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_alternatives=("demo|/usr/bin/demo|/usr/../bin/demo.real|prio")
build(){ :; }
package(){ :; }
'
if run_pkg build badalt >/dev/null 2>&1; then
  fail "pkg_alternatives inválido deveria falhar"
fi
pass "alternativas inválidas são rejeitadas na receita"

echo "Todos os testes de validação passaram em $TEST_ROOT"

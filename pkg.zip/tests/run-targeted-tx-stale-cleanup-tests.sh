#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-tx-stale-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_no_glob(){ ! compgen -G "$1" >/dev/null || fail "match inesperado: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1"; local d="$SOURCES/$n-src"; mkdir -p "$d"; echo "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz"|awk '{print $1}'; }
write_recipe(){ local r="$1" v="$2" rel="$3" deps="$4" body="$5" dir sum depends_line; dir="$RECIPES/$r"; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; depends_line='pkg_depends=()'; [[ -n "$deps" ]] && depends_line="pkg_depends=($deps)"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="$rel"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
write_recipe dep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "dep-v1\\n" > "$PKG_DESTDIR/usr/lib/dep.so"'
write_recipe app 1.0.0 1 '"dep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app-v1\\n" > "$PKG_DESTDIR/usr/bin/app"'
run_pkg install --deps app >/dev/null
write_recipe dep 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "dep-v2\\n" > "$PKG_DESTDIR/usr/lib/dep.so"'
write_recipe app 2.0.0 1 '"dep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app-v2\\n" > "$PKG_DESTDIR/usr/bin/app"'
(
  exec 9>"$LOCKROOT/dep.lock"
  flock -n 9
  sleep 4
) &
locker_pid=$!
sleep 0.3
if run_pkg upgrade app >/dev/null 2>&1; then
  kill "$locker_pid" 2>/dev/null || true
  wait "$locker_pid" 2>/dev/null || true
  fail "upgrade deveria falhar cedo com lock ocupado no conjunto"
fi
kill "$locker_pid" 2>/dev/null || true
wait "$locker_pid" 2>/dev/null || true
assert_file_contains "$SYSROOT/usr/lib/dep.so" 'dep-v1'
assert_file_contains "$SYSROOT/usr/bin/app" 'app-v1'
assert_no_glob "$TMPROOT/tx-*"
pass "upgrade transacional com lock ocupado limpa payloads e tx root sem deixar resíduos"
echo "Todos os testes de limpeza de tx root passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-binarch-compat-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; BINARCH="$TEST_ROOT/binarchives"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == 1 ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT/usr/share" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES" "$BINARCH"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_ARCHIVE_ROOT="$BINARCH"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_CREATE_BINARY_ARCHIVE=1
PKG_KEEP_WORKDIR=1
CFG
srcdir="$SOURCES/demo-1.0.0-src"
mkdir -p "$srcdir"
printf 'demo\n' > "$srcdir/README"
tar -C "$SOURCES" -czf "$SOURCES/demo-1.0.0.tar.gz" demo-1.0.0-src
sum="$(sha256sum "$SOURCES/demo-1.0.0.tar.gz" | awk '{print $1}')"
mkdir -p "$RECIPES/demo/patches" "$RECIPES/demo/files" "$RECIPES/demo/hooks"
cat > "$RECIPES/demo/pkgbuild" <<PKG
pkg_name="demo"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="demo"
pkg_homepage="https://example.invalid/demo"
pkg_license="MIT"
pkg_sources=("$SOURCES/demo-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
build(){ :; }
package(){
  mkdir -p "\$PKG_DESTDIR/usr/share/demo"
  printf 'payload\n' > "\$PKG_DESTDIR/usr/share/demo/payload.txt"
}
PKG
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" build demo >/dev/null
[[ -f "$BINARCH/demo-1.0.0-1.pkg.tar.zst" ]] || fail 'pacote binário flat não foi criado'
[[ -f "$BINARCH/demo/demo-1.0.0-1.tar.zst" ]] || fail 'arquivo legado de stage por pacote não foi criado'
tar --zstd -tf "$BINARCH/demo/demo-1.0.0-1.tar.zst" | grep -Fxq './usr/share/demo/payload.txt' || fail 'arquivo legado não contém payload esperado'
pass 'archive_stage_if_enabled gera pacote binário e arquivo legado de stage compatível'

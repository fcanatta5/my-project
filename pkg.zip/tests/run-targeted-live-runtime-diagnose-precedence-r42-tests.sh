#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r42-live-diag-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; RECIPES="$TEST_ROOT/recipes"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_eq(){ [[ "$1" == "$2" ]] || fail "esperado '$2', obtido '$1'"; }
mkdir -p "$SYSROOT" "$DBROOT/installed/foo/logs" "$STATEROOT/removed" "$LOCKROOT" "$LOGROOT/foo/oldrun" "$LOGROOT/foo/liverun" "$CACHEROOT" "$TMPROOT" "$RECIPES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
cat > "$DBROOT/installed/foo/logs/operation.meta" <<'META'
package=foo
status=ok
detail=installed-db
META
sleep 1
cat > "$LOGROOT/foo/liverun/operation.meta" <<'META'
package=foo
status=running
detail=live-runtime
META
printf 'runtime-main\n' > "$LOGROOT/foo/liverun/main.log"
out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" diagnose foo latest)"
path_out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" logs foo path)"
main_out="$(PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" logs foo main)"
grep -Fq 'detail=live-runtime' <<<"$out" || fail "diagnose não priorizou runtime ativo"
assert_eq "$path_out" "$LOGROOT/foo/liverun"
assert_eq "$main_out" 'runtime-main'
pass 'diagnose/logs priorizam runtime ativo mais recente sobre logs antigos do banco instalado'
echo "Todos os testes de precedência de runtime ativo r42 passaram em $TEST_ROOT"

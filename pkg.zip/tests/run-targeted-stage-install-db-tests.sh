#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-stage-install-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
BINARCH="$TEST_ROOT/binarchives"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_dir() { [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_symlink() { [[ -L "$1" ]] || fail "symlink ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES" "$BINARCH"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_ARCHIVE_ROOT="$BINARCH"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
PKG_CREATE_BINARY_ARCHIVE=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" release="$3" conflicts="$4" replaces="$5" config_files="$6" body="$7"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe stage/install/db test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=()
pkg_replaces=($replaces)
pkg_patches=()
pkg_options=()
pkg_config_files=($config_files)
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

# 1) archive_stage_if_enabled + sync_stage_to_sysroot + install_config_aware must preserve symlink-to-dir
write_recipe linkpkg 1.0.0 1 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/real"
  printf "payload\\n" > "$PKG_DESTDIR/usr/share/real/file"
  ln -s real "$PKG_DESTDIR/usr/share/linkdir"'
run_pkg build linkpkg >/dev/null
archive="$BINARCH/linkpkg/linkpkg-1.0.0-1.tar.zst"
assert_file "$archive"
if ! tar --zstd -tf "$archive" | grep -Fxq './usr/share/linkdir'; then
  fail 'arquivo binário não contém o symlink esperado no stage arquivado'
fi
run_pkg install linkpkg >/dev/null
assert_symlink "$SYSROOT/usr/share/linkdir"
[[ "$(readlink "$SYSROOT/usr/share/linkdir")" == 'real' ]] || fail 'symlink instalado aponta para destino incorreto'
assert_file_contains "$DBROOT/installed/linkpkg/files" '/usr/share/linkdir'
if grep -Fqx '/usr/share/linkdir' "$DBROOT/installed/linkpkg/dirs"; then
  fail 'symlink de diretório não deve ser registrado como diretório no banco'
fi
run_pkg reinstall linkpkg >/dev/null
assert_symlink "$SYSROOT/usr/share/linkdir"
pass 'sync_stage_to_sysroot, install_config_aware, save_installed_db, archive_stage_if_enabled e check_manifest_conflicts preservam symlink-to-dir corretamente'

# 2) config files must be preserved as .new when locally modified
write_recipe confpkg 1.0.0 1 '' '' '"/etc/confpkg.conf"' $'  mkdir -p "$PKG_DESTDIR/etc"
  printf "version=1\\n" > "$PKG_DESTDIR/etc/confpkg.conf"'
run_pkg install confpkg >/dev/null
printf 'local-change\n' > "$SYSROOT/etc/confpkg.conf"
write_recipe confpkg 2.0.0 1 '' '' '"/etc/confpkg.conf"' $'  mkdir -p "$PKG_DESTDIR/etc"
  printf "version=2\\n" > "$PKG_DESTDIR/etc/confpkg.conf"'
run_pkg reinstall confpkg >/dev/null
assert_file_contains "$SYSROOT/etc/confpkg.conf" 'local-change'
assert_file_contains "$SYSROOT/etc/confpkg.conf.new" 'version=2'
pass 'install_config_aware preserva config local e grava .new no reinstall'

# 3) remove_files_from_db must remove old files during reinstall and save_installed_db must persist updated metadata/logs
write_recipe swapbin 1.0.0 1 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "v1\\n" > "$PKG_DESTDIR/usr/bin/oldbin"'
run_pkg install swapbin >/dev/null
write_recipe swapbin 2.0.0 1 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "v2\\n" > "$PKG_DESTDIR/usr/bin/newbin"'
run_pkg reinstall swapbin >/dev/null
assert_not_exists "$SYSROOT/usr/bin/oldbin"
assert_file "$SYSROOT/usr/bin/newbin"
assert_file_contains "$DBROOT/installed/swapbin/files" '/usr/bin/newbin'
assert_not_exists "$DBROOT/installed/swapbin/files.tmp"
assert_dir "$DBROOT/installed/swapbin/logs"
pass 'remove_files_from_db remove arquivos antigos e save_installed_db persiste banco/logs atualizados'

# 4) validate_package_relationships/check_manifest_conflicts must reject replaces without explicit conflicts
write_recipe legacyapp 1.0.0 1 '' '' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "legacy\\n" > "$PKG_DESTDIR/usr/bin/sharedcmd"'
run_pkg install legacyapp >/dev/null
write_recipe newapp 1.0.0 1 '' '"legacyapp"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"
  printf "new\\n" > "$PKG_DESTDIR/usr/bin/sharedcmd"'
if run_pkg install newapp >/dev/null 2>&1; then
  fail 'install deveria falhar para replaces sem conflito explícito quando PKG_ALLOW_REPLACE_WITHOUT_CONFLICTS=0'
fi
pass 'validate_package_relationships e check_manifest_conflicts barram replaces sem conflito explícito'

echo "Todos os testes focados de stage/install/db passaram em $TEST_ROOT"

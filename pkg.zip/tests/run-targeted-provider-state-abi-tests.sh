#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-prov-state-abi-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == 1 ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file(){ [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_PROTECTED_PATHS=(/ /usr /etc /var)
PKG_ASSUME_YES=1
PKG_COLOR=0
CFG
mk_src(){ local name="$1" dir; dir="$SOURCES/$name-src"; mkdir -p "$dir"; printf '%s\n' "$name" > "$dir/README"; tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"; sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'; }
write_recipe(){
  local recipe="$1" version="$2" depends="$3" provides="$4" priority="$5" body="$6" sum
  mkdir -p "$RECIPES/$recipe"
  sum="$(mk_src "$recipe-$version")"
  cat > "$RECIPES/$recipe/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=($provides)
pkg_replaces=()
pkg_provider_priority="$priority"
build(){ :; }
package(){
$body
}
PKG
}
write_recipe provlow 1.0.0 '' '"virtual/editor"' 10 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf low > "$PKG_DESTDIR/usr/bin/editor-low"'
write_recipe provhigh 1.0.0 '' '"virtual/editor"' 200 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf high > "$PKG_DESTDIR/usr/bin/editor-high"'
write_recipe consumer 1.0.0 '"virtual/editor"' '' 100 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf consumer > "$PKG_DESTDIR/usr/bin/consumer"'
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" install --deps consumer >/dev/null
[[ -d "$DBROOT/installed/provhigh" ]] || fail 'provider prioritário não foi instalado'
[[ ! -d "$DBROOT/installed/provlow" ]] || fail 'provider de baixa prioridade não deveria ter sido escolhido'
pass 'provider priority escolhe provider de maior prioridade entre receitas'
state_file="$TEST_ROOT/state.tsv"
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" export-state "$state_file" >/dev/null
assert_file "$state_file"
assert_contains "$state_file" $'provhigh\t1.0.0\t1\tdependency'
assert_contains "$state_file" $'consumer\t1.0.0\t1\texplicit'
pass 'export-state gera inventário TSV'
mkdir -p "$DBROOT/installed/libdemo" "$DBROOT/installed/appdemo"
cat > "$DBROOT/installed/libdemo/meta" <<EOF
name=libdemo
version=1.0
release=1
install_reason=explicit
abi_fingerprint=old
EOF
printf 'libdemo.so.1\t/usr/lib/libdemo.so.1\n' > "$DBROOT/installed/libdemo/abi_provides"
cat > "$DBROOT/installed/appdemo/meta" <<EOF
name=appdemo
version=1.0
release=1
install_reason=explicit
EOF
printf 'libdemo.so.1\t/usr/bin/appdemo\n' > "$DBROOT/installed/appdemo/abi_requires"
chain="$(PKG_CONFIG_FILE="$CONF" "$PKG_BIN" rebuild-chain libdemo)"
[[ "$chain" == *appdemo* ]] || fail "rebuild-chain não incluiu appdemo"
pass 'rebuild-chain encontra consumidores ABI'
snap="$(PKG_CONFIG_FILE="$CONF" "$PKG_BIN" host-snapshot ci)"
assert_file "$snap"
pass 'host-snapshot gera arquivo compactado'
write_recipe consumer2 1.0.0 '"virtual/editor"' '' 100 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf consumer2 > "$PKG_DESTDIR/usr/bin/consumer2"'
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" install provlow >/dev/null
printf 'virtual/editor=provlow\n' > "$DBROOT/provider-preferences.conf"
PKG_CONFIG_FILE="$CONF" "$PKG_BIN" install consumer2 >/dev/null
[[ -d "$DBROOT/installed/consumer2" ]] || fail 'consumer2 não foi instalado com provider preferido já instalado'
pass 'provider preference resolve provider instalado sem ambiguidade'

mkdir -p "$DBROOT/installed/tooldemo"
cat > "$DBROOT/installed/tooldemo/meta" <<EOM
name=tooldemo
version=1.0
release=1
install_reason=explicit
EOM
printf 'appdemo.so.1\t/usr/lib/appdemo.so.1\n' > "$DBROOT/installed/appdemo/abi_provides"
printf 'appdemo.so.1\t/usr/bin/tooldemo\n' > "$DBROOT/installed/tooldemo/abi_requires"
chain2="$(PKG_CONFIG_FILE="$CONF" "$PKG_BIN" rebuild-chain libdemo)"
[[ "$chain2" == *appdemo* && "$chain2" == *tooldemo* ]] || fail "rebuild-chain transitivo não incluiu cadeia completa"
pass 'rebuild-chain inclui dependentes transitivos'

if PKG_CONFIG_FILE="$CONF" "$PKG_BIN" import-state "$state_file" --bogus >/tmp/import-state-invalid.log 2>&1; then
  fail 'import-state deveria rejeitar modo inválido'
fi
pass 'import-state rejeita modo inválido'

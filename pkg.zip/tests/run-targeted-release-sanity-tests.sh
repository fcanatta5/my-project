#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $*"; exit 1; }
cd "$REPO_ROOT"
[[ -x usr/pkg/bin/pkg ]] || fail "pkg principal ausente ou não executável"
[[ ! -e usr/pkg/bin/pkg.bak ]] || fail "artefato de backup pkg.bak não deve ir no release"
[[ ! -e usr/pkg/bin/pkg.preedit ]] || fail "artefato temporário pkg.preedit não deve ir no release"
bash -n usr/pkg/bin/pkg || fail "bash -n falhou no binário principal"
./targeted_check.sh >/dev/null || fail "targeted_check.sh falhou"
echo "PASS: release sanity ok"

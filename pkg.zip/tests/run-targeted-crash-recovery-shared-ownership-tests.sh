#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-crash-owner-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_dir(){ [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_no_glob(){ ! compgen -G "$1" >/dev/null || fail "match inesperado: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1"; local d="$SOURCES/$n-src"; mkdir -p "$d"; echo "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz"|awk '{print $1}'; }
write_recipe(){ local r="$1" v="$2" rel="$3" deps="$4" body="$5" dir sum depends_line; dir="$RECIPES/$r"; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; depends_line='pkg_depends=()'; [[ -n "$deps" ]] && depends_line="pkg_depends=($deps)"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="$rel"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
latest_snapshot(){ find "$SNAPROOT/$1" -maxdepth 1 -type f -name '*.tar' | sort | tail -n1; }
write_recipe shareda 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/share/shared-empty"\n  : > "$PKG_DESTDIR/usr/share/shared-empty/.a"\n  rm -f "$PKG_DESTDIR/usr/share/shared-empty/.a"'
write_recipe sharedb 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/share/shared-empty"\n  : > "$PKG_DESTDIR/usr/share/shared-empty/.b"\n  rm -f "$PKG_DESTDIR/usr/share/shared-empty/.b"'
run_pkg install shareda >/dev/null
run_pkg install sharedb >/dev/null
assert_dir "$SYSROOT/usr/share/shared-empty"
run_pkg remove shareda >/dev/null
assert_dir "$SYSROOT/usr/share/shared-empty"
run_pkg verify sharedb >/dev/null
run_pkg remove sharedb >/dev/null
pass "ownership compartilhado preserva diretório vazio enquanto ainda existe outro owner"
write_recipe crashsolo 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "solo-v1\\n" > "$PKG_DESTDIR/usr/bin/crashsolo"'
run_pkg install crashsolo >/dev/null
write_recipe crashsolo 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "solo-v2\\n" > "$PKG_DESTDIR/usr/bin/crashsolo"'
run_pkg reinstall crashsolo >/dev/null
solo_archive="$(latest_snapshot crashsolo)"; [[ -f "$solo_archive" ]] || fail "snapshot crashsolo ausente"
solo_journal="$STATEROOT/recovery/install-crashsolo-stale"; mkdir -p "$solo_journal/new-manifest"
cat > "$solo_journal/prestate.list" <<PRE
crashsolo	installed	$solo_archive
PRE
cat > "$solo_journal/meta" <<META
id=install-crashsolo-stale
operation=install
target_pkg=crashsolo
state=applying
pid=999999
started_at=$(date -Is)
log_dir=$LOGROOT/recovery/crashsolo
manifest_dir=$solo_journal/new-manifest
prestate=$solo_journal/prestate.list
META
run_pkg list >/dev/null
assert_file_contains "$SYSROOT/usr/bin/crashsolo" 'solo-v1'
assert_file_contains "$DBROOT/installed/crashsolo/meta" 'version=1.0.0'
assert_not_exists "$solo_journal"
pass "recovery de operação interrompida restaura snapshot anterior do pacote"


# recovery não deve avançar sem lock do pacote afetado
write_recipe lockreco 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lock-v1\n" > "$PKG_DESTDIR/usr/bin/lockreco"'
run_pkg install lockreco >/dev/null
write_recipe lockreco 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lock-v2\n" > "$PKG_DESTDIR/usr/bin/lockreco"'
run_pkg reinstall lockreco >/dev/null
lock_archive="$(latest_snapshot lockreco)"; [[ -f "$lock_archive" ]] || fail "snapshot lockreco ausente"
lock_journal="$STATEROOT/recovery/install-lockreco-stale"; mkdir -p "$lock_journal/new-manifest"
cat > "$lock_journal/prestate.list" <<PRE
lockreco	installed	$lock_archive
PRE
cat > "$lock_journal/meta" <<META
id=install-lockreco-stale
operation=install
target_pkg=lockreco
state=applying
pid=999999
started_at=$(date -Is)
log_dir=$LOGROOT/recovery/lockreco
manifest_dir=$lock_journal/new-manifest
prestate=$lock_journal/prestate.list
META
(
  exec 9>"$LOCKROOT/lockreco.lock"
  flock -n 9
  sleep 3
) &
locker_pid=$!
sleep 0.2
run_pkg list >/dev/null
kill "$locker_pid" 2>/dev/null || true
wait "$locker_pid" 2>/dev/null || true
assert_file_contains "$SYSROOT/usr/bin/lockreco" 'lock-v2'
[[ -d "$lock_journal" ]] || fail "journal deveria permanecer pendente quando o lock está ocupado"
pass "crash recovery adia restauração quando o pacote está bloqueado"
run_pkg list >/dev/null
assert_file_contains "$SYSROOT/usr/bin/lockreco" 'lock-v1'
assert_not_exists "$lock_journal"
pass "crash recovery retoma a restauração quando o lock é liberado"

write_recipe txpkg 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "tx-v1\\n" > "$PKG_DESTDIR/usr/bin/txpkg"'
run_pkg install txpkg >/dev/null
write_recipe txpkg 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "tx-v2\\n" > "$PKG_DESTDIR/usr/bin/txpkg"'
run_pkg upgrade txpkg >/dev/null
tx_archive="$(latest_snapshot txpkg)"; [[ -f "$tx_archive" ]] || fail "snapshot txpkg ausente"
mkdir -p "$TMPROOT/tx-stale/payloads"
cat > "$TMPROOT/tx-stale/tx.meta" <<META
id=tx-stale
state=applying
pid=999999
target_recipe=txpkg
started_at=$(date -Is)
META
cat > "$TMPROOT/tx-stale/prestate.list" <<PRE
txpkg	installed	$tx_archive
PRE
run_pkg list >/dev/null
assert_file_contains "$SYSROOT/usr/bin/txpkg" 'tx-v1'
assert_file_contains "$DBROOT/installed/txpkg/meta" 'version=1.0.0'
assert_not_exists "$TMPROOT/tx-stale"
pass "recovery automático de transação interrompida restaura o pacote do conjunto planejado"
assert_no_glob "$DBROOT/installed/*.prev"
assert_no_glob "$DBROOT/installed/*.tmp*"
pass "save_installed_db não deixa diretórios temporários no banco após operação bem-sucedida"
echo "Todos os testes de crash recovery/shared ownership passaram em $TEST_ROOT"

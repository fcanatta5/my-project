#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-snapshot-dbtree-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_exists(){ [[ -e "$1" ]] || fail "ausente: $1"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local name="$1"; local dir="$SOURCES/$name-src"; mkdir -p "$dir"; printf '%s\n' "$name source" > "$dir/README"; tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"; sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'; }
write_recipe(){ local recipe="$1" version="$2" depends="$3" body="$4"; local dir="$RECIPES/$recipe" sum; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$recipe-$version")"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="snapshot db tree integrity test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe dep 1.0.0 '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "dep\\n" > "$PKG_DESTDIR/usr/bin/dep"'
write_recipe demo 1.0.0 '"dep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "demo\\n" > "$PKG_DESTDIR/usr/bin/demo"'
run_pkg install dep >/dev/null
run_pkg install demo >/dev/null
run_pkg remove demo >/dev/null
snapshot_archive="$(find "$SNAPROOT/demo" -maxdepth 1 -type f -name '*.tar' | head -n1)"
assert_exists "$snapshot_archive"
printf 'forgeddep\n' >> "${snapshot_archive%.tar}.db/depends"
mkdir -p "${snapshot_archive%.tar}.db/forged-dir"
printf 'x\n' > "${snapshot_archive%.tar}.db/forged-dir/extra"
if run_pkg rollback demo "$snapshot_archive" >/dev/null 2>"$TEST_ROOT/rollback.err"; then
  fail 'rollback deveria falhar com .db adulterado fora de meta/files/dirs'
fi
assert_not_exists "$DBROOT/installed/demo"
assert_not_exists "$SYSROOT/usr/bin/demo"
pass 'rollback rejeita snapshot com adulteração em .db/depends e arquivo extra em .db'

echo "Todos os testes de integridade agregada do banco de snapshot passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-run-cmd-logged-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_SYSTEMD_INTEGRATION=1
PKG_SYSTEMD_SYSUSERS_BIN="$TEST_ROOT/fake-systemd-sysusers"
CFG

cat > "$TEST_ROOT/fake-systemd-sysusers" <<'SH'
#!/usr/bin/env bash
echo "fake sysusers failure" >&2
exit 73
SH
chmod +x "$TEST_ROOT/fake-systemd-sysusers"

mk_src(){
  local name="$1" dir
  dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

sum="$(mk_src sysuserpkg-1.0.0)"
mkdir -p "$RECIPES/sysuserpkg"
cat > "$RECIPES/sysuserpkg/pkgbuild" <<PKG
pkg_name="sysuserpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="run_cmd_logged exit code regression test"
pkg_homepage="https://example.invalid/sysuserpkg"
pkg_license="MIT"
pkg_sources=("$SOURCES/sysuserpkg-1.0.0.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_system_users=("u testuser - "Test User" /nonexistent")
build(){ :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/bin"
  printf 'ok\n' > "\$PKG_DESTDIR/usr/bin/sysuserpkg"
}
PKG

if PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install sysuserpkg >/dev/null 2>&1; then
  fail "install deveria falhar quando systemd-sysusers retorna erro"
fi
assert_file_contains "$LOGROOT/sysuserpkg"/*/integration.log 'fake sysusers failure'
[[ ! -e "$SYSROOT/usr/bin/sysuserpkg" ]] || fail "arquivo não deveria ter sido instalado após falha de integração"
pass "run_cmd_logged preserva o exit code real e aborta integração com falha"

echo "Todos os testes de run_cmd_logged passaram em $TEST_ROOT"

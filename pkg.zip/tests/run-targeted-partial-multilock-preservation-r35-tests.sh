#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r35-multilock-XXXXXX)}"
LOCKROOT="$TEST_ROOT/locks"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$LOCKROOT"

# shellcheck disable=SC1090
source <(sed '$d' "$PKG_BIN")
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$TEST_ROOT/logs"
PKG_TMP_ROOT="$TEST_ROOT/tmp"
PKG_CLEAN_ENV_AFTER_BUILD=0
mkdir -p "$PKG_LOG_ROOT" "$PKG_TMP_ROOT"

acquire_pkg_lock alpha
[[ ${#LOCK_FDS[@]} -eq 1 ]] || fail "lock inicial não foi adquirido"

exec {busy_fd}>"$LOCKROOT/beta.lock"
flock -n "$busy_fd" || fail "não consegui preparar lock ocupado de beta"

if try_acquire_many_pkg_locks alpha beta gamma; then
  fail "try_acquire_many_pkg_locks deveria falhar com beta ocupado"
fi

[[ ${#LOCK_FDS[@]} -eq 1 ]] || fail "falha parcial soltou locks já retidos"
[[ "${LOCK_FILES[0]}" == "$LOCKROOT/alpha.lock" ]] || fail "lock remanescente incorreto após falha parcial"

if ! flock -n "$LOCK_FD"; then
  :
fi
# alpha must still be exclusively held by this process
if python3 - "$LOCKROOT/alpha.lock" <<'PY'
import fcntl, os, sys
fd=os.open(sys.argv[1], os.O_RDWR|os.O_CREAT, 0o644)
try:
    fcntl.flock(fd, fcntl.LOCK_EX|fcntl.LOCK_NB)
    ok=False
except BlockingIOError:
    ok=True
os.close(fd)
raise SystemExit(0 if ok else 1)
PY
then
  :
else
  fail "lock alpha deixou de estar retido após falha parcial"
fi

exec {busy_fd}>&-
release_lock
pass "falha parcial em multi-lock preserva locks previamente adquiridos pelo processo"
echo "Todos os testes de preservação de multi-lock r35 passaram em $TEST_ROOT"

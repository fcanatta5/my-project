#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-remove-audit-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_contains() { grep -Fq "$2" <<<"$1" || fail "texto ausente: $2"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_grep() { grep -Fqx "$2" "$1" || fail "não encontrado em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc"
mkdir -p "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" depends="$3" provides="$4" body="$5" config_list="$6"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=($config_list)
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

write_recipe provider 1.0.0 '' '"virtual/core"' $'  mkdir -p "$PKG_DESTDIR/usr/share/provider"\n  printf "provider\n" > "$PKG_DESTDIR/usr/share/provider/core.txt"' ''
write_recipe app 1.0.0 '"virtual/core"' '' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "app\n" > "$PKG_DESTDIR/usr/bin/app"' ''
write_recipe leaf 1.0.0 '' '' $'  mkdir -p "$PKG_DESTDIR/usr/share/leaf"\n  printf "leaf\n" > "$PKG_DESTDIR/usr/share/leaf/file.txt"' ''
write_recipe auditmeta 1.0.0 '"virtual/core"' '"virtual/auditmeta"' $'  mkdir -p "$PKG_DESTDIR/etc" "$PKG_DESTDIR/usr/share/auditmeta"\n  printf "enabled=yes\n" > "$PKG_DESTDIR/etc/auditmeta.conf"\n  printf "payload\n" > "$PKG_DESTDIR/usr/share/auditmeta/data.txt"' '"/etc/auditmeta.conf"'

run_pkg install --deps app >/dev/null
if run_pkg remove provider >/dev/null 2>&1; then
  fail "remove deveria bloquear pacote com dependentes reversos"
fi
assert_file "$DBROOT/installed/provider/meta"
pass "remove bloqueia pacote com rdeps"

run_pkg install auditmeta >/dev/null
assert_grep "$DBROOT/installed/auditmeta/meta" 'file_count=2'
assert_grep "$DBROOT/installed/auditmeta/meta" 'config_count=1'
assert_grep "$DBROOT/installed/auditmeta/meta" 'depends_count=1'
assert_grep "$DBROOT/installed/auditmeta/meta" 'provides_count=1'
assert_file "$DBROOT/installed/auditmeta/logs/main.log"
assert_file "$DBROOT/installed/auditmeta/logs/operation.meta"
assert_contains "$(run_pkg logs auditmeta install)" 'Instalado:'
pass "metadados e logs do pacote instalado foram registrados"


run_pkg install leaf >/dev/null
rm -f "$SYSROOT/usr/share/leaf/file.txt"
mkdir -p "$SYSROOT/usr/share/leaf/file.txt"
if run_pkg remove leaf >/dev/null 2>&1; then
  fail "remove deveria falhar quando o manifesto aponta arquivo mas o sysroot contém diretório"
fi
assert_file "$DBROOT/installed/leaf/meta"
assert_contains "$(run_pkg history)" $'remove	leaf	failed'
pass "remove falha de forma auditável e preserva o banco ativo quando encontra estado inconsistente no sysroot"
rm -rf "$SYSROOT/usr/share/leaf/file.txt"
run_pkg remove leaf >/dev/null
assert_not_exists "$DBROOT/installed/leaf"
assert_not_exists "$SYSROOT/usr/share/leaf/file.txt"
removed_leaf="$(find "$STATEROOT/removed/leaf" -mindepth 1 -maxdepth 1 -type d | sort | tail -n1)"
assert_file "$removed_leaf/meta"
assert_file "$removed_leaf/removal.meta"
assert_file "$removed_leaf/runtime-logs/main.log"
assert_contains "$(run_pkg logs leaf main)" 'Pacote removido: leaf'
pass "remove preserva trilha de auditoria e logs pós-remoção"

history_out="$(run_pkg history)"
assert_contains "$history_out" $'install\tprovider\tok'
assert_contains "$history_out" $'install\tauditmeta\tok'
assert_contains "$history_out" $'remove\tleaf\tok'
pass "history global registra install e remove"

echo "Todos os testes de remoção/auditoria passaram em $TEST_ROOT"

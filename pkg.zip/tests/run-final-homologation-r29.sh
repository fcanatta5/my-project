#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"
run(){
  local name="$1"; shift
  echo "== $name =="
  "$@"
  echo "[OK] $name"
}
run "syntax" bash -n usr/pkg/bin/pkg
run "stress prolongado" timeout 420s bash tests/run-targeted-production-stress-r28-tests.sh
run "autocura de resíduos" timeout 240s bash tests/run-targeted-runtime-residue-autocure-r28-tests.sh
run "contenção de lock transacional" timeout 240s bash tests/run-targeted-tx-stale-cleanup-tests.sh
run "recovery com lock ocupado" timeout 240s bash tests/run-targeted-transaction-recovery-lock-contention-tests.sh
run "recovery com PID estrangeiro" timeout 420s bash tests/run-targeted-transaction-recovery-foreign-pid-tests.sh
run "interrupção abrupta repetida" timeout 420s bash tests/run-targeted-repeated-abrupt-interruption-r28-tests.sh
run "validação end-to-end" timeout 420s bash tests/run-production-validation-e2e.sh
echo "Homologação final r29 concluída com sucesso"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTDIR="${OUTDIR:-$REPO_ROOT/QA_RESULTS_R33}"
mkdir -p "$OUTDIR"
REPORT="$OUTDIR/REPORT_R33.tsv"
SUMMARY="$OUTDIR/SUMMARY_R33.txt"
: > "$REPORT"
status=0

log_result(){
  local gate="$1" result="$2" detail="$3"
  printf '%s\t%s\t%s\n' "$gate" "$result" "$detail" >> "$REPORT"
}

run_gate(){
  local gate="$1"; shift
  local logfile="$OUTDIR/${gate}.log"
  echo "[RUN] $gate"
  if "$@" >"$logfile" 2>&1; then
    local tail_line
    tail_line="$(tail -n 1 "$logfile" 2>/dev/null || true)"
    log_result "$gate" "PASS" "${tail_line:-ok}"
    echo "[PASS] $gate"
  else
    local rc=$?
    local tail_line
    tail_line="$(tail -n 20 "$logfile" 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g' | sed 's/^ //;s/ $//')"
    log_result "$gate" "FAIL" "rc=$rc ${tail_line:-sem detalhe}"
    echo "[FAIL] $gate (rc=$rc)"
    status=1
  fi
}

# Static gates: baseline quality and package integrity
run_gate syntax-main bash -n "$REPO_ROOT/usr/pkg/bin/pkg"
run_gate syntax-tests bash -lc 'find "$1/tests" -maxdepth 1 -type f -name "*.sh" -print0 | xargs -0 -n1 bash -n' _ "$REPO_ROOT"
run_gate docs-presence bash -lc 'test -f "$1/README.md" && test -f "$1/docs/TESTING.md" && test -f "$1/etc/pkg/pkg.conf"' _ "$REPO_ROOT"

# Primary-manager go/no-go gates: blocker class
run_gate config-runtime-hardening bash "$REPO_ROOT/tests/run-targeted-config-runtime-hardening-tests.sh"
run_gate config-derived-path-hardening bash "$REPO_ROOT/tests/run-targeted-config-derived-path-hardening-r32-tests.sh"
run_gate input-validation bash "$REPO_ROOT/tests/run-targeted-input-validation-tests.sh"
run_gate repo-command-dispatch bash "$REPO_ROOT/tests/run-targeted-repo-command-tests.sh"
run_gate repo-index-path-hardening bash "$REPO_ROOT/tests/run-targeted-repo-index-path-hardening-tests.sh"
run_gate binary-package-safety bash "$REPO_ROOT/tests/run-targeted-binary-package-safety-tests.sh"
run_gate binary-package-link-safety bash "$REPO_ROOT/tests/run-targeted-binary-package-link-safety-tests.sh"
run_gate binary-manifest-hardening bash "$REPO_ROOT/tests/run-targeted-binary-package-manifest-hardening-tests.sh"
run_gate binary-payload-manifest-drift bash "$REPO_ROOT/tests/run-targeted-binary-package-payload-manifest-drift-tests.sh"
run_gate git-source-integrity bash "$REPO_ROOT/tests/run-targeted-git-source-integrity-tests.sh"
run_gate immediate-rollback bash "$REPO_ROOT/tests/run-targeted-immediate-rollback-tests.sh"
run_gate upgrade-rollback bash "$REPO_ROOT/tests/run-targeted-upgrade-rollback-tests.sh"
run_gate provider-snapshot bash "$REPO_ROOT/tests/run-targeted-provider-snapshot-tests.sh"
run_gate production-cleanup-recovery bash "$REPO_ROOT/tests/run-targeted-production-cleanup-recovery-tests.sh"
run_gate production-stress bash "$REPO_ROOT/tests/run-targeted-production-stress-r28-tests.sh"
run_gate repeated-abrupt-interruption bash "$REPO_ROOT/tests/run-targeted-repeated-abrupt-interruption-r28-tests.sh"
run_gate runtime-residue-autocure bash "$REPO_ROOT/tests/run-targeted-runtime-residue-autocure-r28-tests.sh"
run_gate recovery-foreign-pid bash "$REPO_ROOT/tests/run-targeted-recovery-foreign-pid-tests.sh"
run_gate transaction-failure-lock bash "$REPO_ROOT/tests/run-targeted-transaction-failure-lock-tests.sh"
run_gate transaction-recovery-lock-contention bash "$REPO_ROOT/tests/run-targeted-transaction-recovery-lock-contention-tests.sh"
run_gate transaction-lock-retention bash "$REPO_ROOT/tests/run-targeted-transaction-lock-retention-r34-tests.sh"
run_gate partial-multilock-preservation bash "$REPO_ROOT/tests/run-targeted-partial-multilock-preservation-r35-tests.sh"
run_gate tx-stale-cleanup bash "$REPO_ROOT/tests/run-targeted-tx-stale-cleanup-tests.sh"
run_gate cleanup-metadata-success bash "$REPO_ROOT/tests/run-targeted-cleanup-metadata-success-r37-tests.sh"
run_gate crash-recovery-shared-ownership bash "$REPO_ROOT/tests/run-targeted-crash-recovery-shared-ownership-tests.sh"
run_gate rollback-ownership-conflict bash "$REPO_ROOT/tests/run-targeted-rollback-ownership-conflict-tests.sh"
run_gate runtime-id-collision bash "$REPO_ROOT/tests/run-targeted-runtime-id-collision-tests.sh"
run_gate missing-path-removal-fastpath bash "$REPO_ROOT/tests/run-targeted-missing-path-removal-fastpath-r32-tests.sh"
run_gate operation-telemetry bash "$REPO_ROOT/tests/run-targeted-operation-telemetry-r36-tests.sh"
run_gate manifest-implicit-parent-dirs bash "$REPO_ROOT/tests/run-targeted-manifest-implicit-parent-dirs-tests.sh"
run_gate solver-replaces bash "$REPO_ROOT/tests/run-targeted-solver-replaces-tests.sh"
run_gate release-sanity bash "$REPO_ROOT/tests/run-targeted-release-sanity-tests.sh"

pass_count=$(awk -F'\t' '$2=="PASS"{c++} END{print c+0}' "$REPORT")
fail_count=$(awk -F'\t' '$2=="FAIL"{c++} END{print c+0}' "$REPORT")
verdict="GO"
reason="Todos os gates críticos para uso como gerenciador principal passaram neste ambiente de homologação."
if [[ "$fail_count" -gt 0 ]]; then
  verdict="NO-GO"
  reason="Há falhas em gates críticos; uso como gerenciador principal não é recomendado até correção e revalidação completa."
fi

cat > "$SUMMARY" <<TXT
R33 Primary Manager Go/No-Go Summary
Generated at: $(date -Is)
Repository root: $REPO_ROOT
Output dir: $OUTDIR

Verdict: $verdict
Reason: $reason

Pass gates: $pass_count
Fail gates: $fail_count

Decision rule:
- GO: zero FAIL nos gates críticos.
- NO-GO: qualquer FAIL em sintaxe, hardening, segurança de pacote binário, recuperação/rollback ou locks transacionais.

Detailed report:
$(cat "$REPORT")
TXT

if [[ "$status" -ne 0 ]]; then
  echo "$verdict" > "$OUTDIR/VERDICT_R33.txt"
  exit 1
fi

echo "$verdict" > "$OUTDIR/VERDICT_R33.txt"
echo "R33 primary-manager homologation completed successfully"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r40-autoremove-archive-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
latest_removed_opmeta(){ find "$STATEROOT/removed/$1" -type f -path '*/runtime-logs/operation.meta' | sort | tail -n1; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_AUTOREMOVE_ON_REMOVE=1
CFG
mk_src(){ local n="$1" d; d="$SOURCES/${n}-src"; mkdir -p "$d"; printf '%s\n' "$n source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/$n.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/$n.tar.gz" | awk '{print $1}'; }
write_recipe(){ local r="$1" v="$2" rel="$3" deps="$4" body="$5" dir sum depends_line; dir="$RECIPES/$r"; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$r-$v")"; depends_line='pkg_depends=()'; [[ -n "$deps" ]] && depends_line="pkg_depends=($deps)"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$r"
pkg_version="$v"
pkg_release="$rel"
pkg_desc="$r"
pkg_homepage=x
pkg_license=x
pkg_sources=("$SOURCES/$r-$v.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 60s bash "$PKG_BIN" "$@"; }
write_recipe baselib 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "baselib-v1\\n" > "$PKG_DESTDIR/usr/lib/baselib.so"'
write_recipe baseapp 1.0.0 1 '"baselib"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "baseapp-v1\\n" > "$PKG_DESTDIR/usr/bin/baseapp"'
run_pkg install --deps baseapp >/dev/null
run_pkg remove baseapp >/dev/null
baseapp_meta="$(latest_removed_opmeta baseapp)"
baselib_meta="$(latest_removed_opmeta baselib)"
[[ -f "$baseapp_meta" ]] || fail "operation.meta arquivado ausente para baseapp"
[[ -f "$baselib_meta" ]] || fail "operation.meta arquivado ausente para baselib"
assert_file_contains "$baseapp_meta" 'package=baseapp'
assert_file_contains "$baseapp_meta" 'operation=remove'
assert_file_contains "$baseapp_meta" 'status=ok'
assert_file_contains "$baselib_meta" 'package=baselib'
assert_file_contains "$baselib_meta" 'operation=remove'
assert_file_contains "$baselib_meta" 'status=ok'
pass 'autoremove preserva sincronização final do operation.meta arquivado da remoção explícita e da órfã'
echo "Todos os testes de metadados arquivados do autoremove r40 passaram em $TEST_ROOT"

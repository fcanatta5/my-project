#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-test-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() {
  [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"
}
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_grep() { grep -Fqx "$2" "$1" || fail "não encontrado em $1: $2"; }
assert_contains() { grep -Fq "$2" <<<"$1" || fail "texto ausente: $2"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$SYSROOT/usr/share" "$SYSROOT/etc" "$SYSROOT/var/lib"
mkdir -p "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_ARCHIVE_ROOT="$TEST_ROOT/packages"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_PROTECTED_PATHS=(/ /bin /sbin /etc /lib /lib64 /usr /usr/bin /usr/sbin /var /boot /dev /proc /sys /run)
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /usr/local /opt /etc /var)
PKG_ALLOW_INSECURE_HTTP=0
PKG_BUILD_UMASK="022"
PKG_BUILD_USER="root"
PKG_JOBS="1"
PKG_CFLAGS="-O2"
PKG_CXXFLAGS="-O2"
PKG_CPPFLAGS=""
PKG_LDFLAGS=""
PKG_MAKEFLAGS="-j1"
PKG_CONFIGURE_FLAGS=("--prefix=/usr")
PKG_CMAKE_FLAGS=()
PKG_MESON_FLAGS=()
PKG_DOWNLOAD_TOOL="curl"
PKG_FETCH_RETRIES=1
PKG_FETCH_TIMEOUT=5
PKG_DEFAULT_GIT_CLONE_DEPTH=1
PKG_KEEP_WORKDIR=0
PKG_KEEP_STAGE=0
PKG_VERBOSE=1
PKG_ASSUME_YES=1
PKG_STRIP_BINARIES=0
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_HOOKS_ENABLED=1
PKG_LOG_TO_SCREEN=1
PKG_LOG_DATE_FORMAT="%F %T"
PKG_COLOR=0
PKG_ARCHIVE_BUILDS=0
PKG_CREATE_BINARY_ARCHIVE=0
PKG_INSTALL_TOOL="cp"
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_AUTOREMOVE_ON_REMOVE=0
PKG_SEARCH_IN_DESCRIPTIONS=1
PKG_MAX_SNAPSHOTS_PER_PACKAGE=8
PKG_ALLOW_UNOWNED_OVERWRITE=0
PKG_ALLOW_REPLACE_WITHOUT_CONFLICTS=0
PKG_STRICT_OWNERSHIP=1
CFG

git_tree_sha256() {
  local repo="$1" tmp
  tmp="$(mktemp)"
  (
    cd "$repo"
    find . -path ./.git -prune -o -type f -print0 | sort -z | while IFS= read -r -d '' f; do
      f="${f#./}"
      printf '%s\0' "$f"
      sha256sum -- "$f" | awk '{print $1}'
    done
  ) > "$tmp"
  sha256sum "$tmp" | awk '{print $1}'
  rm -f -- "$tmp"
}

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_basic_recipe() {
  local recipe="$1" version="$2" release="$3" desc="$4" depends="$5" provides="$6" conflicts="$7" replaces="$8" body="$9"
  local dir="$RECIPES/$recipe" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$desc"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/$recipe-$version.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=($depends)
pkg_build_depends=()
pkg_conflicts=($conflicts)
pkg_provides=($provides)
pkg_replaces=($replaces)
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() {
  :
}

package() {
$body
}
PKG
}

write_patch_recipe() {
  local dir="$RECIPES/patchpkg" srcdir="$SOURCES/patchpkg-src" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks" "$srcdir"
  printf 'before\n' > "$srcdir/message.txt"
  tar -C "$SOURCES" -czf "$SOURCES/patchpkg-1.0.0.tar.gz" "$(basename "$srcdir")"
  sum="$(sha256sum "$SOURCES/patchpkg-1.0.0.tar.gz" | awk '{print $1}')"
  cat > "$dir/patches/message.patch" <<'PATCH'
--- a/message.txt
+++ b/message.txt
@@ -1 +1 @@
-before
+after-patch
PATCH
  cat > "$dir/pkgbuild" <<PKG
pkg_name="patchpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="patch test"
pkg_homepage="https://example.invalid/patchpkg"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/patchpkg-1.0.0.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/patchpkg"
  cp -f message.txt "\$PKG_DESTDIR/usr/share/patchpkg/message.txt"
}
PKG
}

write_hook_recipe() {
  local dir="$RECIPES/hookpkg" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src hookpkg-1.0.0)"
  cat > "$dir/hooks/post_install.sh" <<'HOOK'
#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$PKG_SYSROOT/var/lib/pkg-hook"
printf 'hook-ran\n' > "$PKG_SYSROOT/var/lib/pkg-hook/post_install.marker"
HOOK
  chmod +x "$dir/hooks/post_install.sh"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="hookpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="hook test"
pkg_homepage="https://example.invalid/hookpkg"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/hookpkg-1.0.0.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
post_build() {
  printf 'function-hook\n' > "\$PKG_WORKDIR/post_build.marker"
}
package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/hookpkg"
  cp -f "\$PKG_WORKDIR/post_build.marker" "\$PKG_DESTDIR/usr/share/hookpkg/post_build.marker"
}
PKG
}

write_config_recipe() {
  local version="$1" content="$2" dir="$RECIPES/configpkg" sum
  local srcdir="$SOURCES/configpkg-$version-src"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks" "$srcdir"
  printf '%s\n' "$content" > "$srcdir/configpkg.conf"
  tar -C "$SOURCES" -czf "$SOURCES/configpkg-$version.tar.gz" "$(basename "$srcdir")"
  sum="$(sha256sum "$SOURCES/configpkg-$version.tar.gz" | awk '{print $1}')"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="configpkg"
pkg_version="$version"
pkg_release="1"
pkg_desc="config test"
pkg_homepage="https://example.invalid/configpkg"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/configpkg-$version.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=(
  "/etc/configpkg.conf"
)

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/etc"
  cp -f configpkg.conf "\$PKG_DESTDIR/etc/configpkg.conf"
}
PKG
}

write_flat_archive_recipe() {
  local dir="$RECIPES/flatroot" srcdir="$SOURCES/flatroot-payload" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks" "$srcdir"
  printf 'flat archive root
' > "$srcdir/README"
  printf 'payload
' > "$srcdir/payload.txt"
  tar -C "$srcdir" -czf "$SOURCES/flatroot-1.0.0.tar.gz" README payload.txt
  sum="$(sha256sum "$SOURCES/flatroot-1.0.0.tar.gz" | awk '{print $1}')"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="flatroot"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="flat archive root test"
pkg_homepage="https://example.invalid/flatroot"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/flatroot-1.0.0.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() {
  test -f README
  test -f payload.txt
}

package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/flatroot"
  cp -f README "\$PKG_DESTDIR/usr/share/flatroot/README"
  cp -f payload.txt "\$PKG_DESTDIR/usr/share/flatroot/payload.txt"
}
PKG
}

write_git_recipe() {
  local repo="$SOURCES/gitpkg-repo" dir="$RECIPES/gitpkg" treehash
  rm -rf "$repo"
  mkdir -p "$repo" "$dir/patches" "$dir/files" "$dir/hooks"
  git init -q -b main "$repo"
  (
    cd "$repo"
    git config user.name 'Test User'
    git config user.email 'test@example.invalid'
    printf 'git-source\n' > git.txt
    git add git.txt
    git commit -q -m 'init'
  )
  treehash="$(git_tree_sha256 "$repo")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="gitpkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="git source test"
pkg_homepage="https://example.invalid/gitpkg"
pkg_license="MIT"
pkg_sources=(
  "git+$repo#ref=main"
)
pkg_sha256s=(
  "$treehash"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/gitpkg"
  cp -f git.txt "\$PKG_DESTDIR/usr/share/gitpkg/git.txt"
}
PKG
}

run_pkg() {
  PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"
}

run_pkg_keep_workdir() {
  PKG_CONFIG_FILE="$CONF" PKG_KEEP_WORKDIR=1 bash "$PKG_BIN" "$@"
}

write_single_file_recipe() {
  local dir="$RECIPES/singlefilepkg" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  printf 'single-file-payload
' > "$SOURCES/singlefilepkg-1.0.0.txt"
  sum="$(sha256sum "$SOURCES/singlefilepkg-1.0.0.txt" | awk '{print $1}')"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="singlefilepkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="single file source test"
pkg_homepage="https://example.invalid/singlefilepkg"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/singlefilepkg-1.0.0.txt"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() {
  test -f singlefilepkg-1.0.0.txt
}

package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/singlefilepkg"
  cp -f singlefilepkg-1.0.0.txt "\$PKG_DESTDIR/usr/share/singlefilepkg/payload.txt"
}
PKG
}

write_prefetch_hook_recipe() {
  local dir="$RECIPES/prefetchhook" sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src prefetchhook-1.0.0)"
  cat > "$dir/hooks/pre_fetch.sh" <<'HOOK'
#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$PKG_SYSROOT/var/lib/prefetch-hook"
printf '%s
' "$PKG_WORKDIR" > "$PKG_SYSROOT/var/lib/prefetch-hook/workdir.txt"
HOOK
  chmod +x "$dir/hooks/pre_fetch.sh"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="prefetchhook"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="prefetch hook env test"
pkg_homepage="https://example.invalid/prefetchhook"
pkg_license="MIT"
pkg_sources=(
  "$SOURCES/prefetchhook-1.0.0.tar.gz"
)
pkg_sha256s=(
  "$sum"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/prefetchhook"
  printf 'ok
' > "\$PKG_DESTDIR/usr/share/prefetchhook/installed.txt"
}
PKG
}

write_insecure_http_recipe() {
  local dir="$RECIPES/insecurehttp"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  cat > "$dir/pkgbuild" <<'PKG'
pkg_name="insecurehttp"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="insecure http fetch test"
pkg_homepage="https://example.invalid/insecurehttp"
pkg_license="MIT"
pkg_sources=(
  "http://example.com/insecurehttp-1.0.0.tar.gz"
)
pkg_sha256s=(
  "SKIP"
)
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()

build() { :; }
package() {
  mkdir -p "$PKG_DESTDIR/usr/share/insecurehttp"
  printf 'never
' > "$PKG_DESTDIR/usr/share/insecurehttp/payload.txt"
}
PKG
}

list_empty_msg="$(run_pkg list 2>&1 >/dev/null || true)"
assert_contains "$list_empty_msg" 'Nenhum pacote instalado'
pass "list informa quando não há pacotes"

orphan_empty_msg="$(run_pkg orphan 2>&1 >/dev/null || true)"
assert_contains "$orphan_empty_msg" 'Nenhum pacote órfão encontrado'
pass "orphan informa quando não há órfãos"

history_empty_msg="$(run_pkg history 2>&1 >/dev/null || true)"
assert_contains "$history_empty_msg" 'Historico vazio'
pass "history informa quando está vazio"

write_basic_recipe provlib 1.0.0 1 "provider lib" "" '"virtual/libfoo"' "" "" $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "provlib 1\\n" > "$PKG_DESTDIR/usr/lib/libfoo.so"'
write_basic_recipe consumer 1.0.0 1 "consumer" '"virtual/libfoo"' "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "consumer\\n" > "$PKG_DESTDIR/usr/bin/consumer"'
write_basic_recipe owned 1.0.0 1 "owned file" "" "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "owned\\n" > "$PKG_DESTDIR/usr/bin/shared"'
write_basic_recipe conflict 1.0.0 1 "conflicting file" "" "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "conflict\\n" > "$PKG_DESTDIR/usr/bin/shared"'
write_basic_recipe oldname 1.0.0 1 "legacy package" "" '"legacy-virtual"' "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "old\\n" > "$PKG_DESTDIR/usr/bin/legacy-tool"'
write_basic_recipe newname 2.0.0 1 "replacement package" "" '"legacy-virtual"' '"oldname"' '"oldname"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "new\\n" > "$PKG_DESTDIR/usr/bin/legacy-tool"'
write_basic_recipe alpha 1.0.0 1 "upgrade target" "" "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "alpha-v1\\n" > "$PKG_DESTDIR/usr/bin/alpha"'
write_basic_recipe unowned 1.0.0 1 "unowned overwrite" "" "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "pkg-owned\\n" > "$PKG_DESTDIR/usr/bin/unowned"'
write_patch_recipe
write_hook_recipe
write_config_recipe 1.0.0 'setting=old'
write_git_recipe
write_single_file_recipe
write_prefetch_hook_recipe
write_insecure_http_recipe

write_basic_recipe leaf 1.0.0 1 "leaf package" "" "" "" "" $'  mkdir -p "$PKG_DESTDIR/usr/share/leafdir"
  printf "leaf
" > "$PKG_DESTDIR/usr/share/leafdir/leaf.txt"'
write_basic_recipe metapkg 1.0.0 1 "metadata package" '"virtual/libfoo"' '"virtual/meta"' "" "" $'  mkdir -p "$PKG_DESTDIR/etc" "$PKG_DESTDIR/usr/share/metapkg"
  printf "meta-config
" > "$PKG_DESTDIR/etc/metapkg.conf"
  printf "meta-data
" > "$PKG_DESTDIR/usr/share/metapkg/data.txt"'

run_pkg install --deps consumer >/dev/null
assert_file "$SYSROOT/usr/lib/libfoo.so"
assert_file "$SYSROOT/usr/bin/consumer"
assert_grep "$DBROOT/installed/provlib/meta" 'install_reason=dependency'
assert_grep "$DBROOT/installed/consumer/meta" 'install_reason=explicit'
assert_contains "$(run_pkg rdeps provlib)" 'consumer'
pass "instalação com depends/provides e rdeps"

run_pkg remove consumer >/dev/null
run_pkg autoremove >/dev/null
assert_not_exists "$DBROOT/installed/consumer"
assert_not_exists "$DBROOT/installed/provlib"
pass "autoremove remove dependência órfã"

exit 0

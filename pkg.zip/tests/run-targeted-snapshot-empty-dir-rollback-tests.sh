#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-snapshot-emptydir-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_dir() { [[ -d "$1" ]] || fail "diretório ausente: $1"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }

mkdir -p "$SYSROOT/usr/share" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_KEEP_WORKDIR=1
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

name="emptydirpkg"
version="1.0.0"
sum="$(mk_src "$name-$version")"
mkdir -p "$RECIPES/$name"
cat > "$RECIPES/$name/pkgbuild" <<PKG
pkg_name="$name"
pkg_version="$version"
pkg_release="1"
pkg_desc="snapshot empty dir rollback test"
pkg_homepage="https://example.invalid/$name"
pkg_license="MIT"
pkg_sources=("$SOURCES/$name-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/share/emptydirpkg/empty/sub"
  printf 'payload\n' > "\$PKG_DESTDIR/usr/share/emptydirpkg/file"
}
PKG

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

run_pkg install "$name" >/dev/null
assert_dir "$SYSROOT/usr/share/emptydirpkg/empty/sub"
run_pkg remove "$name" >/dev/null
run_pkg rollback "$name" >/dev/null
assert_dir "$SYSROOT/usr/share/emptydirpkg/empty/sub"
assert_file "$SYSROOT/usr/share/emptydirpkg/file"
pass 'snapshot_installed_package e rollback restauram diretórios vazios rastreados pelo pacote'

echo "Todos os testes focados de snapshot/rollback com diretórios vazios passaram em $TEST_ROOT"

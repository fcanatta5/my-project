#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTDIR="${OUTDIR:-$REPO_ROOT/QA_RESULTS_R34}"
mkdir -p "$OUTDIR"
REPORT="$OUTDIR/REPORT_R34.tsv"
SUMMARY="$OUTDIR/SUMMARY_R34.txt"
VERDICT_FILE="$OUTDIR/VERDICT_R34.txt"
SHA_FILE="$OUTDIR/CRITICAL_SHA256_R34.txt"
: > "$REPORT"
status=0

log_result(){
  printf '%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" >> "$REPORT"
}

check_cmd(){
  local gate="$1"; shift
  local logfile="$OUTDIR/${gate}.log"
  if "$@" >"$logfile" 2>&1; then
    log_result "$gate" PASS "$(tail -n 1 "$logfile" 2>/dev/null || echo ok)" "$logfile"
  else
    local rc=$?
    log_result "$gate" FAIL "rc=$rc $(tail -n 20 "$logfile" 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g')" "$logfile"
    status=1
  fi
}

check_evidence(){
  local gate="$1" file="$2"
  local abs="$REPO_ROOT/$file"
  if [[ ! -s "$abs" ]]; then
    log_result "$gate" FAIL "evidência ausente ou vazia" "$file"
    status=1
    return
  fi
  if grep -Eqi '(^|\s)(FAIL|ERROR|Terminated)(\s|:|$)' "$abs"; then
    log_result "$gate" FAIL "evidência contém FAIL/ERROR/Terminated" "$file"
    status=1
    return
  fi
  log_result "$gate" PASS "$(tail -n 1 "$abs" | tr '\n' ' ' | sed 's/[[:space:]]\+/ /g')" "$file"
}

check_summary_entry(){
  local gate="$1" needle="$2" file="$REPO_ROOT/QA_RESULTS_R32/SUMMARY_R32.txt"
  if grep -Fq "$needle" "$file"; then
    log_result "$gate" PASS "$(grep -F "$needle" "$file" | head -n 1)" "QA_RESULTS_R32/SUMMARY_R32.txt"
  else
    log_result "$gate" FAIL "entrada não encontrada em SUMMARY_R32" "QA_RESULTS_R32/SUMMARY_R32.txt"
    status=1
  fi
}

# Structural/smoke gates executed now
check_cmd syntax-main bash -n "$REPO_ROOT/usr/pkg/bin/pkg"
check_cmd syntax-tests bash -lc 'find "$1/tests" -maxdepth 1 -type f -name "*.sh" -print0 | xargs -0 -n1 bash -n' _ "$REPO_ROOT"
check_cmd docs-presence bash -lc 'test -f "$1/README.md" && test -f "$1/docs/TESTING.md" && test -f "$1/docs/GO_NO_GO_PRIMARY_MANAGER.md" && test -f "$1/etc/pkg/pkg.conf"' _ "$REPO_ROOT"
check_cmd executable-entrypoint bash -lc 'test -x "$1/usr/pkg/bin/pkg"' _ "$REPO_ROOT"
check_cmd smoke-help bash -lc '"$1/usr/pkg/bin/pkg" help | grep -Fq "pkg 0.4.0"' _ "$REPO_ROOT"

# Fresh live evidence collected in this revision
for f in \
  QA_RESULTS_R34_LIVE/run-targeted-config-runtime-hardening-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-config-derived-path-hardening-r32-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-input-validation-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-repo-command-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-repo-index-path-hardening-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-binary-package-safety-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-binary-package-link-safety-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-binary-package-manifest-hardening-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-binary-package-payload-manifest-drift-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-git-source-integrity-tests.sh.log \
  QA_RESULTS_R34_LIVE/run-targeted-immediate-rollback-tests.sh.log; do
  check_evidence "live-$(basename "$f" .log)" "$f"
done

# Extended promotion coverage inherited from R32 homologation
for needle in \
  'run-targeted-provider-snapshot-tests.sh.log' \
  'run-targeted-production-cleanup-recovery-tests.sh.log' \
  'run-targeted-production-stress-r28-tests.sh.log' \
  'run-targeted-repeated-abrupt-interruption-r28-tests.sh.log' \
  'run-targeted-runtime-residue-autocure-r28-tests.sh.log' \
  'run-targeted-recovery-foreign-pid-tests.sh.log' \
  'run-targeted-transaction-failure-lock-tests.sh.log' \
  'run-targeted-transaction-recovery-lock-contention-tests.sh.log' \
  'run-targeted-transaction-lock-retention-r34-tests.sh.log' \
  'run-targeted-partial-multilock-preservation-r35-tests.sh.log' \
  'run-targeted-tx-stale-cleanup-tests.sh.log' \
  'run-targeted-cleanup-metadata-success-r37-tests.sh.log' \
  'run-targeted-crash-recovery-shared-ownership-tests.sh.log' \
  'run-targeted-rollback-ownership-conflict-tests.sh.log' \
  'run-targeted-runtime-id-collision-tests.sh.log' \
  'run-targeted-missing-path-removal-fastpath-r32-tests.sh.log' \
  'run-targeted-operation-telemetry-r36-tests.sh.log' \
  'run-targeted-manifest-implicit-parent-dirs-tests.sh.log' \
  'run-targeted-solver-replaces-tests.sh.log' \
  'run-targeted-upgrade-rollback-tests.sh.log' \
  'run-targeted-release-sanity-tests.sh.log'; do
  check_summary_entry "r32-$(basename "$needle" .log)" "$needle"
done

pass_count=$(awk -F'\t' '$2=="PASS"{c++} END{print c+0}' "$REPORT")
fail_count=$(awk -F'\t' '$2=="FAIL"{c++} END{print c+0}' "$REPORT")
verdict=GO
reason='GO: estrutura atual válida, evidência viva crítica desta revisão íntegra, e cobertura estendida R32 confirmada por summary.'
if [[ "$fail_count" -gt 0 ]]; then
  verdict=NO-GO
  reason='NO-GO: falha estrutural, evidência viva inconsistente ou cobertura R32 ausente.'
fi
cat > "$SUMMARY" <<TXT
R34 Primary Manager Go/No-Go Summary
Generated at: $(date -Is)
Repository root: $REPO_ROOT
Output dir: $OUTDIR

Verdict: $verdict
Reason: $reason

Pass gates: $pass_count
Fail gates: $fail_count

Decision rule:
- GO: zero FAIL em estrutura, smoke e evidência crítica viva + cobertura estendida R32.
- NO-GO: qualquer FAIL nessas camadas.

Evidence model:
1) Structural/smoke gates executados nesta revisão.
2) Fresh live logs de blocker gates executados nesta revisão e validados por conteúdo.
3) Extended promotion gates confirmados no SUMMARY_R32 já presente no bundle.
4) Fingerprint SHA-256 em CRITICAL_SHA256_R34.txt.

Detailed report:
$(cat "$REPORT")
TXT

(
  cd "$REPO_ROOT"
  sha256sum \
    usr/pkg/bin/pkg \
    tests/run-go-no-go-primary-manager-r34.sh \
    docs/GO_NO_GO_PRIMARY_MANAGER.md \
    etc/pkg/pkg.conf \
    QA_RESULTS_R34_LIVE/SUMMARY_R34_LIVE.txt \
    QA_RESULTS_R34/SUMMARY_R34.txt > "$SHA_FILE"
)


echo "$verdict" > "$VERDICT_FILE"
[[ "$status" -eq 0 ]]

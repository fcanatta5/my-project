#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-snapshot-missing-db-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_exists() { [[ -e "$1" ]] || fail "deveria existir: $1"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/demo" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
PKG_KEEP_WORKDIR=1
CFG

mkdir -p "$SOURCES/demo-src"
printf 'demo source\n' > "$SOURCES/demo-src/README"
tar -C "$SOURCES" -czf "$SOURCES/demo.tar.gz" demo-src
sum="$(sha256sum "$SOURCES/demo.tar.gz" | awk '{print $1}')"
cat > "$RECIPES/demo/pkgbuild" <<PKG
pkg_name="demo"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="demo snapshot rollback"
pkg_homepage="https://example.invalid/demo"
pkg_license="MIT"
pkg_sources=("$SOURCES/demo.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/bin"
  printf 'demo\n' > "\$PKG_DESTDIR/usr/bin/demo"
}
PKG
run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
run_pkg install demo >/dev/null
run_pkg remove demo >/dev/null
snapshot_archive="$(find "$SNAPROOT/demo" -maxdepth 1 -type f -name '*.tar' | head -n1)"
assert_exists "$snapshot_archive"
rm -rf -- "${snapshot_archive%.tar}.db"
if run_pkg rollback demo >"$TEST_ROOT/rollback.out" 2>"$TEST_ROOT/rollback.err"; then
  fail 'rollback deveria falhar quando o snapshot estiver sem .db'
fi
assert_not_exists "$DBROOT/installed/demo"
assert_not_exists "$SYSROOT/usr/bin/demo"
pass 'rollback rejeita snapshot sem .db e não restaura arquivos sem banco'
echo "Todos os testes de snapshot sem .db passaram em $TEST_ROOT"

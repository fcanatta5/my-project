#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-consistency-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_contains() { grep -Fq "$2" <<<"$1" || fail "texto ausente: $2"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_eq() { [[ "$1" == "$2" ]] || fail "esperado '$1' == '$2'"; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local name="$1"; local dir="$SOURCES/$name-src"; mkdir -p "$dir"; printf '%s\n' "$name source" > "$dir/README"; tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"; sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'; }
write_recipe(){ local recipe="$1" version="$2" body="$3" provides="${4:-}" config_list="${5:-}"; local dir="$RECIPES/$recipe" sum; mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"; sum="$(mk_src "$recipe-$version")"; cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe consistency test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=($provides)
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=($config_list)
build() { :; }
package() {
$body
}
PKG
}
run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
write_recipe auditpkg 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin" "$PKG_DESTDIR/usr/share/auditpkg" "$PKG_DESTDIR/etc"\n  printf "v1\\n" > "$PKG_DESTDIR/usr/bin/audittool"\n  printf "payload-v1\\n" > "$PKG_DESTDIR/usr/share/auditpkg/data.txt"\n  printf "enabled=yes\\n" > "$PKG_DESTDIR/etc/auditpkg.conf"' '"virtual/auditpkg"' '"/etc/auditpkg.conf"'
run_pkg install auditpkg >/dev/null
assert_eq "$(run_pkg owner /usr/bin/../bin/audittool)" auditpkg
assert_eq "$(run_pkg owner /usr/share/auditpkg)" auditpkg
run_pkg verify auditpkg >/dev/null
pass 'owner canonicaliza caminho e verify passa no pacote íntegro'
python3 - "$DBROOT/installed/auditpkg/meta" <<'PY'
from pathlib import Path
p=Path(__import__('sys').argv[1]); t=p.read_text(); p.write_text(t.replace('file_count=3','file_count=99'))
PY
if run_pkg verify auditpkg >/dev/null 2>&1; then fail 'verify deveria falhar com meta inconsistente'; fi
pass 'verify detecta inconsistência de metadados'
echo BEFORE_REINSTALL
timeout 20s bash -c "run_pkg reinstall auditpkg >/dev/null"
echo AFTER_REINSTALL
write_recipe auditpkg 2.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin" "$PKG_DESTDIR/usr/share/auditpkg" "$PKG_DESTDIR/etc"\n  printf "v2\\n" > "$PKG_DESTDIR/usr/bin/audittool"\n  printf "payload-v2\\n" > "$PKG_DESTDIR/usr/share/auditpkg/data.txt"\n  printf "enabled=no\\n" > "$PKG_DESTDIR/etc/auditpkg.conf"' '"virtual/auditpkg"' '"/etc/auditpkg.conf"'
run_pkg upgrade auditpkg >/dev/null
snap_meta="$(find "$SNAPROOT/auditpkg" -maxdepth 1 -type f -name '*.meta' | sort | tail -n1)"
assert_file "$snap_meta"
assert_file_contains "$snap_meta" 'package=auditpkg'
assert_file_contains "$snap_meta" 'archive_sha256='
assert_file_contains "$snap_meta" 'manifest_sha256='
assert_file_contains "$snap_meta" 'file_count=3'
assert_file_contains "$snap_meta" 'dir_count='
pass 'snapshot registra metadados fortes para auditoria'
run_pkg rollback auditpkg latest >/dev/null
assert_file_contains "$DBROOT/installed/auditpkg/meta" 'restored_from_snapshot='
assert_file_contains "$DBROOT/installed/auditpkg/meta" 'restored_at='
assert_file_contains "$DBROOT/installed/auditpkg/meta" 'rollback_log_dir='
assert_contains "$(cat "$SYSROOT/usr/bin/audittool")" 'v1'
compgen -G "$DBROOT/installed/*.rollback.*.tmp" >/dev/null && fail 'rollback deixou banco temporário pendente' || true
pass 'rollback restaura payload, grava metadados de restauração e não deixa banco temporário'
cp -a "$DBROOT/installed/auditpkg" "$DBROOT/installed/impostor"
printf '/usr/bin/audittool\n' > "$DBROOT/installed/impostor/files"
: > "$DBROOT/installed/impostor/dirs"
if run_pkg owner /usr/bin/audittool >/dev/null 2>&1; then fail 'owner deveria falhar com múltiplos owners'; fi
if run_pkg verify auditpkg >/dev/null 2>&1; then fail 'verify deveria falhar com ownership duplicado'; fi
pass 'owner e verify detectam corrupção por múltiplos owners'
rm -rf "$DBROOT/installed/impostor"

cp -a "$DBROOT/installed/auditpkg" "$DBROOT/installed/auditpkg-missing-sha"
rm -f "$DBROOT/installed/auditpkg-missing-sha/sha256sums"
if run_pkg verify auditpkg-missing-sha >/dev/null 2>&1; then fail 'verify deveria falhar sem sha256sums'; fi
rm -rf "$DBROOT/installed/auditpkg-missing-sha"
pass 'verify exige manifesto sha256sums para auditoria completa'
cp -a "$DBROOT/installed/auditpkg" "$DBROOT/installed/auditpkg-bad-sha"
printf 'invalido /usr/bin/audittool
' > "$DBROOT/installed/auditpkg-bad-sha/sha256sums"
if run_pkg verify auditpkg-bad-sha >/dev/null 2>&1; then fail 'verify deveria falhar com sha256sums malformado'; fi
rm -rf "$DBROOT/installed/auditpkg-bad-sha"
pass 'verify detecta manifesto sha256sums malformado'
echo "Todos os testes de consistência passaram em $TEST_ROOT"

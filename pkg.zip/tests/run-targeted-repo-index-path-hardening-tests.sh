#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-repo-index-path-XXXXXX)}"
trap 'rm -rf "$TEST_ROOT"' EXIT
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; REPO="$TEST_ROOT/repo"; EXTREPO="$TEST_ROOT/extrepo"; CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/share/test" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/repopkg/patches" "$RECIPES/repopkg/files" "$RECIPES/repopkg/hooks" "$SOURCES" "$REPO" "$EXTREPO"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPO"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
printf 'repo hardening source\n' > "$SOURCES/repopkg-1.0.0.txt"
sum="$(sha256sum "$SOURCES/repopkg-1.0.0.txt"|awk '{print $1}')"
cat > "$RECIPES/repopkg/pkgbuild" <<PKG
pkg_name="repopkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="repo hardening"
pkg_sources=("$SOURCES/repopkg-1.0.0.txt")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/test"; printf ok > "\$PKG_DESTDIR/usr/share/test/repopkg"; }
PKG
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" pack repopkg "$EXTREPO" >/dev/null
external_pkg="$(find "$EXTREPO" -type f -name '*.pkg.tar.zst' | sort | head -n1)"
[[ -n "$external_pkg" && -f "$external_pkg" ]]
cat > "$REPO/index.tsv" <<EOF
repopkg	1.0.0	1	$external_pkg	external absolute path
EOF
if PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install-bin repopkg "$REPO" >"$TEST_ROOT/abs.out" 2>&1; then
  echo '[FAIL] install-bin aceitou caminho absoluto vindo do índice'; exit 1
fi
grep -Fq 'caminho absoluto não é permitido' "$TEST_ROOT/abs.out" || { echo '[FAIL] erro esperado para caminho absoluto não apareceu'; cat "$TEST_ROOT/abs.out"; exit 1; }
[[ ! -e "$SYSROOT/usr/share/test/repopkg" ]] || { echo '[FAIL] pacote externo foi instalado via índice adulterado'; exit 1; }
echo '[PASS] install-bin rejeita caminho absoluto adulterado no index.tsv'
cat > "$REPO/index.tsv" <<'EOF'
repopkg	1.0.0	1	../extrepo/packages/repopkg/repopkg-1.0.0-1.pkg.tar.zst	relative traversal path
EOF
if PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install-bin repopkg "$REPO" >"$TEST_ROOT/traversal.out" 2>&1; then
  echo '[FAIL] install-bin aceitou path traversal vindo do índice'; exit 1
fi
grep -Fq 'path traversal detectado' "$TEST_ROOT/traversal.out" || { echo '[FAIL] erro esperado para traversal não apareceu'; cat "$TEST_ROOT/traversal.out"; exit 1; }
[[ ! -e "$SYSROOT/usr/share/test/repopkg" ]] || { echo '[FAIL] pacote externo foi instalado via traversal do índice'; exit 1; }
echo '[PASS] install-bin rejeita path traversal adulterado no index.tsv'
echo "OK repo index path hardening em $TEST_ROOT"

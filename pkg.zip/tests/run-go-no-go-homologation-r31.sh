#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"
run(){
  local name="$1"; shift
  echo "== $name =="
  "$@"
  echo "[OK] $name"
}
run "syntax" bash -n usr/pkg/bin/pkg
run "config/runtime hardening" bash tests/run-targeted-config-runtime-hardening-tests.sh
run "input validation" bash tests/run-targeted-input-validation-tests.sh
run "repo index path hardening" bash tests/run-targeted-repo-index-path-hardening-tests.sh
run "binary payload safety" bash tests/run-targeted-binary-package-safety-tests.sh
run "binary symlink safety" bash tests/run-targeted-binary-package-link-safety-tests.sh
run "binary manifest hardening" bash tests/run-targeted-binary-package-manifest-hardening-tests.sh
run "binary manifest drift" bash tests/run-targeted-binary-package-payload-manifest-drift-tests.sh
run "git source integrity" bash tests/run-targeted-git-source-integrity-tests.sh
run "immediate rollback" bash tests/run-targeted-immediate-rollback-tests.sh
run "upgrade rollback" bash tests/run-targeted-upgrade-rollback-tests.sh
run "provider snapshot" bash tests/run-targeted-provider-snapshot-tests.sh
run "production cleanup recovery" bash tests/run-targeted-production-cleanup-recovery-tests.sh
run "transaction failure rollback" bash tests/run-targeted-transaction-failure-lock-tests.sh
run "transaction recovery lock contention" bash tests/run-targeted-transaction-recovery-lock-contention-tests.sh
run "transaction stale cleanup" bash tests/run-targeted-tx-stale-cleanup-tests.sh
run "manifest implicit parent dirs" bash tests/run-targeted-manifest-implicit-parent-dirs-tests.sh
run "solver replaces" bash tests/run-targeted-solver-replaces-tests.sh
run "release sanity" bash tests/run-targeted-release-sanity-tests.sh
run "consistency" bash tests/run-consistency-tests.sh
run "production end-to-end" bash tests/run-production-validation-e2e.sh
printf 'GO/NO-GO homologation r31 concluída com sucesso\n'

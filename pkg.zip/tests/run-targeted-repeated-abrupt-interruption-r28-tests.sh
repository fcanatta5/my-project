#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r28-int-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
wait_for_exit(){ local pid="$1" deadline=$((SECONDS+30)); while kill -0 "$pid" 2>/dev/null; do (( SECONDS < deadline )) || fail "processo interrompido não encerrou no prazo: $pid"; sleep 0.2; done; }
mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1" d; d="$SOURCES/${n}-src"; mkdir -p "$d"; printf '%s\n' "${n} source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/${n}.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/${n}.tar.gz"|awk '{print $1}'; }
write_recipe(){
  local r="$1" v="$2" rel="$3" deps="$4" body="$5" build_body="${6:-:;}" dir sum depends_line
  dir="$RECIPES/$r"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$r-$v")"
  depends_line='pkg_depends=()'
  [[ -n "$deps" ]] && depends_line="pkg_depends=($deps)"
  {
    printf 'pkg_name="%s"\n' "$r"
    printf 'pkg_version="%s"\n' "$v"
    printf 'pkg_release="%s"\n' "$rel"
    printf 'pkg_desc="%s"\n' "$r"
    printf 'pkg_homepage=x\n'
    printf 'pkg_license=x\n'
    printf 'pkg_sources=("%s/%s-%s.tar.gz")\n' "$SOURCES" "$r" "$v"
    printf 'pkg_sha256s=("%s")\n' "$sum"
    printf '%s\n' "$depends_line"
    printf 'pkg_build_depends=()\n'
    printf 'pkg_conflicts=()\n'
    printf 'pkg_provides=()\n'
    printf 'pkg_replaces=()\n'
    printf 'pkg_patches=()\n'
    printf 'pkg_options=()\n'
    printf 'pkg_config_files=()\n'
    printf 'build(){\n%s\n}\n' "$build_body"
    printf 'package(){\n%s\n}\n' "$body"
  } > "$dir/pkgbuild"
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 240s bash "$PKG_BIN" "$@"; }
write_recipe irlib 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "irlib-v1\\n" > "$PKG_DESTDIR/usr/lib/irlib.so"'
write_recipe irapp 1.0.0 1 '"irlib"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "irapp-v1\\n" > "$PKG_DESTDIR/usr/bin/irapp"'
run_pkg install --deps irapp >/dev/null
for cycle in 1 2 3; do
  echo "[INFO] ciclo de interrupção $cycle/3"
  libbody=$(printf '  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "irlib-v2.%s\\n" > "$PKG_DESTDIR/usr/lib/irlib.so"' "$cycle")
  appbody=$(printf '  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "irapp-v2.%s\\n" > "$PKG_DESTDIR/usr/bin/irapp"' "$cycle")
  write_recipe irlib "2.0.$cycle" 1 '' "$libbody" 'sleep 8'
  write_recipe irapp "2.0.$cycle" 1 '"irlib"' "$appbody" 'sleep 8'
  (PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" upgrade irapp >/dev/null 2>&1) &
  upid=$!
  sleep 1
  kill -TERM "$upid" 2>/dev/null || true
  wait_for_exit "$upid"
  run_pkg list >/dev/null
  assert_file_contains "$SYSROOT/usr/lib/irlib.so" 'irlib-v1'
  assert_file_contains "$SYSROOT/usr/bin/irapp" 'irapp-v1'
  assert_not_exists "$TMPROOT/irlib-2.0.$cycle-1"
  assert_not_exists "$TMPROOT/irapp-2.0.$cycle-1"
done
pass "interrupção abrupta repetida preserva estado anterior e limpa resíduos"
echo "Todos os testes de interrupção repetida r28 passaram em $TEST_ROOT"

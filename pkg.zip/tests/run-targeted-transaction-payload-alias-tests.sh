#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-payload-alias-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){
  local srcname="$1"
  local srcdir="$SOURCES/${srcname}-src"
  mkdir -p "$srcdir"
  printf '%s\n' "$srcname source" > "$srcdir/README"
  tar -C "$SOURCES" -czf "$SOURCES/${srcname}.tar.gz" "$(basename "$srcdir")"
  sha256sum "$SOURCES/${srcname}.tar.gz" | awk '{print $1}'
}
write_recipe(){
  local recipe="$1"
  local version="$2"
  local body="$3"
  local dir="$RECIPES/$recipe"
  local sum
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="1"
pkg_desc="$recipe alias test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }
write_recipe looptest 1.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "v1\\n" > "$PKG_DESTDIR/usr/bin/looptest"'
run_pkg install looptest >/dev/null
write_recipe looptest 2.0.0 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "v2\\n" > "$PKG_DESTDIR/usr/bin/looptest"'
run_pkg upgrade looptest >/dev/null
if find "$TMPROOT" -type l -print | xargs -r -I{} readlink '{}' | grep -Fq '/payloads/looptest'; then
  fail 'upgrade criou link recursivo para o próprio payload'
fi
pass 'upgrade do pacote com recipe==pkg_name não cria link recursivo de payload'

#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r37-cleanup-meta-XXXXXX)}"
CONF="$TEST_ROOT/pkg.conf"
RECIPES="$TEST_ROOT/recipes"
TMPROOT="$TEST_ROOT/tmp"
LOGROOT="$TEST_ROOT/logs"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
CACHEROOT="$TEST_ROOT/cache"
SNAPROOT="$TEST_ROOT/snapshots"
SYSROOT="$TEST_ROOT/sysroot"
SOURCES="$TEST_ROOT/sources"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

mkdir -p "$RECIPES" "$TMPROOT" "$LOGROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$CACHEROOT" "$SNAPROOT" "$SYSROOT/usr" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG

printf 'success-source\n' > "$SOURCES/success-1.0.0.txt"
success_sha="$(sha256sum "$SOURCES/success-1.0.0.txt" | awk '{print $1}')"
mkdir -p "$RECIPES/success"
cat > "$RECIPES/success/pkgbuild" <<PKG
pkg_name="success"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="success"
pkg_sources=("$SOURCES/success-1.0.0.txt")
pkg_sha256s=("$success_sha")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf '#!/usr/bin/env bash\necho success\n' > "\$PKG_DESTDIR/usr/bin/success"; chmod +x "\$PKG_DESTDIR/usr/bin/success"; }
PKG

run_pkg install success >"$TEST_ROOT/install.out" 2>&1 || fail "install bem-sucedido retornou erro"
run_pkg diagnose success latest >"$TEST_ROOT/diag.out" 2>&1 || fail "diagnose latest falhou após install bem-sucedido"
grep -q '^status=ok$' "$TEST_ROOT/diag.out" || fail "operation.meta persistido no db não registrou status=ok"
grep -q '^exit_code=0$' "$TEST_ROOT/diag.out" || fail "operation.meta persistido no db não registrou exit_code=0"
if run_pkg diagnose success error >"$TEST_ROOT/error.out" 2>&1; then
  fail "diagnose error deveria falhar quando não há last_error.meta"
fi
pass "cleanup final não transforma sucesso em falha e persiste metadados corretos"

echo "Todos os testes de cleanup metadata r37 passaram em $TEST_ROOT"

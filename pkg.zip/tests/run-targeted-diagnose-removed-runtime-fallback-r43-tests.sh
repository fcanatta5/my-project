#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PKG_BIN="${ROOT_DIR}/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r43-diagnose-fallback-XXXXXX)}"
trap 'rm -rf -- "${TEST_ROOT}"' EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }

setup_env() {
  mkdir -p "${TEST_ROOT}"/{db/installed,state/removed,logs,cache,tmp,recipes,sysroot,locks,snapshots}
  cat > "${TEST_ROOT}/pkg.conf" <<CFG
PKG_SYSROOT="${TEST_ROOT}/sysroot"
PKG_DB_ROOT="${TEST_ROOT}/db"
PKG_STATE_ROOT="${TEST_ROOT}/state"
PKG_REMOVED_DB_ROOT="${TEST_ROOT}/state/removed"
PKG_LOG_ROOT="${TEST_ROOT}/logs"
PKG_CACHE_ROOT="${TEST_ROOT}/cache"
PKG_TMP_ROOT="${TEST_ROOT}/tmp"
PKG_LOCK_ROOT="${TEST_ROOT}/locks"
PKG_SNAPSHOT_ROOT="${TEST_ROOT}/snapshots"
PKG_RECIPES_ROOT="${TEST_ROOT}/recipes"
PKG_LOG_TO_SCREEN=0
PKG_COLOR=0
CFG
  export PKG_CONFIG_FILE="${TEST_ROOT}/pkg.conf"
}

setup_env
removed_dir="${TEST_ROOT}/state/removed/demo/001"
mkdir -p "${removed_dir}/runtime-logs" "${removed_dir}/logs"
printf 'status=ok\nsource=archived\n' > "${removed_dir}/logs/operation.meta"
printf 'detail=archived-error\n' > "${removed_dir}/logs/last_error.meta"

diag_out="$(${PKG_BIN} diagnose demo latest)" || fail "diagnose latest deveria usar logs arquivados quando runtime-logs está parcial"
printf '%s\n' "$diag_out" | grep -Fqx 'status=ok' || fail "operation.meta arquivado não foi retornado"
printf '%s\n' "$diag_out" | grep -Fqx 'source=archived' || fail "diagnose latest não apontou para metadata arquivada"

err_out="$(${PKG_BIN} diagnose demo error)" || fail "diagnose error deveria usar last_error.meta arquivado"
printf '%s\n' "$err_out" | grep -Fqx 'detail=archived-error' || fail "last_error.meta arquivado não foi retornado"

path_out="$(${PKG_BIN} diagnose demo path)" || fail "diagnose path deveria resolver um diretório válido"
[[ "$path_out" == "${removed_dir}/logs" ]] || fail "diagnose path deveria preferir logs arquivados com metadata; obtido: $path_out"

pass "diagnose faz fallback para logs arquivados quando runtime-logs removido está parcial"
echo "Todos os testes de fallback de diagnose r43 passaram em ${TEST_ROOT}"

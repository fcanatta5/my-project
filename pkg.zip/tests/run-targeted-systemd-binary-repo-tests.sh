#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-binary-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
REPOROOT="$TEST_ROOT/repo"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/lib/systemd/system" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/demo" "$SOURCES" "$REPOROOT"
printf 'demo source\n' > "$SOURCES/demo.txt"
tar -C "$SOURCES" -czf "$SOURCES/demo.tar.gz" demo.txt
SUM="$(sha256sum "$SOURCES/demo.tar.gz" | awk '{print $1}')"

cat > "$RECIPES/demo/pkgbuild" <<PKG
pkg_name="demo"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="demo binary repo test"
pkg_homepage="https://example.invalid/demo"
pkg_license="MIT"
pkg_sources=("$SOURCES/demo.tar.gz")
pkg_sha256s=("$SUM")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_system_users=("u demo - \"Demo service user\" /var/lib/demo")
pkg_tmpfiles=("d /var/lib/demo 0755 demo demo -")
pkg_systemd_units_enable=("demo.service")
pkg_systemd_units_disable=()
pkg_alternatives=("demo|/usr/bin/demo|/usr/bin/demo.real|50")

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/bin" "\$PKG_DESTDIR/usr/lib/systemd/system"
  printf '#!/bin/sh\necho demo\n' > "\$PKG_DESTDIR/usr/bin/demo"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo"
  printf '#!/bin/sh\necho demo-real\n' > "\$PKG_DESTDIR/usr/bin/demo.real"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo.real"
  cat > "\$PKG_DESTDIR/usr/lib/systemd/system/demo.service" <<'UNIT'
[Unit]
Description=Demo Service
[Service]
ExecStart=/usr/bin/demo
[Install]
WantedBy=multi-user.target
UNIT
}
PKG

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPOROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
PKG_REQUIRE_BUILD_FUNCTION=1
PKG_HOOKS_ENABLED=1
PKG_AUTO_APPLY_PATCHES=1
PKG_EXPORT_BUILD_ENV=1
PKG_CLEAN_ENV_AFTER_BUILD=1
PKG_KEEP_WORKDIR=1
PKG_SYSTEMD_INTEGRATION=0
CFG

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

run_pkg pack demo >/dev/null
assert_file "$REPOROOT/index.tsv"
assert_file_contains "$REPOROOT/index.tsv" $'demo\t1.0.0\t1\t'
assert_file "$REPOROOT/packages/demo/demo-1.0.0-1.pkg.tar.zst"
assert_file "$CACHEROOT/source-packages/demo-1.0.0-1.src.tar.zst"
pass 'pack gera pacote binário, source package e índice de repositório'

run_pkg install-bin demo >/dev/null
assert_file "$SYSROOT/usr/bin/demo"
assert_file "$SYSROOT/usr/lib/systemd/system/demo.service"
assert_file "$DBROOT/installed/demo/meta"
assert_file_contains "$DBROOT/installed/demo/meta" 'system_users_count=1'
assert_file_contains "$DBROOT/installed/demo/meta" 'tmpfiles_count=1'
assert_file_contains "$DBROOT/installed/demo/meta" 'systemd_units_enable_count=1'
assert_file_contains "$DBROOT/installed/demo/meta" 'alternatives_count=1'
assert_file_contains "$DBROOT/installed/demo/system_users" 'u demo'
assert_file_contains "$DBROOT/installed/demo/tmpfiles" 'd /var/lib/demo'
assert_file_contains "$DBROOT/installed/demo/systemd_units_enable" 'demo.service'
assert_file_contains "$DBROOT/installed/demo/alternatives" 'demo|/usr/bin/demo|/usr/bin/demo.real|50'
pass 'install-bin instala payload e preserva metadados de integração do pacote'


# cenário adicional: índice relocável e seleção da versão mais nova por nome do pacote
cat > "$RECIPES/demo/pkgbuild" <<PKG
pkg_name="demo"
pkg_version="2.0.0"
pkg_release="1"
pkg_desc="demo binary repo test v2"
pkg_homepage="https://example.invalid/demo"
pkg_license="MIT"
pkg_sources=("$SOURCES/demo.tar.gz")
pkg_sha256s=("$SUM")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_system_users=("u demo - \"Demo service user\" /var/lib/demo")
pkg_tmpfiles=("d /var/lib/demo 0755 demo demo -")
pkg_systemd_units_enable=("demo.service")
pkg_systemd_units_disable=()
pkg_alternatives=("demo|/usr/bin/demo|/usr/bin/demo.real|50")

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/bin" "\$PKG_DESTDIR/usr/lib/systemd/system"
  printf '#!/bin/sh\necho demo-v2\n' > "\$PKG_DESTDIR/usr/bin/demo"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo"
  printf '#!/bin/sh\necho demo-real-v2\n' > "\$PKG_DESTDIR/usr/bin/demo.real"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo.real"
  cat > "\$PKG_DESTDIR/usr/lib/systemd/system/demo.service" <<'UNIT'
[Unit]
Description=Demo Service V2
[Service]
ExecStart=/usr/bin/demo
[Install]
WantedBy=multi-user.target
UNIT
}
PKG
run_pkg pack demo >/dev/null

cat > "$RECIPES/demo/pkgbuild" <<PKG
pkg_name="demo"
pkg_version="10.0.0"
pkg_release="1"
pkg_desc="demo binary repo test v10"
pkg_homepage="https://example.invalid/demo"
pkg_license="MIT"
pkg_sources=("$SOURCES/demo.tar.gz")
pkg_sha256s=("$SUM")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
pkg_system_users=("u demo - \"Demo service user\" /var/lib/demo")
pkg_tmpfiles=("d /var/lib/demo 0755 demo demo -")
pkg_systemd_units_enable=("demo.service")
pkg_systemd_units_disable=()
pkg_alternatives=("demo|/usr/bin/demo|/usr/bin/demo.real|50")

build() { :; }
package() {
  mkdir -p "\$PKG_DESTDIR/usr/bin" "\$PKG_DESTDIR/usr/lib/systemd/system"
  printf '#!/bin/sh\necho demo-v10\n' > "\$PKG_DESTDIR/usr/bin/demo"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo"
  printf '#!/bin/sh\necho demo-real-v10\n' > "\$PKG_DESTDIR/usr/bin/demo.real"
  chmod +x "\$PKG_DESTDIR/usr/bin/demo.real"
  cat > "\$PKG_DESTDIR/usr/lib/systemd/system/demo.service" <<'UNIT'
[Unit]
Description=Demo Service V10
[Service]
ExecStart=/usr/bin/demo
[Install]
WantedBy=multi-user.target
UNIT
}
PKG
run_pkg pack demo >/dev/null

assert_file_contains "$REPOROOT/index.tsv" $'demo\t10.0.0\t1\tpackages/demo/demo-10.0.0-1.pkg.tar.zst\t'
run_pkg remove demo >/dev/null
MOVED_REPO="$TEST_ROOT/repo-relocated"
mv "$REPOROOT" "$MOVED_REPO"
run_pkg install-bin demo "$MOVED_REPO" >/dev/null
assert_file_contains "$SYSROOT/usr/bin/demo" 'demo-v10'
assert_file_contains "$DBROOT/installed/demo/meta" 'version=10.0.0'
pass 'install-bin por nome usa a versão mais nova e continua funcionando após mover o repositório binário'

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="$(mktemp -d /tmp/pkg-error-clarity-XXXXXX)"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
CONF="$TEST_ROOT/pkg.conf"
cleanup(){ rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
mkdir -p "$SYSROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/insecurehttp"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
cat > "$RECIPES/insecurehttp/pkgbuild" <<'PKG'
pkg_name="insecurehttp"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="http"
pkg_sources=("http://example.com/insecurehttp-1.0.0.tar.gz")
pkg_sha256s=("SKIP")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ :; }
PKG
if PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install insecurehttp >/tmp/pkg-error-clarity.out 2>&1; then
  echo "[FAIL] install deveria falhar para HTTP inseguro" >&2
  exit 1
fi
grep -R -Fq 'Fonte HTTP insegura bloqueada' "$LOGROOT"
if grep -R -Fq 'comando return $?' "$LOGROOT"; then
  echo "[FAIL] erro secundário enganoso permaneceu nos logs" >&2
  exit 1
fi
echo '[PASS] bloqueio de HTTP inseguro falha sem erro secundário enganoso de return'

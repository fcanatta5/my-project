#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-targeted-binlink-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
REPOROOT="$TEST_ROOT/repo"
CONF="$TEST_ROOT/pkg.conf"
ESCAPE_ROOT="$TEST_ROOT/escape"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }

mkdir -p "$SYSROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$REPOROOT" "$ESCAPE_ROOT"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$TEST_ROOT/recipes"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPOROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG

mkdir -p "$TEST_ROOT/payload-src/payload" "$TEST_ROOT/payload-src/meta" "$TEST_ROOT/append-src/payload/linkdir"
cat > "$TEST_ROOT/payload-src/.PKGINFO" <<'PKGINFO'
pkgname=evil-link
pkgver=1.0.0
pkgrelease=1
PKGINFO
ln -s "$ESCAPE_ROOT" "$TEST_ROOT/payload-src/payload/linkdir"
printf 'owned\n' > "$TEST_ROOT/append-src/payload/linkdir/owned.txt"
(
  cd "$TEST_ROOT/payload-src"
  tar -cf "$REPOROOT/evil-link-1.0.0-1.pkg.tar" .
)
(
  cd "$TEST_ROOT/append-src"
  tar -rf "$REPOROOT/evil-link-1.0.0-1.pkg.tar" payload/linkdir/owned.txt
)
zstd -qf "$REPOROOT/evil-link-1.0.0-1.pkg.tar" -o "$REPOROOT/evil-link-1.0.0-1.pkg.tar.zst"
rm -f "$REPOROOT/evil-link-1.0.0-1.pkg.tar"

set +e
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" install-bin "$REPOROOT/evil-link-1.0.0-1.pkg.tar.zst" > "$TEST_ROOT/cmd.out" 2> "$TEST_ROOT/cmd.err"
rc=$?
set -e

[[ $rc -ne 0 ]] || fail 'install-bin deveria rejeitar pacote com symlink seguido por entrada aninhada'
grep -Eq 'link simbólico|aninhada sob link simbólico' "$TEST_ROOT/cmd.err" || fail 'mensagem de erro não indica proteção contra link simbólico inseguro'
[[ ! -e "$ESCAPE_ROOT/owned.txt" ]] || fail 'arquivo externo foi criado fora do diretório de extração'
pass 'install-bin rejeita pacote binário com symlink perigoso antes da extração'

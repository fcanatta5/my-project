#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r28-stress-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
assert_file_contains(){ grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists(){ [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG
mk_src(){ local n="$1" d; d="$SOURCES/${n}-src"; mkdir -p "$d"; printf '%s\n' "${n} source" > "$d/README"; tar -C "$SOURCES" -czf "$SOURCES/${n}.tar.gz" "$(basename "$d")"; sha256sum "$SOURCES/${n}.tar.gz"|awk '{print $1}'; }
write_recipe(){
  local r="$1" v="$2" rel="$3" body="$4" dir sum
  dir="$RECIPES/$r"
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$r-$v")"
  {
    printf 'pkg_name="%s"\n' "$r"
    printf 'pkg_version="%s"\n' "$v"
    printf 'pkg_release="%s"\n' "$rel"
    printf 'pkg_desc="%s"\n' "$r"
    printf 'pkg_homepage=x\n'
    printf 'pkg_license=x\n'
    printf 'pkg_sources=("%s/%s-%s.tar.gz")\n' "$SOURCES" "$r" "$v"
    printf 'pkg_sha256s=("%s")\n' "$sum"
    printf 'pkg_depends=()\n'
    printf 'pkg_build_depends=()\n'
    printf 'pkg_conflicts=()\n'
    printf 'pkg_provides=()\n'
    printf 'pkg_replaces=()\n'
    printf 'pkg_patches=()\n'
    printf 'pkg_options=()\n'
    printf 'pkg_config_files=()\n'
    printf 'build(){ :; }\n'
    printf 'package(){\n%s\n}\n' "$body"
  } > "$dir/pkgbuild"
}
run_pkg(){ PKG_CONFIG_FILE="$CONF" timeout 180s bash "$PKG_BIN" "$@"; }
write_recipe stresspkg 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "stress-v1\\n" > "$PKG_DESTDIR/usr/bin/stresspkg"'
run_pkg install stresspkg >/dev/null
for cycle in 1 2 3 4 5; do
  echo "[INFO] ciclo de stress $cycle/5"
  body=$(printf '  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "stress-v2.%s\\n" > "$PKG_DESTDIR/usr/bin/stresspkg"' "$cycle")
  write_recipe stresspkg "2.0.$cycle" 1 "$body"
  run_pkg upgrade stresspkg >/dev/null
  assert_file_contains "$SYSROOT/usr/bin/stresspkg" "stress-v2.$cycle"
  assert_not_exists "$TMPROOT/stresspkg-2.0.$cycle-1"
  run_pkg list >/dev/null
  run_pkg remove stresspkg >/dev/null
  assert_not_exists "$SYSROOT/usr/bin/stresspkg"
  write_recipe stresspkg 1.0.0 1 $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "stress-v1\\n" > "$PKG_DESTDIR/usr/bin/stresspkg"'
  run_pkg install stresspkg >/dev/null
  assert_file_contains "$SYSROOT/usr/bin/stresspkg" 'stress-v1'
done
pass "stress prolongado com múltiplos ciclos mantém consistência e sem resíduo"
echo "Todos os testes de stress r28 passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-config-derived-r32-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; CONF="$TEST_ROOT/pkg.conf"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == 1 ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
mkdir -p "$SYSROOT/usr/bin" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"
cat > "$CONF" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_PROTECTED_PATHS=(/ /usr /etc /var)
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG

PKG_CONFIG_FILE="$CONF" "$PKG_BIN" list >/dev/null
[[ -d "$RECIPES" && -d "$CACHEROOT/binary" && -d "$CACHEROOT/source-packages" && -d "$DBROOT/repo" ]] || fail 'paths derivados padrão não foram materializados corretamente'
[[ -d "$DBROOT" ]] || fail 'db root ausente'
pass 'paths derivados padrão acompanham roots base'

CUSTOM_PREFS="$TEST_ROOT/custom/provider-prefs.conf"
CUSTOM_INDEX="$TEST_ROOT/custom/repo/index.tsv"
CUSTOM_RECIPES="$TEST_ROOT/custom/recipes"
CUSTOM_BINCACHE="$TEST_ROOT/custom/cache/binary"
CUSTOM_SRCCACHE="$TEST_ROOT/custom/cache/source-packages"
CUSTOM_REPO="$TEST_ROOT/custom/repo"
cat > "$TEST_ROOT/pkg-custom.conf" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$CUSTOM_RECIPES"
PKG_BINARY_CACHE_ROOT="$CUSTOM_BINCACHE"
PKG_SOURCE_ARCHIVE_ROOT="$CUSTOM_SRCCACHE"
PKG_BINARY_REPO_ROOT="$CUSTOM_REPO"
PKG_BINARY_INDEX_FILE="$CUSTOM_INDEX"
PKG_PROVIDER_PREFERENCES_FILE="$CUSTOM_PREFS"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG
PKG_CONFIG_FILE="$TEST_ROOT/pkg-custom.conf" "$PKG_BIN" list >/dev/null
[[ -d "$(dirname -- "$CUSTOM_PREFS")" ]] || fail 'parent de provider preferences customizado não foi criado'
[[ ! -e "$DBROOT/provider-preferences.conf" ]] || fail 'provider preferences caiu silenciosamente no default'
[[ ! -f "$CUSTOM_PREFS" ]] || fail 'provider preferences não deveria ser criado sem gravação explícita'
pass 'provider preferences customizado é preservado mesmo ausente e sem fallback silencioso'

INVALID_ROOT="$TEST_ROOT/invalid-derived"
mkdir -p "$INVALID_ROOT"
cat > "$INVALID_ROOT/pkg-invalid.conf" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="relative-recipes"
PKG_BINARY_CACHE_ROOT="$CACHEROOT/binary"
PKG_SOURCE_ARCHIVE_ROOT="$CACHEROOT/source-packages"
PKG_BINARY_REPO_ROOT="$DBROOT/repo"
PKG_BINARY_INDEX_FILE="$DBROOT/repo/index.tsv"
PKG_PROVIDER_PREFERENCES_FILE="$DBROOT/provider-preferences.conf"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG
(
  cd "$INVALID_ROOT"
  if PKG_CONFIG_FILE="$INVALID_ROOT/pkg-invalid.conf" "$PKG_BIN" list >/tmp/pkg-invalid-derived.out 2>/tmp/pkg-invalid-derived.err; then
    fail 'config derivada relativa foi aceita'
  fi
)
grep -q 'Configuração deve usar caminho absoluto: PKG_RECIPES_ROOT=relative-recipes' /tmp/pkg-invalid-derived.err || fail 'mensagem inesperada para path derivado relativo'
[[ ! -e "$INVALID_ROOT/relative-recipes" ]] || fail 'path derivado relativo foi materializado antes da validação'
pass 'paths derivados relativos são rejeitados antes de mkdir'

NONCAN_ROOT="$TEST_ROOT/noncanonical-derived"
mkdir -p "$NONCAN_ROOT/inside"
cat > "$NONCAN_ROOT/pkg-noncanonical.conf" <<CFG
PKG_ROOT="$SYSROOT"
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_LOG_ROOT="$LOGROOT"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_BINARY_CACHE_ROOT="$CACHEROOT/binary"
PKG_SOURCE_ARCHIVE_ROOT="$CACHEROOT/source-packages"
PKG_BINARY_REPO_ROOT="$DBROOT/repo"
PKG_BINARY_INDEX_FILE="$NONCAN_ROOT/inside/../repo/index.tsv"
PKG_PROVIDER_PREFERENCES_FILE="$DBROOT/provider-preferences.conf"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_ASSUME_YES=1
PKG_COLOR=0
PKG_LOG_TO_SCREEN=0
CFG
if PKG_CONFIG_FILE="$NONCAN_ROOT/pkg-noncanonical.conf" "$PKG_BIN" list >/tmp/pkg-noncanonical-derived.out 2>/tmp/pkg-noncanonical-derived.err; then
  fail 'config derivada não canônica foi aceita'
fi
grep -q 'Configuração deve usar caminho canônico: PKG_BINARY_INDEX_FILE=' /tmp/pkg-noncanonical-derived.err || fail 'mensagem inesperada para path derivado não canônico'
[[ ! -d "$NONCAN_ROOT/repo" ]] || fail 'path derivado não canônico foi materializado antes da validação'
pass 'paths derivados não canônicos são rejeitados antes de mkdir'

#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-r41-archived-reset-XXXXXX)}"
CONF="$TEST_ROOT/pkg.conf"
RECIPES="$TEST_ROOT/recipes"
TMPROOT="$TEST_ROOT/tmp"
LOGROOT="$TEST_ROOT/logs"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
CACHEROOT="$TEST_ROOT/cache"
SNAPROOT="$TEST_ROOT/snapshots"
SYSROOT="$TEST_ROOT/sysroot"
SOURCES="$TEST_ROOT/sources"
cleanup(){ [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT
fail(){ echo "[FAIL] $*" >&2; exit 1; }
pass(){ echo "[PASS] $*"; }
run_pkg(){ PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

mkdir -p "$RECIPES" "$TMPROOT" "$LOGROOT" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$CACHEROOT" "$SNAPROOT" "$SYSROOT/usr" "$SOURCES"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_AUTOREMOVE_ON_REMOVE=1
PKG_LOG_TO_SCREEN=0
CFG

printf 'libfoo source\n' > "$SOURCES/libfoo-1.0.0.txt"
libfoo_sha="$(sha256sum "$SOURCES/libfoo-1.0.0.txt" | awk '{print $1}')"
printf 'app source\n' > "$SOURCES/app-1.0.0.txt"
app_sha="$(sha256sum "$SOURCES/app-1.0.0.txt" | awk '{print $1}')"

mkdir -p "$RECIPES/libfoo"
cat > "$RECIPES/libfoo/pkgbuild" <<PKG
pkg_name="libfoo"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="library"
pkg_sources=("$SOURCES/libfoo-1.0.0.txt")
pkg_sha256s=("$libfoo_sha")
pkg_depends=()
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/lib"; printf 'lib\n' > "\$PKG_DESTDIR/usr/lib/libfoo.so"; }
PKG

mkdir -p "$RECIPES/app"
cat > "$RECIPES/app/pkgbuild" <<PKG
pkg_name="app"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="app"
pkg_sources=("$SOURCES/app-1.0.0.txt")
pkg_sha256s=("$app_sha")
pkg_depends=(libfoo)
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/bin"; printf '#!/usr/bin/env bash\nexit 0\n' > "\$PKG_DESTDIR/usr/bin/app"; chmod +x "\$PKG_DESTDIR/usr/bin/app"; }
PKG

run_pkg install libfoo >/dev/null || fail "install libfoo"
run_pkg install app >/dev/null || fail "install app"
sed -i "s/^install_reason=.*/install_reason=dependency/" "$DBROOT/installed/libfoo/meta"

printf 'relative/path\n' > "$DBROOT/installed/libfoo/files"

set +e
run_pkg remove app >/dev/null 2>"$TEST_ROOT/remove.err"
rc=$?
set -e
[[ $rc -ne 0 ]] || fail "remove app deveria falhar por autoremove corrompido"

a_removed_root="$STATEROOT/removed/app"
[[ -d "$a_removed_root" ]] || fail "arquivo removido de app não encontrado"
a_archive="$(find "$a_removed_root" -mindepth 1 -maxdepth 1 -type d | sort | tail -n1)"
[[ -n "$a_archive" ]] || fail "instância arquivada de app ausente"

opmeta="$a_archive/runtime-logs/operation.meta"
[[ -f "$opmeta" ]] || fail "operation.meta arquivado de app ausente"

grep -q '^package=app$' "$opmeta" || fail "operation.meta arquivado de app foi sobrescrito por pacote errado"
grep -q '^status=failed$' "$opmeta" || fail "operation.meta arquivado de app deveria fechar como failed"
! grep -q '^package=libfoo$' "$opmeta" || fail "operation.meta arquivado de app contaminado por falha de libfoo"

grep -q 'Falha removendo arquivos de libfoo' "$TEST_ROOT/remove.err" || fail "stderr não mostrou a falha real do órfão"
pass "falha em autoremove não contamina logs arquivados da remoção explícita"

echo "Todos os testes de reset de contexto arquivado r41 passaram em $TEST_ROOT"

#!/usr/bin/env bash
set -Eeuo pipefail
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-repo-index-gen-XXXXXX)}"
trap 'rm -rf "$TEST_ROOT"' EXIT
SYSROOT="$TEST_ROOT/sysroot"; DBROOT="$TEST_ROOT/db"; STATEROOT="$TEST_ROOT/state"; LOCKROOT="$TEST_ROOT/locks"; LOGROOT="$TEST_ROOT/logs"; CACHEROOT="$TEST_ROOT/cache"; TMPROOT="$TEST_ROOT/tmp"; SNAPROOT="$TEST_ROOT/snapshots"; RECIPES="$TEST_ROOT/recipes"; SOURCES="$TEST_ROOT/sources"; REPO="$TEST_ROOT/repo"; EXTREPO="$TEST_ROOT/extrepo"; CONF="$TEST_ROOT/pkg.conf"
mkdir -p "$SYSROOT/usr/share/test" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES/repopkg/patches" "$RECIPES/repopkg/files" "$RECIPES/repopkg/hooks" "$SOURCES" "$REPO/packages" "$EXTREPO"
cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_BINARY_REPO_ROOT="$REPO"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_LOG_TO_SCREEN=0
CFG
printf 'repo index generation hardening source\n' > "$SOURCES/repopkg-1.0.0.txt"
sum="$(sha256sum "$SOURCES/repopkg-1.0.0.txt"|awk '{print $1}')"
cat > "$RECIPES/repopkg/pkgbuild" <<PKG
pkg_name="repopkg"
pkg_version="1.0.0"
pkg_release="1"
pkg_desc="repo generation hardening"
pkg_sources=("$SOURCES/repopkg-1.0.0.txt")
pkg_sha256s=("$sum")
pkg_depends=(); pkg_build_depends=(); pkg_conflicts=(); pkg_provides=(); pkg_replaces=(); pkg_patches=(); pkg_options=(); pkg_config_files=()
build(){ :; }
package(){ mkdir -p "\$PKG_DESTDIR/usr/share/test"; printf ok > "\$PKG_DESTDIR/usr/share/test/repopkg"; }
PKG
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" pack repopkg "$EXTREPO" >/dev/null
valid_pkg="$(find "$EXTREPO" -type f -name '*.pkg.tar.zst' | sort | head -n1)"
[[ -n "$valid_pkg" && -f "$valid_pkg" ]]
cp -f "$valid_pkg" "$REPO/packages/repopkg-1.0.0-1.pkg.tar.zst"
printf -v unsafe_pkg '%s/packages/repopkg-bad	name.pkg.tar.zst' "$REPO"
cp -f "$valid_pkg" "$unsafe_pkg"
PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" repo-index "$REPO" >"$TEST_ROOT/repo-index.out" 2>&1
index_file="$REPO/index.tsv"
[[ -f "$index_file" ]] || { echo '[FAIL] index.tsv ausente'; exit 1; }
line_count="$(awk 'END{print NR}' "$index_file")"
[[ "$line_count" == "1" ]] || { echo "[FAIL] esperado 1 linha no índice, obtido $line_count"; cat "$index_file"; exit 1; }
grep -Fq $'packages/repopkg-1.0.0-1.pkg.tar.zst' "$index_file" || { echo '[FAIL] pacote válido não entrou no índice'; cat "$index_file"; exit 1; }
if grep -Fq $'bad	name' "$index_file"; then
  echo '[FAIL] índice aceitou caminho com TAB inseguro'
  cat "$index_file"
  exit 1
fi
echo '[PASS] repo-index ignora pacote com TAB no caminho relativo e mantém index.tsv íntegro'
echo "OK repo index generation hardening em $TEST_ROOT"

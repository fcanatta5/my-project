#!/usr/bin/env bash
set -Eeuo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG_BIN="$REPO_ROOT/usr/pkg/bin/pkg"
TEST_ROOT="${TEST_ROOT:-$(mktemp -d /tmp/pkg-tx-failure-lock-XXXXXX)}"
SYSROOT="$TEST_ROOT/sysroot"
DBROOT="$TEST_ROOT/db"
STATEROOT="$TEST_ROOT/state"
LOCKROOT="$TEST_ROOT/locks"
LOGROOT="$TEST_ROOT/logs"
CACHEROOT="$TEST_ROOT/cache"
TMPROOT="$TEST_ROOT/tmp"
SNAPROOT="$TEST_ROOT/snapshots"
RECIPES="$TEST_ROOT/recipes"
SOURCES="$TEST_ROOT/sources"
CONF="$TEST_ROOT/pkg.conf"

cleanup() { [[ "${KEEP_TEST_ROOT:-0}" == "1" ]] || rm -rf "$TEST_ROOT"; }
trap cleanup EXIT

fail() { echo "[FAIL] $*" >&2; exit 1; }
pass() { echo "[PASS] $*"; }
assert_file() { [[ -f "$1" ]] || fail "arquivo ausente: $1"; }
assert_file_contains() { grep -Fq "$2" "$1" || fail "texto ausente em $1: $2"; }
assert_not_exists() { [[ ! -e "$1" ]] || fail "não deveria existir: $1"; }
assert_no_match() { ! compgen -G "$1" >/dev/null || fail "match inesperado: $1"; }

mkdir -p "$SYSROOT/usr/bin" "$SYSROOT/usr/share" "$SYSROOT/etc" "$DBROOT" "$STATEROOT" "$LOCKROOT" "$LOGROOT" "$CACHEROOT" "$TMPROOT" "$SNAPROOT" "$RECIPES" "$SOURCES"

cat > "$CONF" <<CFG
PKG_SYSROOT="$SYSROOT"
PKG_DB_ROOT="$DBROOT"
PKG_STATE_ROOT="$STATEROOT"
PKG_LOCK_ROOT="$LOCKROOT"
PKG_REMOVED_DB_ROOT="$STATEROOT/removed"
PKG_LOG_ROOT="$LOGROOT"
PKG_HISTORY_FILE="$LOGROOT/history.log"
PKG_CACHE_ROOT="$CACHEROOT"
PKG_TMP_ROOT="$TMPROOT"
PKG_RECIPES_ROOT="$RECIPES"
PKG_SNAPSHOT_ROOT="$SNAPROOT"
PKG_ALLOWED_INSTALL_PREFIXES=(/usr /etc /var)
PKG_COLOR=0
PKG_ASSUME_YES=1
PKG_MAKEFLAGS="-j1"
PKG_JOBS="1"
PKG_LOG_TO_SCREEN=0
CFG

mk_src() {
  local name="$1"
  local dir="$SOURCES/$name-src"
  mkdir -p "$dir"
  printf '%s\n' "$name source" > "$dir/README"
  tar -C "$SOURCES" -czf "$SOURCES/$name.tar.gz" "$(basename "$dir")"
  sha256sum "$SOURCES/$name.tar.gz" | awk '{print $1}'
}

write_recipe() {
  local recipe="$1" version="$2" release="$3" depends="$4" body="$5"
  local dir="$RECIPES/$recipe" sum depends_line
  mkdir -p "$dir/patches" "$dir/files" "$dir/hooks"
  sum="$(mk_src "$recipe-$version")"
  depends_line='pkg_depends=()'
  [[ -n "$depends" ]] && depends_line="pkg_depends=($depends)"
  cat > "$dir/pkgbuild" <<PKG
pkg_name="$recipe"
pkg_version="$version"
pkg_release="$release"
pkg_desc="$recipe tx test"
pkg_homepage="https://example.invalid/$recipe"
pkg_license="MIT"
pkg_sources=("$SOURCES/$recipe-$version.tar.gz")
pkg_sha256s=("$sum")
${depends_line}
pkg_build_depends=()
pkg_conflicts=()
pkg_provides=()
pkg_replaces=()
pkg_patches=()
pkg_options=()
pkg_config_files=()
build() { :; }
package() {
$body
}
PKG
}

run_pkg() { PKG_CONFIG_FILE="$CONF" bash "$PKG_BIN" "$@"; }

# cenário 1: falha no segundo pacote do upgrade deve restaurar o primeiro
write_recipe libtx 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "libtx-v1\\n" > "$PKG_DESTDIR/usr/lib/libtx.so"'
write_recipe apptx 1.0.0 1 '"libtx"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "apptx-v1\\n" > "$PKG_DESTDIR/usr/bin/apptx"'
run_pkg install --deps apptx >/dev/null
assert_file_contains "$SYSROOT/usr/lib/libtx.so" 'libtx-v1'
assert_file_contains "$SYSROOT/usr/bin/apptx" 'apptx-v1'

write_recipe libtx 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "libtx-v2\\n" > "$PKG_DESTDIR/usr/lib/libtx.so"'
write_recipe apptx 2.0.0 1 '"libtx"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "apptx-v2\\n" > "$PKG_DESTDIR/usr/bin/apptx"\n  printf "boom\\n" > "$PKG_DESTDIR/usr/share/tx-collision"'
printf 'external\n' > "$SYSROOT/usr/share/tx-collision"
if run_pkg upgrade apptx >/dev/null 2>&1; then
  fail "upgrade transacional deveria falhar no segundo pacote"
fi
assert_file_contains "$SYSROOT/usr/lib/libtx.so" 'libtx-v1'
assert_file_contains "$SYSROOT/usr/bin/apptx" 'apptx-v1'
assert_not_exists "$DBROOT/installed/libtx/meta.tmp"
pass "upgrade transacional restaura pacote já atualizado quando o próximo falha"

# cenário 2: dependência nova instalada na transação deve ser removida se o alvo falhar
write_recipe freshdep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "freshdep-v1\\n" > "$PKG_DESTDIR/usr/lib/freshdep.so"'
write_recipe freshapp 1.0.0 1 '"freshdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "freshapp-v1\\n" > "$PKG_DESTDIR/usr/bin/freshapp"\n  printf "boom-new\\n" > "$PKG_DESTDIR/usr/share/tx-new-collision"'
printf 'external\n' > "$SYSROOT/usr/share/tx-new-collision"
if run_pkg upgrade freshapp >/dev/null 2>&1; then
  fail "upgrade transacional deveria remover dependência nova após falha"
fi
assert_not_exists "$SYSROOT/usr/lib/freshdep.so"
assert_not_exists "$DBROOT/installed/freshdep"
assert_not_exists "$DBROOT/installed/freshapp"
pass "upgrade transacional remove dependência nova quando o alvo falha"

# cenário 3: lock em dependência deve barrar transação antes de tocar no sistema
write_recipe lockdep 1.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "lockdep-v1\\n" > "$PKG_DESTDIR/usr/lib/lockdep.so"'
write_recipe lockapp 1.0.0 1 '"lockdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lockapp-v1\\n" > "$PKG_DESTDIR/usr/bin/lockapp"'
run_pkg install --deps lockapp >/dev/null
write_recipe lockdep 2.0.0 1 '' $'  mkdir -p "$PKG_DESTDIR/usr/lib"\n  printf "lockdep-v2\\n" > "$PKG_DESTDIR/usr/lib/lockdep.so"'
write_recipe lockapp 2.0.0 1 '"lockdep"' $'  mkdir -p "$PKG_DESTDIR/usr/bin"\n  printf "lockapp-v2\\n" > "$PKG_DESTDIR/usr/bin/lockapp"'
(
  exec 9>"$LOCKROOT/lockdep.lock"
  flock -n 9
  sleep 5
) &
locker_pid=$!
sleep 0.3
if run_pkg upgrade lockapp >/dev/null 2>&1; then
  kill "$locker_pid" 2>/dev/null || true
  wait "$locker_pid" 2>/dev/null || true
  fail "upgrade deveria falhar ao detectar lock do conjunto transacional"
fi
kill "$locker_pid" 2>/dev/null || true
wait "$locker_pid" 2>/dev/null || true
assert_file_contains "$SYSROOT/usr/lib/lockdep.so" 'lockdep-v1'
assert_file_contains "$SYSROOT/usr/bin/lockapp" 'lockapp-v1'
pass "upgrade transacional falha cedo quando lock do conjunto já está ocupado"

echo "Todos os testes transacionais de falha/rollback/lock passaram em $TEST_ROOT"

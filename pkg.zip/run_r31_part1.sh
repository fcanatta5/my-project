#!/usr/bin/env bash
set -Eeuo pipefail
run(){ local name="$1"; shift; echo "== $name =="; "$@" >"QA_RESULTS_R31/${name}.log" 2>&1; }
run syntax bash -n usr/pkg/bin/pkg
run config_runtime bash tests/run-targeted-config-runtime-hardening-tests.sh
run input_validation bash tests/run-targeted-input-validation-tests.sh
run repo_index_path bash tests/run-targeted-repo-index-path-hardening-tests.sh
run binary_payload bash tests/run-targeted-binary-package-safety-tests.sh
run binary_symlink bash tests/run-targeted-binary-package-link-safety-tests.sh
run binary_manifest bash tests/run-targeted-binary-package-manifest-hardening-tests.sh
run binary_manifest_drift bash tests/run-targeted-binary-package-payload-manifest-drift-tests.sh
run git_integrity bash tests/run-targeted-git-source-integrity-tests.sh
run tx_failure_lock bash tests/run-targeted-transaction-failure-lock-tests.sh
run tx_recovery_lock bash tests/run-targeted-transaction-recovery-lock-contention-tests.sh
run tx_stale_cleanup bash tests/run-targeted-tx-stale-cleanup-tests.sh
run manifest_parent_dirs bash tests/run-targeted-manifest-implicit-parent-dirs-tests.sh
run solver_replaces bash tests/run-targeted-solver-replaces-tests.sh
run release_sanity bash tests/run-targeted-release-sanity-tests.sh
run consistency bash tests/run-consistency-tests.sh
run production_e2e bash tests/run-production-validation-e2e.sh
